# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re, json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['es']
        self.domains = ['pepecine.io', 'pepecine.tv']
        self.base_link = 'https://pepecine.me/'
        self.search_link = 'secure/search/%s?type=&limit=16'#'ver-online?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year, 'movie')
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(
                aliases),year, 'movie')
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year, 'series')
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year, 'series')
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = url[:-1] if url.endswith('/') else url
            url += '/seasons/%d/episodes/%d' % (int(season), int(episode))
            return url
        except BaseException:
            return

    def __search(self, titles, year, type):
        try:
            query = [self.search_link % (urllib.quote(cleantitle.getsearch(i)))for i in titles]
            query = [urlparse.urljoin(self.base_link, i) for i in query]

            t = [cleantitle.get(i) for i in set(titles) if i]
            self.cj = client.request(self.base_link, output='cookie')
            for u in query:
                try:
                    r = client.request(u, referer=self.base_link, cookie=self.cj, XHR=True)
                    r = json.loads(r)
                    r = r['results']
                    data = [(i['name'], i['id']) for i in r]
                    data = ['https://pepecine.me/secure/titles/{0}'.format(i[1]) for i in data if cleantitle.get(i[0]) in t]
                    if data:
                        url = data[0]
                    else:
                        data = client.request(data[0])
                        data = re.findall('<h3>Pelicula.+?">(.+?)\((\d{4})\).+?</a>',data, re.DOTALL)[0]
                        if titles[0] in data[0] and year == data[1]:
                            url = data[0]
                except BaseException:
                    pass

            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            query = url
            r = client.request(query, referer=self.base_link, cookie=self.cj, XHR=True)
            r = json.loads(r)
            links = r['title']['videos']

            data = [(i['url'], i['name'], i['quality']) for i in links if i]
            for url, info, quality in data:

                lang, info = self.get_lang_by_type(info)
                quality = self.quality_fixer(quality)
                if 'streamcloud' in url:
                    quality = 'SD'

                valid, host = source_utils.is_host_valid(url, hostDict)
                if 'goo' in url:
                    data = client.request(url)
                    url_id = re.findall('var\s*videokeyorig\s*=\s*"(.+?)"', data, re.DOTALL)[0]
                    url, host = 'http://hqq.tv/player/embed_player.php?vid=%s' % url_id, 'netu.tv'

                sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                'direct':False,'debridonly': False})

            return sources
        except BaseException:
            return sources

    def quality_fixer(self,quality):
        if '1080' in quality: return '1080p'
        elif '720' in quality: return '720p'
        else: return 'SD'

    def get_lang_by_type(self, lang_type):
        if 'Latino' in lang_type:
            return 'es', 'LAT'
        elif 'zl' in lang_type:
            return 'es', 'LAT'
        elif 'Castellano' in lang_type:
            return 'es', 'CAST'
        elif 'zc' in lang_type:
            return 'es', 'CAST'
        elif 'Subtitulado' in lang_type:
            return 'en', 'SUB'
        elif 'zs' in lang_type:
            return 'en', 'SUB'
        elif 'zi' in lang_type:
            return 'en', 'Ingles'
        elif 'Ingles' in lang_type:
            return 'en', 'Ingles'
        return 'es', None

    def resolve(self, url):
        return url