# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import re
import urllib
import urlparse
import requests

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['es']
        self.domains = ['pelisplus.tv']
        self.base_link = 'https://www.pelisplus.to/'
        self.referer = 'https://www.pelisplus.to/search/?s={0}'
        self.search_link = '/search/?s=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(aliases),
                                                                    year)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and tvshowtitle != localtvshowtitle: url = self.__search([tvshowtitle] + source_utils.aliases_to_array(aliases), year)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return

            url = url[:-1] if url.endswith('/') else url
            url += '/temporada/%d/capitulo/%d/' % (int(season), int(episode))
            return url
        except:
            return

    def __search(self, titles, year):
        try:
            query = [self.search_link % (cleantitle.getsearch(urllib.quote_plus(i))) for i in titles]

            query = [urlparse.urljoin(self.base_link, i) for i in query]

            t = [cleantitle.get(i) for i in set(titles) if i]
            for u in query:
                try:
                    r = client.request(u)
                    r = client.parseDOM(r, 'div', attrs={'class': 'Posters'})[0]
                    r = zip(client.parseDOM(r, 'a', ret='href'),
                            client.parseDOM(r, 'p'))
                    r = [i[0] for i in r if cleantitle.get(i[1]) in t]

                    return source_utils.strip_domain(r[0])
                except:
                    pass

            return
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            query = urlparse.urljoin(self.base_link, url)
            print query
            r = client.request(query)
            frames = zip(client.parseDOM(r, 'a', attrs={'href': '#option\d+'}),
                         re.findall('''video\[\d+\]\s*=\s*['"](.+?)['"]''', r, re.DOTALL))

            for host, url in frames:
                lang, info = 'es', 'LAT'
                qual = '720p'

                if 'fastplay' in url:
                    host = url

                valid, host = source_utils.is_host_valid(host, hostDict)
                if valid:
                    sources.append({'source': host, 'quality': qual, 'language': lang, 'url': url,
                                    'info': info, 'direct': False,'debridonly': False})
                else:
                    try:
                        if 'pelishd.tv' in url:
                            from resources.lib.modules import unjuice
                            import json
                            data = client.request(host)
                            if unjuice.test(data):
                                juice = unjuice.run(data)
                                links = json.loads(re.findall('sources:(\[.+?\])', juice)[0])
                                for stream in links:
                                    url = stream['file']
                                    qual = stream['label']

                                    url += '|User-Agent=%s' % urllib.quote(client.agent())
                                    sources.append({'source': host, 'quality': qual, 'language': lang, 'url': url,
                                                    'info': info, 'direct': True, 'debridonly': False})

                        elif 'www.pelisplus.net' in url:
                            headers = {'User-Agent': client.agent(),
                                       'Referer': url}
                            cj = requests.get(url, headers=headers).cookies
                            cj = '__cfduid=%s' % str(cj['__cfduid'])
                            vid_id = url.split('/')[-1]
                            headers['Cookie'] = cj
                            data = requests.post('https://www.pelisplus.net/api/source/%s' % vid_id, headers=headers).json()
                            streams = data['data']
                            for stream in streams:
                                url = stream['file']
                                url = 'https://www.pelisplus.net' + url if url.startswith('/') else url
                                qual = stream['label']
                                link = client.request(url, output='geturl')
                                link += '|User-Agent=%s' % urllib.quote(client.agent())
                                sources.append({'source': host, 'quality': qual, 'language': lang, 'url': link,
                                                'info': info, 'direct': True, 'debridonly': False})
                    except BaseException:
                        continue
                    sources.append({'source': host, 'quality': qual, 'language': lang, 'url': url,
                                    'info': info, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources

    def resolve(self, url):

        try:
            if 'animeshd' in url:
                host = client.request(url, output='geturl')

            elif 'server.pelisplus' in url:
                host = client.request(url)
                host = client.parseDOM(host, 'iframe', ret='src')[0]

            else:
                host = url

            if 'animehdpro' in host:
                data = client.request(host)
                host = re.compile('''file['"]:['"]([^'"]+)''', re.DOTALL).findall(data)[0]
                host = requests.get(host).headers['location']
                return host + '|User-Agent=%s' % urllib.quote(client.agent())

            elif 'tiwi' in host:
                from resources.lib.modules import jsunpack
                data = client.request(host)
                if jsunpack.detect(data):
                    data = jsunpack.unpack(data)
                    link = re.compile('''\{file:['"]([^'"]+)''', re.DOTALL).findall(data)[0]
                else:
                    link = re.compile('''dash\+xml.+?src:['"](.+?)['"]''', re.DOTALL).findall(data)[0]
                return link + '|User-Agent=%s&Referer=%s' % (urllib.quote(client.agent()), host)

            return host
        except:
            return url