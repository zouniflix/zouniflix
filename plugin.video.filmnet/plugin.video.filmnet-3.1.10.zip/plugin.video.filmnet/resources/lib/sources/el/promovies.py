# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import unjuice
from resources.lib.modules import dom_parser2 as dom


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['el']
        self.domains = ['promovies.pro']
        self.base_link = 'https://promovies.pro/'
        self.search_link = 'search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'localtitle': localtitle, 'title': title, 'aliases': aliases,'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            sources = []

            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = '%dx%d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '%s' % data['tvshowtitle'] if 'tvshowtitle' in data else '%s' % data['title']
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)
            headers = {'User-Agent': client.randomagent(),
                       'Referer': self.base_link}
            r = client.request(url, headers=headers, output='extended')
            headers['Cookie'] = r[3]

            posts = client.parseDOM(r[0], 'item')

            for post in posts:
                try:
                    name = client.parseDOM(post, 'title')[0]
                    name = client.replaceHTMLCodes(name)
                    link = client.parseDOM(post, 'link')[0]

                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, re.I)
                    t = re.findall('\w+', cleantitle.get(t))[0]

                    if not t == cleantitle.get(title): raise Exception()
                    if 'tvshows' in link:
                        tvshow = re.findall('tvshows/(.+?)/', link)[0]
                        link = self.base_link + 'episodes/%s-%s/' % (tvshow, hdlr)
                        r = client.request(link, headers=headers, output='extended')
                        r = r[0]

                    else:
                        if '-3d' in link: continue
                        r = client.request(link, headers=headers, output='extended')
                        headers['Cookie'] = r[3]
                        r = r[0]

                        y = client.parseDOM(r, 'span', attrs={'class': 'date'})[0]
                        y = re.findall('(\d{4})', y)[0]
                        year = data['year']
                        if not y == year: raise Exception()

                    frames = client.parseDOM(r, 'div', {'id': 'playeroptions'})[0]
                    frames = dom.parse_dom(frames, 'li', attrs={'class': 'dooplay_player_option'}, req=['data-post', 'data-nume', 'data-type'])
                    urls = []

                    for frame in frames:
                        try:

                            post = 'action=doo_player_ajax&post=%s&nume=%s&type=%s' %\
                                   (frame.attrs['data-post'], frame.attrs['data-nume'], frame.attrs['data-type'])
                            if '=trailer' in post: continue
                            p_link = 'https://promovies.pro/wp-admin/admin-ajax.php'
                            headers['Referer'] = link
                            flink = client.request(p_link, post=post, headers=headers)
                            flink = client.parseDOM(flink, 'iframe', ret='src')[0]

                            if any(x in frame for x in ['youtube', 'xrysoi.se', 'filmer', '.bp', '.blogger']): continue

                            r = client.request(flink, headers=headers)
                            r = unjuice.run(r)
                            if not r:
                                return
                            else:
                                urls = re.compile('''['"]file['"]:['"](.+?)['"]\,['"]label['"]:['"](.+?)['"]\,''',
                                                  re.DOTALL).findall(r)

                                sub = [i[0] for i in urls if i[0].endswith('srt')][0]
                                urls = [(i[0], i[1], sub, flink) for i in urls if not i[0].endswith('srt')]
                                urls.append(urls)
                        except BaseException:
                            return

                    for link, label, sub, ref in urls:
                        quality, info = source_utils.get_release_quality(label, label)
                        if '3D' in sub: info = '3D | SUB'
                        else:
                            info = 'SUB'
                        url = link + '|User-Agent=%s&Referer=%s' % (urllib.quote(headers['User-Agent']), urllib.quote(ref))
                        sources.append({'source': 'GVIDEO', 'quality': quality, 'language': 'gr',
                                        'url': url, 'info': info, 'direct': True, 'debridonly': False, 'sub': sub})

                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url