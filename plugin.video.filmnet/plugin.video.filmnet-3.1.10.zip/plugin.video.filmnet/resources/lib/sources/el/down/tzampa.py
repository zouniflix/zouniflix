# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urlparse, re, json

from resources.lib.modules import client
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['el']
        self.domains = ['tzampa.tv']
        self.base_link = 'https://movies.tzampa.tv/'
        self.ref = 'https://movies.tzampa.tv/'
        self.search_link = '/movie/%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:

            query = urlparse.urljoin(self.search_link, imdb)
            url = urlparse.urljoin(self.base_link, query)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            r = client.request(url)
            link = re.findall('''file["']:\s*['"]([^'"]+)''', r, re.DOTALL)[0]
            link = client.replaceHTMLCodes(link) + "|Referer=%s" % url

            subt = re.findall('''tracks.+?file:\s*['"]([^'"]+)''', r, re.DOTALL)[0]
            sub = subt if subt.endswith('srt') else 'https://cdn.tzampa.tv/vod/subs/%s.srt' % url.split('/')[-1]
            sub += "|Referer=%s" % url
            quality = '720p'
            lang, info = 'gr', 'SUB'

            sources.append({'source': 'CDN', 'quality': quality, 'language': lang, 'url': link, 'info': info, 'sub': sub,
                            'direct': True, 'debridonly': False})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url