# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import unjuice
from resources.lib.modules import dom_parser2 as dom


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['el']
        self.domains = ['tenies-online.gr']
        self.base_link = 'http://tenies-online.club/'
        self.search_link = '?story={}&sfSbm=Search&titleonly=3&do=search&subaction=search'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'localtitle': localtitle, 'title': title, 'aliases': aliases,'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            sources = []

            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = '%dx%d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '%s' % data['tvshowtitle'] if 'tvshowtitle' in data else '%s' % data['title']
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', query)

            url = self.search_link.format(urllib.quote_plus(query))
            url = urlparse.urljoin(self.base_link, url)
            headers = {'User-Agent': client.agent(),
                       'Referer': url}
            # cj = client.request(self.base_link, output='cookie')
            # headers['Cookie'] = cj
            r = client.request(url, headers=headers)
            posts = client.parseDOM(r, 'td', {'id': 'views3'})
            for post in posts:
                try:
                    name = client.parseDOM(post, 'a')[0]
                    name = client.replaceHTMLCodes(name.strip())
                    link = client.parseDOM(post, 'a', ret='href')[0]
                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, re.I)
                    t = cleantitle.get(t)
                    y = re.findall('[\.|\(|\[|\s](\d{4})[\.|\)|\]|\s]', name, re.I)[-1].upper()
                    if not t == cleantitle.get(title):
                        continue
                    if not y == data['year']:
                        continue
                    # if 'tvshows' in link:
                    #     tvshow = re.findall('tvshows/(.+?)/', link)[0]
                    #     link = self.base_link + 'episodes/%s-%s/' % (tvshow, hdlr)
                    #     r = client.request(link, headers=headers, output='extended')
                    #     r = r[0]
                    #
                    # else:
                    #     r = client.request(link, headers=headers, output='extended')
                    #     headers['Cookie'] = r[3]
                    #     r = r[0]
                    #
                    #     y = client.parseDOM(r, 'span', attrs={'class': 'date'})[0]
                    #     y = re.findall('(\d{4})', y)[0]
                    #     year = data['year']
                    #     if not y == year:
                    #         raise Exception()

                    # html = client.request(link)
                    # player = re.findall(r'''.load\(['"]([^'"]+)['"]\)''', html, re.DOTALL)[0]
                    tid = link.split('-')[-1]
                    player = urlparse.urljoin(self.base_link,
                                              '/engine/ajax/controller.php?mod=playlist&news_id={}'.format(tid))
                    r = client.request(player)
                    try:
                        if 'tvshowtitle' in data:
                            # seas = '{}\u03bf\u03c2 \u039a\u03cd\u03ba\u03bb\u03bf\u03c2'.format(int(data['season']))
                            # print seas
                            epis = '{} episode'.format(int(data['episode']))
                            seas = int(data['season']) - 1
                            season = client.parseDOM(r, 'optgroup')[seas]
                            frames = dom.parse_dom(season, 'option', req='value')
                            frames = [i.attrs['value'] for i in frames if epis in i.content]
                        else:
                            frames = dom.parse_dom(r, 'option', req='value')[1:]
                            frames = [i.attrs['value'] for i in frames if i]

                        for frame in frames:
                            if 'redvid' in frame:
                                flink = client.request(frame, headers=headers)
                                flink = client.parseDOM(flink, 'iframe', ret='src')[0]
                            else:
                                flink = frame
                            quality, info = source_utils.get_release_quality(flink, flink)
                            lang, info = 'gr', 'SUB'
                            valid, host = source_utils.is_host_valid(flink, hostDict)
                            if not valid:
                                continue

                            if 'openload' in host.lower() or 'oload' in host.lower():
                                r = client.request(url)
                                try:
                                    sub = client.parseDOM(r, 'track', ret='src', attrs={'srclang': 'el'})[0]
                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                         'sub': sub, 'direct': False, 'debridonly': False})
                                except:
                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                         'direct': False, 'debridonly': False})

                            sources.append({'source': host, 'quality': quality, 'language': 'gr',
                                            'url': flink, 'info': info, 'direct': False, 'debridonly': False})
                    except BaseException:
                        pass

                    try:
                        extra = client.parseDOM(r, 'div', attrs={'class': 'links_table'})[0]
                        extra = dom.parse_dom(extra, 'td')
                        extra = [dom.parse_dom(i.content, 'img', req='src') for i in extra if i]
                        extra = [(i[0].attrs['src'], dom.parse_dom(i[0].content, 'a', req='href')) for i in extra if i]
                        extra = [(re.findall('domain=(.+?)$', i[0])[0], i[1][0].attrs['href']) for i in extra if i]
                        for item in extra:
                            url = item[1]
                            if 'tenies-online' in url:
                                url = client.request(url, output='geturl', redirect=True)
                            else:
                                url = url
                            quality, info = source_utils.get_release_quality(url, url)
                            lang, info = 'gr', 'SUB'
                            valid, host = source_utils.is_host_valid(item[0], hostDict)
                            if not valid: continue
                            if 'openload' in host.lower() or 'oload' in host.lower():
                                r = client.request(url)
                                try:
                                    sub = client.parseDOM(r, 'track', ret='src', attrs={'srclang': 'el'})[0]
                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                         'sub': sub, 'direct': False, 'debridonly': False})
                                except:
                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                         'direct': False, 'debridonly': False})
                            else:
                                sources.append(
                                    {'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                     'direct': False, 'debridonly': False})
                    except BaseException:
                        pass





                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url