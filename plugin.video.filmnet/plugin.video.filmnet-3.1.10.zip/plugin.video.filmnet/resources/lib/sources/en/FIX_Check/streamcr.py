# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse,json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2
from resources.lib.modules import source_utils
from resources.lib.modules import cfscrape

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['search.stream.cr']
        self.base_link = 'https://search.stream.cr'
        self.search_link = 'main/index.php?query=%s'
        self.ajax_link = 'https://asap2bypass.streamcr.com/ajax/movie/get_sources/%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return      

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return
            
    def search_generic(self, title, season=None, episode=None):
        try:
            self.scraper = cfscrape.create_scraper()
            #r = self.scraper.get('https://stream.cr/').content
            if season:
                term = title.replace(' ','%20') + '%20season%20' + season
                check = '%s - Season %s' % (title, season)
            else:
                term = title.replace(' ','%20')
                check = title
            url = urlparse.urljoin(self.base_link, self.search_link % term)
            self.scraper.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
            self.scraper.headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
            self.scraper.headers['Referer'] = url
            self.scraper.headers['Host'] = 'search.stream.cr'
            self.scraper.headers['Accept-Encoding'] = 'gzip, deflate'
            self.scraper.headers['Upgrade-Insecure-Requests'] = '1'
            r = self.scraper.get(url).content
            r = dom_parser2.parse_dom(r, 'a', {'class': 'rl'})
            r = [i.attrs['href'] for i in r if i.content.split(' (<span')[0].lower() == check.lower()]
            if r:
                r = self.scraper.get(r[0]).content
                r = dom_parser2.parse_dom(r, 'span', {'id': 'inchannel'})[0]
                r = dom_parser2.parse_dom(r.content, 'iframe', req='allowfullscreen src')[0]
                r = client.request(r.attrs['allowfullscreen src'])
                if season:
                    r = dom_parser2.parse_dom(r, 'li', {'class': 'ep-item'})
                    r = [(i.attrs['data-id'], dom_parser2.parse_dom(i.content, 'a', req='title')) for i in r]
                    r = [(i[0], i[1][0].attrs['title']) for i in r]
                    r = [(i[0], i[1]) for i in r if 'Episode %02d' % (int(episode)) in i[1]]
                    eid = r[0][0]
                else:
                    eid = re.findall('''eid =\s*'([^']+)''', r)[0]
                url = self.ajax_link % eid
                return url
            else: return
        except BaseException: return
        
    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season = data['season'] if 'season' in data else None
            episode = data['episode'] if 'episode' in data else None
            url = self.search_generic(title, season, episode)
          
            r = client.request(url)
            jd = json.loads(r)
            links = []

            _sources = jd['sources']
            for source in _sources:
                links.append((source['label'],source['file']))
            for i in links:
                quality, info = source_utils.get_release_quality(i[0])
                sources.append({'source': 'CDN', 'quality': quality, 'language': 'en', 'url': i[1], 'direct': True, 'debridonly': False})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url