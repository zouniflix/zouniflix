# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import workers
from resources.lib.modules import dom_parser2 as dom

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ganol.movie', 'ganool.cx']
        self.base_link = 'http://ganol.si'
        self.search_link = '/search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []

            if url is None: return self._sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s S%02dE%02d' % (data['tvshowtitle'], int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s %s' % (data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)
            r = client.request(url)

            posts = client.parseDOM(r, 'item')

            self.hostprDict = hostprDict
            self.hostDict = hostDict
            self.total = self.hostprDict + self.hostDict
            items = []

            for post in posts:

                try:
                    t = client.parseDOM(post, 'title')[0]
                    t2 = t.lower().split(self.hdlr.lower())[0]

                    if not cleantitle.get_simple(t2) == cleantitle.get(title): raise Exception()
                    link = client.parseDOM(post, 'link')[0]

                    items += [(t, link)]

                except BaseException:
                    pass
            threads = []
            for item in items:
                name = item[0]
                name = client.replaceHTMLCodes(name)

                try:
                    y = re.findall('(?:\.|\(|\[|\s*|)(S\d*E\d*|S\d*)(?:\.|\)|\]|\s*|)', name, re.I)[-1].upper()
                except BaseException:
                    y = re.findall('(?:\.|\(|\[|\s*|)(\d{4})(?:\.|\)|\]|\s*|)', name)[0]
                if not y == self.hdlr:
                    continue
                threads.append(workers.Thread(self._get_sources, item))
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, item):
        try:
            url = item[1]
            r = client.request(url)
            quality, info = source_utils.get_release_quality(item[0], url)
            try:
                size = re.findall('((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', r)[-1]
                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                size = '%.2f GB' % size
                info.append(size)
            except BaseException:
                pass
            info = ' | '.join(info)
            enlaces = client.parseDOM(r, 'iframe', ret='src')
            extra = client.parseDOM(r, 'table')[0]
            enlaces += client.parseDOM(extra, 'a', ret='href')

            for url in enlaces:

                if any(x in url for x in ['.srt', '.rar', '.zip', '.iso', 'subscene.', 'destyy.', 'torrent', 'youtube']): raise Exception()
                url = client.replaceHTMLCodes(url)
                url = url.encode('utf-8')
                if 'ganol' in url: continue

                host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                host = client.replaceHTMLCodes(host)
                host = host.encode('utf-8')
                if host in self.hostprDict:
                    self._sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                          'info': info, 'direct': False, 'debridonly': True})
                elif host in self.hostDict:
                    self._sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                          'info': info, 'direct': False, 'debridonly': False})
                else:
                    continue

        except BaseException:
            pass

    def resolve(self, url):
        return url


