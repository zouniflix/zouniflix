# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re, urllib, urlparse, time

from resources.lib.modules import source_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import workers


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['moviefiles.org']
        self.base_link = 'https://moviefiles.org/'
        self.search_link = 'index.php?search=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []

            if url is None: return self._sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['title']

            hdlr = data['year']

            query = '%s %s' % (data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', query)

            url = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(query))
            r = client.request(url)
            posts = client.parseDOM(r, 'tbody')[0]
            posts = zip(re.findall('''href=['"]([^'"]+)['"]>([^<]+)''', posts, re.DOTALL),
                        re.findall('''</td><td>(.+?)</td></tr''', posts, re.DOTALL))
            posts = [(i[0][0], i[0][1], i[1]) for i in posts if i]

            links= []
            for post in posts:
                try:
                    name = post[1]
                    name = client.replaceHTMLCodes(name)

                    t = re.sub('(\.|\(|\[|\s|\_|\-)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|\_|\-)(.+|)', '', name, flags=re.I)

                    if not cleantitle.get(t) == cleantitle.get(title): raise Exception()


                    try:
                        y = re.findall('[\.|\(|\[|\s|\_|\-](S\d+E\d+|S\d+)[\.|\)|\]|\s|\_|\-]', name, re.I)[-1].upper()
                    except BaseException:
                        y = re.findall('[\.|\(|\[|\s\_|\-](\d{4})[\.|\)|\]|\s\_|\-]', name, re.I)[-1].upper()

                    if not y == hdlr: raise Exception()

                    fmt = re.sub('(.+)(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+)(\.|\)|\]|\s)', '', name.upper())
                    fmt = re.split('\.|\(|\)|\[|\]|\s|\-|\_', fmt)
                    fmt = [i.lower() for i in fmt]

                    if any(i.endswith(('subs', 'sub', 'dubbed', 'dub')) for i in fmt): raise Exception()
                    if any(i in ['extras', 'french', 'italian', 'trailer', 'sample'] for i in fmt): raise Exception()

                    url = client.replaceHTMLCodes(post[0])
                    url = urlparse.urljoin(self.base_link, url)
                    url = url.encode('utf-8')

                    info = []
                    if '3d' in fmt or '.3d.' in fmt: info.append('3D')
                    if any(i in ['hevc', 'h265', 'x265'] for i in fmt): info.append('HEVC')
                    try:
                        size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', post[2])[-1]
                        div = 1 if size.endswith(('GB', 'GiB')) else 1024
                        size = float(re.sub('[^0-9|/.|/,]', '', size))/div
                        size = '%.2f GB' % size
                        info.append(size)
                    except BaseException:
                        pass
                    quality, info2 = source_utils.get_release_quality(name, name)
                    info = ' | '.join(info)
                    links += [(url, quality, info, hostDict)]
                except BaseException:
                    pass

            threads = []
            for link in links: threads.append(workers.Thread(self._get_sources, link[0], link[1], link[2], link[3]))
            for i in threads: i.start()

            alive = [x for x in threads if x.is_alive() is True]
            while alive:
                alive = [x for x in threads if x.is_alive() is True]
                time.sleep(0.5)

            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, url, quality, info, hosters):
        try:
            ref = url
            r = client.request(url)
            r = client.request(url + '&dl', referer=ref)
            link = client.parseDOM(r, 'input', ret='value', attrs={'id': 'copyTarget'})[0]
            valid, host = source_utils.is_host_valid(link, hosters)

            self._sources.append(
                {'source': host, 'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': False,
                 'debridonly': False})
        except BaseException:
            pass

    def resolve(self, url):
        return url