# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, time

from resources.lib.modules import cleantitle
from resources.lib.modules import dom_parser2
from resources.lib.modules import client
from resources.lib.modules import workers
from resources.lib.modules import source_utils
from resources.lib.modules import cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['scnlog.me']
        self.base_link = 'https://scnlog.me/'
        self.search_movie = 'movies/?s=%s'
        self.search_show = 'tv-shows/?s=%s'


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []
            if url is None: return self._sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            self.title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s S%02dE%02d' % (
            data['tvshowtitle'], int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s %s' % (
            data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            query = urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, self.search_show % query) if 'tvshowtitle' in data \
                else urlparse.urljoin(self.base_link, self.search_movie % query)

            self.scraper = cfscrape.create_scraper()
            r = self.scraper.get(url).content
            posts =  client.parseDOM(r, 'div', attrs={'class':'title'})
            posts = [dom_parser2.parse_dom(i, 'a', req='href')[0] for i in posts if i]
            posts = [(i.attrs['href'], i.attrs['title']) for i in posts if i]
            posts = [(i[0], i[1]) for i in posts if cleantitle.get(i[1].split(self.hdlr)[0]) == cleantitle.get(self.title)]

            self.hostprDict = hostprDict
            self.hostDict = hostDict

            threads = []

            for i in posts: threads.append(workers.Thread(self._get_sources, i))
            [i.start() for i in threads]

            alive = [x for x in threads if x.is_alive() == True]
            while alive:
                alive = [x for x in threads if x.is_alive() == True]
                time.sleep(0.1)
            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, item):
        try:
            r = self.scraper.get(item[0]).content
            name = item[1]
            name = client.replaceHTMLCodes(name)
            main = client.parseDOM(r, 'div', {'class': 'entry'})
            main = client.parseDOM(main, 'div', attrs={'class':'download'})
            for con in main:
                links = client.parseDOM(con, 'a', ret='href')
                for i in links:
                    try:
                        url = i
                        if 'youtube' in url: continue
                        if any(x in url.lower() for x in ['.rar.', '.zip.', '.iso.']) or any(
                                url.lower().endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()

                        if any(x in url.lower() for x in ['youtube', 'sample', 'trailer']): raise Exception()
                        valid, host = source_utils.is_host_valid(url, self.hostDict)
                        if not valid:
                            valid, host = source_utils.is_host_valid(url, self.hostprDict)
                            if not valid:
                                continue
                            else:
                                rd = True
                        else:
                            rd = False
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')
                        quality, info = source_utils.get_release_quality(i, name)
                        try:
                            size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', con)[0]
                            div = 1 if size.endswith(('GB', 'GiB')) else 1024
                            size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                            size = '%.2f GB' % size
                            info.append(size)
                        except BaseException:
                            pass
                        info = ' | '.join(info)
                        if url in str(self._sources): continue
                        if rd:
                            self._sources.append(
                                {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                                 'direct': False, 'debridonly': True})
                        else:
                            self._sources.append(
                                {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                                 'direct': False, 'debridonly': False})
                    except BaseException:
                        pass
        except BaseException:
            pass

    def resolve(self, url):
        return url
