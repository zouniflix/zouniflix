# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse,json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2
from resources.lib.modules import source_utils
from resources.lib.modules import cfscrape

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['scr.cr']
        self.base_link = 'https://scr.cr/'
        self.search_link = 'search.php?query=%s'
        self.ajax_link = 'https://ajax2.scr.cr/get-source.php?eid=%s'
        self.vc_link = 'https://vcstream.to/player?fid=%s&page=embed'
        

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return		

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return
            
    def search_generic(self, title, season=None, episode=None):
        try:
            r = client.request(self.base_link, output='extended')
            self.cookie = r[4]
            self.headers = r[3]

            if season:
                term = '%s season %s' % (urllib.quote_plus(title), int(season))#title.replace(' ','+') + '+season+' + season
                term2 = '%s season %02d' % (urllib.quote_plus(title), int(season))
                check = '%s - Season %s' % (title, season)
                check2 = '%s - Season %02d' % (title, int(season))
            else:
                term = urllib.quote_plus(title)
                check = title
            url = urlparse.urljoin(self.base_link, self.search_link % term)            
            r = client.request(url, headers=self.headers, cookie=self.cookie)
            r = dom_parser2.parse_dom(r, 'a', {'class': 'ml-mask'})
            if season and not r:
                url = urlparse.urljoin(self.base_link, self.search_link % term2)
                r = client.request(url, headers=self.headers, cookie=self.cookie)
                r = dom_parser2.parse_dom(r, 'a', {'class': 'ml-mask'})
                r = [i.attrs['href'] for i in r if "title='%s'"%check2.lower() in i.content.lower()]   
            else:
                r = [i.attrs['href'] for i in r if "title='%s'"%check.lower() in i.content.lower()]        


            if r:
                url = urlparse.urljoin(self.base_link, r[0])
                r = client.request(url, headers=self.headers, cookie=self.cookie)
                if season:                   
                    r = dom_parser2.parse_dom(r, 'a', {'id': 'sv-ca1'})
                    r = [(i.attrs['data-eid'], i.content, i.attrs['data-fallback']) for i in r]
                    r = [(i[0], i[1], i[2]) for i in r if 'Episode %02d' % (int(episode)) in i[1]]
                    eid = r[0][0]
                    fallback = r[0][2]
                else:
                    eid,fallback = re.findall(r"data-eid\s*=\s*'([^']+).*?data-fallback='([^']+)", r)[0]
                    
                url = self.ajax_link % eid
                return url,fallback
            else: return
        except BaseException: return
        
    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season = data['season'] if 'season' in data else None
            episode = data['episode'] if 'episode' in data else None
            url,fallback = self.search_generic(title, season, episode)
            if not url: return sources
          
            r = client.request(url)
            if not r:
                r = client.request(fallback, headers=self.headers, cookie=self.cookie, redirect=False, output='extended')
                r = r[2]['Location']
                emb = re.findall(r'embed\/(\w+)', r)[0]
                emb = self.vc_link%emb
                headers = self.headers
                headers['Referer'] = r
                r = client.request(emb, headers=headers, XHR=True)

            jd = json.loads(r)
            links = []
            try:
                tracks = jd['tracks']
                for track in tracks:
                    if track['kind'] == 'captions':
                        srt = track['file']
                _sources = jd['sources']
            except BaseException:
                html = jd['html']
                label, file, srt_ = re.findall(r'config\s*=.*?title:\s*\'([^\']+).*?sources.*?file":"([^"]+).*?tracks(?:.*?file":"([^"]+))?', html, re.DOTALL)[0]
                _sources = '[{"label":"%s", "file":"%s", "srt":"%s"}]' % (label, file, srt)
                _sources = json.loads(_sources)

            for source in _sources:
                links.append((source['label'], source['file'], srt))
            for i in links:
                quality, info = source_utils.get_release_quality(i[0])
                sources.append({'source': 'CDN', 'quality': quality, 'language': 'en', 'url': i[1], 'sub': i[2], 'direct': True, 'debridonly': False})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url