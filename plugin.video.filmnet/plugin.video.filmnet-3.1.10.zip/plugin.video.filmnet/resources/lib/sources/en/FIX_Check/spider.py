# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''

import urllib, urlparse

from resources.lib.modules import client
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['videospider.in']
        self.base_link = 'https://videospider.in/'
        self.post_link = 'https://videospider.in/?try'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            imdb = data['imdb']

            headers = {'User-Agent': client.agent(),
                       'Referer': 'https://videospider.in/?try'}

            cj = client.request(self.base_link, headers=headers, output='cookie')
            headers['Cookie'] = cj
            headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8;'
            headers['Content-Type'] = 'application/x-www-form-urlencoded'
            post = {'imdb': imdb}
            post = urllib.urlencode(post)
            txt = client.request(self.post_link, post=post, headers=headers)

            url = client.parseDOM(txt, 'iframe', ret='src')[0]
            valid, host = source_utils.is_host_valid(url, hostDict)
            if not valid: raise Exception()
            data = client.request(url)
            quality = client.parseDOM(data, 'meta', ret='content')[0]
            quality, info = source_utils.get_release_quality(quality, None)
            info = ' | '.join(info)
            sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False, 'info': info})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url


