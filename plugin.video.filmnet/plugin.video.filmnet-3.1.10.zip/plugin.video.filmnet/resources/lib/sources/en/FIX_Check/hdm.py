# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse
import math, random

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['hdm.to']
        self.base_link = 'https://hdm.to'
        self.search_link = '/search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return


    def sources(self, url, hostDict, hostprDict):

        try:
            sources = []

            if url is None: return sources

            if debrid.status() is False: raise Exception()

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s S%02dE%02d' % (
            data['tvshowtitle'], int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s %s' % (
            data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)
            r = client.request(url)

            posts = client.parseDOM(r, 'item')

            items = []

            for post in posts:
                try:
                    t = client.parseDOM(post, 'title')[0]
                    u = client.parseDOM(post, 'link')[0]
                    src = client.parseDOM(post, 'iframe', ret='src')[0]
                    items += [(t, u, src)]
                except BaseException:
                    pass
            for item in items:
                try:
                    name = item[0]
                    name = client.replaceHTMLCodes(name)
                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)
                    if not cleantitle.get(t) == cleantitle.get(title): raise Exception()
                    try:
                        valid, host = source_utils.is_host_valid(item[2], hostDict)
                        if not valid: continue
                        sources.append({'source': host, 'quality': '720p', 'language': 'en', 'url': item[2],
                                        'direct': False, 'debridonly': False})

                    except BaseException:
                        url = urllib.quote(item[2],':/?=')
                        url, sub = self.get_link(url)
                        if url:
                            sources.append({'source': 'HLS', 'quality': '720p', 'language': 'en', 'url': url,
                                            'direct': True, 'debridonly': False})
                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def get_link(self, url):
        try:
            r = client.request(url)
            reg_hls = re.search('''var\s*hlsUrl\s*=.+?urlProtocol\)\.replace\("([^"]+)",\s*"([^"]+)"\)\+"([^"]+)";''', r)
            rep_1 = reg_hls.groups()[0]; rep_2 = reg_hls.groups()[1]; end_plus = reg_hls.groups()[2]
            url = url.split('?v=')[1]
            vtt_url = url.replace(".mp4", "_webvtt.vtt").replace('http://', 'https://')
            url = url.replace(rep_1, rep_2).replace('http://', 'https://') + end_plus
            return url, vtt_url
        except BaseException: return

    def resolve(self, url):
        return url