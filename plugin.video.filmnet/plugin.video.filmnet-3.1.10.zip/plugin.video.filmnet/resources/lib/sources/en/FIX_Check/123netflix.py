# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urlparse, urllib, base64

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['123netflix.pro']
        self.base_link = 'http://www1.123netflix.pro'
        self.search_link = '/?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            clean_title = cleantitle.getsearch(title)
            search_url = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(clean_title+' '+year))
            r = client.request(search_url)
            r = client.parseDOM(r, 'div', {'class': 'ml-item'})
            r = [dom_parser2.parse_dom(i, 'a', req=['href', 'oldtitle']) for i in r]
            r = [(i[0].attrs['href'], i[0].attrs['oldtitle']) for i in r]
            r = [(i[0]) for i in r if (cleantitle.get(i[1]) == cleantitle.get(title) and re.findall('(\d{4})',i[1])[0] == year)]

            url = r[0]
            return url
        except Exception:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['premiered'], url['season'], url['episode'] = premiered, season, episode
            try:
                tab = 'tab%d' % int(episode)
                title = url['tvshowtitle']
                clean_title = title + ' Season %d' % int(season)
                search_url = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(clean_title))
                r = client.request(search_url)
                r = client.parseDOM(r, 'div', {'class': 'ml-item'})
                r = [dom_parser2.parse_dom(i, 'a', req=['href', 'oldtitle']) for i in r]
                r = [i[0].attrs['href'] for i in r if
                     cleantitle.get(clean_title) in cleantitle.get(i[0].attrs['oldtitle'])]
                url = {'url': r[0], 'ep': tab}
                return url
            except BaseException:
                pass
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            if type(url) is dict:
                r = client.request(url['url'])
                r = client.parseDOM(r, 'div', attrs={'id': url['ep']})
                link = client.parseDOM(r, 'iframe', ret='src')[0]
                quality, info = source_utils.get_release_quality(link)
                valid, host = source_utils.is_host_valid(link, hostDict)
                if not valid: raise Exception()
                info = ' | '.join(info)

                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'url': link, 'info': info, 'direct': False,
                     'debridonly': False})
            else:
                r = client.request(url)
                r = client.parseDOM(r, 'div', attrs={'id': 'tab\d+'})
                link = client.parseDOM(r, 'iframe', ret='src')[0]
                quality, info = source_utils.get_release_quality(link)
                valid, host = source_utils.is_host_valid(link, hostDict)
                if not valid: raise Exception()
                info = ' | '.join(info)
                sources.append(
                    {'source': host, 'quality': quality, 'language': 'en', 'url': link, 'direct': False, 'info': info, 'debridonly': False})

            return sources
        except Exception:
            return

    def resolve(self, url):
        return url
