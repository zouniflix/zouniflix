# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse

from resources.lib.modules import source_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import workers
from resources.lib.modules import debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['crazyhdsource.com']
        self.base_link = 'http://crazyhdsource.com/'
        self.search_link = 'search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        self._sources = []
        try:
            if url is None:
                return self._sources
            if debrid.status() is False:
                raise Exception()

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            imdb = data['imdb']

            self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s S%02dE%02d' % (imdb, int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s' % imdb
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)

            r = client.request(url, referer=self.base_link)
            #posts = client.parseDOM(r, 'div', attrs={'class':'posts clear-block'})[0]
            #posts = client.parseDOM(posts, 'ul')[0]
            #posts = dom_parser2.parse_dom(posts, 'a')
            #posts = [(i.attrs['href'], i.content) for i in posts if not 'hidden' in i.attrs['href']]
            posts = client.parseDOM(r, 'item')
            self.hostDict = hostprDict + hostDict
            frames = []
            for item in posts:
                try:
                    name = client.parseDOM(item, 'title')[0]
                    name = client.replaceHTMLCodes(name)
                    url = client.parseDOM(item, 'link')[0]
                    frames = [(name, url)]
                except BaseException:
                    return self._sources
            threads = []
            for name, url in frames:
                threads.append(workers.Thread(self._get_sources, name, url))
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, name, url):
        try:
            r = client.request(url)
            name = client.replaceHTMLCodes(name)

            quality, info = source_utils.get_release_quality(name, url)
            info = ' | '.join(info)
            urls = client.parseDOM(r, 'a', ret='href', attrs={'target': '_blank'})
            urls = [i for i in urls if '/files/' in i]  # and hdlr.lower() in i.lower()][0]
            url = [i for i in urls if self.hdlr.lower() in i.lower()][0]
            if any(x in url.lower() for x in ['.rar.', '.zip.', '.iso.']) or any(
                    url.lower().endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()

            if any(x in url.lower() for x in ['youtube', 'sample', 'trailer']): raise Exception()
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            url = urllib.quote(url, ':/?=.!@#$%^&*()_-+')
            valid, host = source_utils.is_host_valid(url, self.hostDict)
            if valid:
                self._sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                      'info': info, 'direct': False, 'debridonly': True})

        except BaseException:
            pass

    def resolve(self, url):
        return url