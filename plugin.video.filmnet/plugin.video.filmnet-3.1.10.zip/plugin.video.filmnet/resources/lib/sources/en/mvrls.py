# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urllib
import urlparse

from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from resources.lib.modules import debrid


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['mvrls.com']
        self.base_link = 'http://mvrls.com/'
        self.search_link = 'search/{0}/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = None
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
        except BaseException:
            pass
        finally:
            return url
            
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = None
            url = {
                'imdb': imdb,
                'tvdb': tvdb,
                'tvshowtitle': tvshowtitle,
                'year': year}
            url = urllib.urlencode(url)
        except BaseException:
            pass
        finally:
            return url

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url:
                url = urlparse.parse_qs(url)
                url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
                url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
                url = urllib.urlencode(url)
        except BaseException:
            pass
        finally:
            return url
            
    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None: 
                return
            if debrid.status() == False:
                raise Exception()

            data = urlparse.parse_qs(url)
            data = dict((i, data[i][0]) for i in data)
            hostDict = hostDict + hostprDict

            r = client.request(urlparse.urljoin(
                      self.base_link, self.search_link.format(data['imdb'])))

            items = dom_parser2.parse_dom(r, 'item')
            
            if items:
                for item in items:
                    try:
                        title = dom_parser2.parse_dom(item, 'title')
                        if not title:
                            continue
                        else:
                            title = title[0].content
                        if 'premiered' in data:
                            if 'S%02dE%02d' % (int(data['season']), int(data['episode'])) not in title.upper():
                                continue
                        urls = dom_parser2.parse_dom(item, 'enclosure', req='url')
                        if urls:
                            urls = [i.attrs['url'] for i in urls]
                        if urls:
                            for url in urls:
                                try:
                                    info = []
                                    quality, info = source_utils.get_release_quality(title, url)
                                    info = ' | '.join(info)
                                    url = client.replaceHTMLCodes(url)
                                    url = url.encode('utf-8')
                                    valid, host = source_utils.is_host_valid(url, hostDict)
                                    host = client.replaceHTMLCodes(host)
                                    host = host.encode('utf-8')
                                    if not valid:
                                        continue
                                    sources.append(
                                        {'source': host, 'info': info, 'quality': quality, 
                                        'language': 'en', 'url': url, 'direct': False,
                                         'debridonly': True})
                                except BaseException:
                                    pass
                    except BaseException:
                        pass
        except BaseException:
            pass
        finally:
            return sources

    def resolve(self, url):
        return url
