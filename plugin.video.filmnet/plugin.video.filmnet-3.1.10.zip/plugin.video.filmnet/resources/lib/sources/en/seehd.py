# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import directstream
from resources.lib.modules import source_utils
from resources.lib.modules import cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['seehd.club', 'seehd.unblckd.bet']
        self.base_link = 'http://www.seehd.pl'
        self.movie_link = '/%s-%04d-watch-online/'
        self.tvshow_link = '/%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else int(data['year'])

            if 'tvshowtitle' in data:
                url = urlparse.urljoin(self.base_link, self.tvshow_link % cleantitle.geturl(title))
                url += '-s%02de%02d-watch-online/' % (int(data['season']), int(data['episode']))
            else:
                url = urlparse.urljoin(self.base_link, self.movie_link % (cleantitle.geturl(title), hdlr))
            scraper = cfscrape.create_scraper()
            r = scraper.get(url, timeout=15).content
            # r = client.request(url)
            if 'error404' in r:
                if 'tvshowtitle' in data:
                    url = urlparse.urljoin(self.base_link, self.tvshow_link % cleantitle.geturl(title))
                    url += '-season-%d-episode-%d/' % (int(data['season']), int(data['episode']))
                else:
                    url = urlparse.urljoin(self.base_link, '/%s-watch-online/' % cleantitle.geturl(title))
                r = scraper.get(url, timeout=15).content
            if '<meta name="application-name" content="Unblocked">' in r:
                return sources
            r = client.parseDOM(r, 'div',attrs={'class':'entry-content'})[0]
            frames = []
            frames += client.parseDOM(r, 'iframe', ret='src')
            frames += client.parseDOM(r, 'a', ret='href')
            frames += client.parseDOM(r, 'source', ret='src')
            try:
                q = re.findall('<strong>Quality:</strong>([^<]+)', r)[0]
                if 'high' in q.lower(): quality = '720p'
                elif 'cam' in q.lower(): quality = 'CAM'
                else: quality = 'SD'
            except BaseException: quality = 'SD'

            for i in frames:
                try:
                    if 'pasted.co' in i:
                        try:
                            data = client.request(i)
                            frame = client.parseDOM(data, 'iframe', ret='src', attrs={'id': 'pasteFrame'})[0]
                            frame = frame.replace('false', 'true')
                            links = client.request(frame)
                            links = client.parseDOM(links, 'pre', attrs={'id': 'thepaste'})[0]
                            links = client.parseDOM(links, 'li')
                            for i in links:
                                valid, host = source_utils.is_host_valid(i, hostDict)
                                quality = source_utils.get_release_quality(i, i)[0]
                                if valid:
                                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': i,
                                                    'direct': False, 'debridonly': False})
                                else:
                                    valid, host = source_utils.is_host_valid(i, hostprDict)
                                    if not valid: continue
                                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': i,
                                                    'direct': False, 'debridonly': True})
                        except:
                            pass
                    if 'facebook' in i or 'plus.google' in i:
                        continue
                    if 'http://24hd.org' in i and i.lower().endswith(('.mp4', 'ts')):
                        sources.append({'source': 'CDN', 'quality': quality, 'language': 'en', 'url': i,
                                    'info': '', 'direct': True, 'debridonly': False})

                    elif '24hd.club' in i:
                        pid = i.split('/')[-1]
                        plink = 'https://www.24hd.club/api/source/{}'.format(pid)
                        pdata = {'r': '',
                                 'd': 'www.24hd.club'}
                        data = client.request(plink, post=pdata, referer=url)

                        import json
                        data = json.loads(data)
                        for frame in data['data']:
                            link = frame['file']
                            quality = source_utils.get_release_quality(frame['label'], frame['label'])[0]
                            sources.append({'source': 'GVIDEO', 'quality': quality, 'language': 'en', 'url': link,
                                            'direct': False, 'debridonly': False})

                    elif 'ok.ru' in i:
                        host = 'vk'
                        url = directstream.odnoklassniki(i)
                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                        'info': '', 'direct': True, 'debridonly': False})

                    elif 'vk.com' in i:
                        host = 'vk'
                        url = directstream.vk(i)
                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                        'info': '', 'direct': True, 'debridonly': False})

                    else:
                        valid, host = source_utils.is_host_valid(i, hostDict)
                        if valid:
                            sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': i,
                                        'info': '', 'direct': False, 'debridonly': False})
                        else:
                            valid, host = source_utils.is_host_valid(i, hostprDict)
                            if not valid: continue
                            sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': i,
                                        'info': '', 'direct': False, 'debridonly': True})
                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        if 'fvs.io' in url:
            url = client.request(url, output='geturl', redirect=True)
        return url


