# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re, urllib, urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['cmovieshd.net']
        self.base_link = 'https://www2.cmovieshd.bz/'
        self.search_link = '/movie/search/%s'
        self.ajax_search = 'https://api.ocloud.stream/cmovieshd//movie/search/%s?link_web=https://www1.cmovieshd.bz/'

    def matchAlias(self, title, aliases):
        try:
            for alias in aliases:
                if cleantitle.get(title) == cleantitle.get(alias['title']):
                    return True
        except:
            return False

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            aliases.append({'country': 'us', 'title': title})
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            aliases.append({'country': 'us', 'title': tvshowtitle})
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
            return url
        except:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url == None: return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, locDict):
        sources = []

        try:
            if url is None:
                return sources
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            aliases = eval(data['aliases'])

            referer = urlparse.urljoin(self.base_link, self.search_link % (urllib.quote_plus(title.replace(' ', '-'))))
            query = self.ajax_search % (urllib.quote_plus(title.replace(' ', '-')))
            for r in range(1, 3):
                result = client.request(query, headers={'Referer': referer}, timeout=20)
                if result != None: break
                
            try:
              
                if 'episode' in data:            
                    r = client.parseDOM(result, 'div', attrs={'class': 'ml-item'})
                    r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
                    r = [(i[0], i[1], re.findall('(.*?)\s+-\s+Season\s+(\d)', i[1])) for i in r]
                    r = [(i[0], i[1], i[2][0]) for i in r if len(i[2]) > 0]
                    url = [i[0] for i in r if self.matchAlias(i[2][0], aliases) and i[2][1] == data['season']][0]
                    
                else:
                    r = client.parseDOM(result, 'div', attrs={'class': 'ml-item'})
                    r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'a', ret='title'))
                    results = [(i[0], i[1], re.findall('\((\d{4})', i[1])) for i in r]
                    try:
                        r = [(i[0], i[1], i[2][0]) for i in results if len(i[2]) > 0]
                        url = [i[0] for i in r if self.matchAlias(i[1], aliases) and (data['year'] == i[2])][0]
                    except:
                        url = None
                        pass

                    if (url == None):
                        url = [i[0] for i in results if self.matchAlias(i[1], aliases)][0]
                    
                url = '%s/watching.html' % url
                if 'episode' in data:
                    url = url+'?ep=%s'%data['episode']

            except:                           
              return sources
            
            url = url if 'http' in url else urlparse.urljoin(self.base_link, url)
            for r in range(1,3):
                result = client.request(url, timeout=10)
                if result != None:
                    break
            slinks = re.findall(r'data-video="([^"]+)', result)
            
            quali = re.search(r'<span class="quality">([^<]+)</span>',result)
            if quali:
                quali = quali.groups()[0]
            else:
                quali = 'SD'
            
            slinks = [slink if slink.startswith('http') else 'https:{0}'.format(
                      slink) for slink in slinks]

            for url in slinks:
                sub = re.search('http.+#caption=([^$]+)', url)
                if sub:
                    sub = sub.groups()[0]

            '''Grab all links from vidcloud.icu load.php pages'''
            _slinks = []
            for url in slinks:
                try:
                    if 'vidcloud.icu' in url:
                        urls = []
                        urls = source_utils.getVidcloudLink(url)
                        if urls:
                            for uri in urls:
                                _slinks.append((uri[0], uri[1]))
                    elif 'xstreamcdn.com' in url:
                        url, quality = source_utils.getXstreamcdnLink(url)
                        if url:
                            _slinks.append((url, quality))
                    else:
                        _slinks.append((url, 'HD'))
                except BaseException:
                    pass

            for url in _slinks:
                quali = url[1]
                url = url[0]
                url = client.replaceHTMLCodes(url)
                url = url.encode('utf-8')
                url = re.sub('(#caption=[^$]+)', '', url)
                valid, host = source_utils.is_host_valid(url, hostDict)
                direct = False if valid else True
                host = client.replaceHTMLCodes(host)
                host = host.encode('utf-8')
                info = []
                quality, info = source_utils.get_release_quality(quali, url)
                quality = quali if quality is 'SD' else quality
                info = ' | '.join(info)
                sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                'info': info, 'sub': sub, 'direct': direct, 'debridonly': False})
            return sources
        except:
            return sources

    def resolve(self, url):
        return url
