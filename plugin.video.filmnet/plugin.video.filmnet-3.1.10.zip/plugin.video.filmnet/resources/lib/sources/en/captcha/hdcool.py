# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, time, os

from resources.lib.modules import source_utils
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2
from resources.lib.modules import debrid
from resources.lib.modules import workers


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['www.hdc0ol.com/']
        self.base_link = 'http://www.hdc0ol.com/'
        self.search_link = 'http://www.hdc0ol.com/search.php?do=process'
        self.search_post_data = 'securitytoken=guest&do=process&query=%s&submit.x=0&submit.y=0'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []

            if url is None: return self._sources
            if debrid.status() is False: raise Exception()

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s S%02dE%02d' % (
                data['tvshowtitle'], int(data['season']),
                int(data['episode'])) if 'tvshowtitle' in data else '%s (%s)' % (
                data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_post_data % urllib.quote(query)
            r = client.request(self.search_link, post=url)
            posts = dom_parser2.parse_dom(r, 'a', attrs={'class': 'title'})
            items = []
            self.hostDict = hostDict + hostprDict

            for post in posts:
                try:
                    url = post.attrs['href']
                    url = client.replaceHTMLCodes(url)
                    name = post.content
                    items += [(name, url)]
                except BaseException:
                    pass

            lista = []

            for item in items:
                try:
                    name = item[0]
                    name = client.replaceHTMLCodes(name)
                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)

                    if not cleantitle.get(t) == cleantitle.get(title): raise Exception()

                    try:
                        y = re.findall('(?:\.|\(|\[|\s*|)(S\d+E\d+|S\d+)(?:\.|\)|\]|\s*|)', name, re.I)[-1].upper()
                    except BaseException:
                        y = re.findall('(?:\.|\(|\[|\s*|)(\d{4})(?:\.|\)|\]|\s*|)', name, re.I)[0].upper()

                    if not y == hdlr: raise Exception()
                    url = urllib.quote(item[1], '?&:/')
                    url = urlparse.urljoin(self.base_link, url) if not url.startswith('http') else url
                    lista.append((url, name))

                except BaseException:
                    pass

            threads = []
            for i in lista: threads.append(workers.Thread(self._get_sources, i))
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, item):
        try:
            r = client.request(item[0])
            quality, info = source_utils.get_release_quality(item[1], item[0])
            try:
                size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', r)[0]
                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                size = '%.2f GB' % size
                info.append(size)
            except BaseException:
                pass
            info = ' | '.join(info)
            links = client.parseDOM(r, 'div', attrs={'class': 'content'})[0]
            links = re.findall('Single Link(.+?)</pre', links, re.I | re.DOTALL)[0]
            links = re.findall('''((?:http|ftp|https)://[\w_-]+(?:(?:\.[\w_-]+)+)[\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])''',
                               links, re.DOTALL)
            for url in links:
                try:
                    if any(x in url for x in ['.rar.', '.zip.', '.iso.']) or any(
                        url.endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()
                    valid, host = source_utils.is_host_valid(url, self.hostDict)
                    if not valid: continue
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    self._sources.append(
                        {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                         'direct': False,
                         'debridonly': True})
                except BaseException:
                    pass
        except BaseException:
            pass

    def resolve(self, url):
        return url