# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['www.reddit.com']
        self.base_link = 'https://www.reddit.com/'
        self.mov_link = 'https://www.reddit.com/r/vsharemovies/'
        self.tv_link = 'https://www.reddit.com/r/vsharetv/'
        self.search_link = 'search?q=%s&restrict_sr=on'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def search(self, url, title, hdlr):
        try:
            content = []
            try:
                if not 'tv' in url:
                    query = urlparse.urljoin(url, self.search_link % urllib.quote(title+' '+hdlr))
                    r = client.request(query)
                    r = client.parseDOM(r, 'header', {'class': 'search-result-header'})
                    r = [dom_parser2.parse_dom(i, 'a', req='href') for i in r if i]
                    r = [(i[0].attrs['href'], i[0].content) for i in r if i]

                    content += [(i[0], i[1]) for i in r if
                                cleantitle.get(title) in cleantitle.get(i[1]) and hdlr in i[1]]

                else:
                    query = urlparse.urljoin(url, self.search_link % urllib.quote(title))
                    r = client.request(query)
                    r = client.parseDOM(r, 'header', {'class': 'search-result-header'})
                    r = [dom_parser2.parse_dom(i, 'a', req='href') for i in r if i]
                    r = [(i[0].attrs['href'], i[0].content) for i in r if i]
                    content += [(i[0], i[1]) for i in r if cleantitle.get(title) == cleantitle.get(i[1].split('(')[0])]

            except BaseException:
                pass
            return content
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return sources
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            if 'tvshowtitle' in data:
                urls = self.search(self.tv_link, title, hdlr)

            else:
                urls = self.search(self.mov_link, title, hdlr)

            for u in urls:
                try:
                    if not 'tv' in u[0]:
                        r = client.request(u[0])
                        url = client.parseDOM(r, 'a', ret='href')
                        url = [i for i in url if 'vshare.io/d/' in i][0]

                        data = client.request(url)
                        data = re.findall('>\s*(.+?)<br />', data)[0]
                        quality, info2 = source_utils.get_release_quality(data, u[1])
                        sources.append(
                            {'source': 'vshare', 'quality': quality, 'language': 'en', 'url': url, 'direct': False,
                             'debridonly': False})
                    else:
                        r = client.request(u[0])
                        url = dom_parser2.parse_dom(r, 'a')
                        url = [i.attrs['href'] for i in url if hdlr in i.content][0]

                        data = client.request(url)
                        data = re.findall('>\s*(.+?)<br />', data)[0]
                        quality, info2 = source_utils.get_release_quality(data, u[1])
                        sources.append(
                            {'source': 'vshare', 'quality': quality, 'language': 'en', 'url': url, 'direct': False,
                             'debridonly': False})

                except BaseException:
                    pass
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url