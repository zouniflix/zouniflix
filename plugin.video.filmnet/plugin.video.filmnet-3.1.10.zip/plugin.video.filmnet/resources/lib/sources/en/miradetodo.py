# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re, urllib, urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import cfscrape
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['miradetodo.net']
        self.base_link = 'https://miradetodo.net'
        self.search_link = '/?s=%s'
        self.episode_link = '/episodio/%s-%sx%s'
        self.tvshow_link = '/series/%s/'

    def movie(self, imdb, title, localtitle, aliases, year):

        self.scraper = cfscrape.create_scraper()
        try:
            t = 'http://www.imdb.com/title/%s' % imdb
            t = client.request(t, headers={'Accept-Language': 'es-AR'})
            t = client.parseDOM(t, 'title')[0]
            t = re.sub('(?:\(|\s)\d{4}.+', '', t).strip().encode('utf-8')

            q = self.search_link % urllib.quote_plus(t)
            q = urlparse.urljoin(self.base_link, q)

            # r = client.request(q)
            r = self.scraper.get(q).text

            r = client.parseDOM(r, 'div', attrs = {'class': 'item'})
            r = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, 'span', attrs = {'class': 'tt'}), client.parseDOM(i, 'span', attrs = {'class': 'year'})) for i in r]
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            r = [i[0] for i in r if cleantitle.get(t) == cleantitle.get(i[1]) and year == i[2]][0]

            url = re.findall('(?://.+?|)(/.+)', r)[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except BaseException:
            pass

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        self.scraper = cfscrape.create_scraper()
        try:
            t = cleantitle.geturl(tvshowtitle)

            q = self.tvshow_link % t
            q = urlparse.urljoin(self.base_link, q)
            r = self.scraper.get(q, output='geturl').geturl()

            if not r:
                t = 'http://www.imdb.com/title/%s' % imdb
                t = client.request(t, headers={'Accept-Language': 'es-AR'})
                t = client.parseDOM(t, 'title')[0]
                t = re.sub('(?:\(|\s)\(TV Series.+', '', t).strip().encode('utf-8')

                q = self.search_link % urllib.quote_plus(t)
                q = urlparse.urljoin(self.base_link, q)

                # r = client.request(q)
                r = self.scraper.get(q).text

                r = client.parseDOM(r, 'div', attrs = {'class': 'item'})
                r = zip(client.parseDOM(r, 'a', ret='href'), client.parseDOM(r, 'span', attrs = {'class': 'tt'}), client.parseDOM(r, 'span', attrs = {'class': 'year'}))
                r = [(i[0], re.sub('(?:\(|\s)\('+year+'.+', '', i[1]).strip().encode('utf-8'), i[2]) for i in r if len(i[0]) > 0 and '/series/' in i[0] and len(i[1]) > 0 and len(i[2]) > 0]
                r = [i[0] for i in r if year == i[2]][0]

            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'url': r}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            show = data['url'].split('/')[4]
            r = urlparse.urljoin(self.base_link, self.episode_link % (show, season, episode))

            url = re.findall('(?://.+?|)(/.+)', r)[0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except BaseException:
            pass

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources

            r = urlparse.urljoin(self.base_link, url)

            # result = client.request(r)
            result = self.scraper.get(r).text

            f = client.parseDOM(result, 'div', attrs = {'class': 'movieplay'})
            if not f:
                f = client.parseDOM(result, 'div', attrs={'class': 'embed2'})
                f = client.parseDOM(f, 'div')

            f = client.parseDOM(f, 'iframe', ret='data-lazy-src')[0]

            try:
                r = client.request(f)
                r = client.parseDOM(r, 'li')
                links = [client.parseDOM(i, 'a', ret='href')[0] for i in r if i]
                streams = []
                for i in links:
                    try:
                        data = self.scraper.get(i).text
                        frame = client.parseDOM(data, 'iframe', ret='src')[0]
                        streams.append(frame.rstrip())
                    except BaseException:
                        pass

                for stream in streams:
                    try:
                        if 'google' in stream:
                            valid, hoster = source_utils.is_host_valid(stream, hostDict)
                            urls, host, direct = source_utils.check_directstreams(stream, hoster)
                            for x in urls: sources.append(
                                {'source': host, 'quality': x['quality'], 'language': 'en', 'url': x['url'],
                                 'direct': direct, 'debridonly': False})
                        elif stream.startswith('http'):
                            valid, host = source_utils.is_host_valid(stream, hostDict)
                            if not valid: continue
                            quality, info = source_utils.get_release_quality(url, stream)
                            sources.append(
                                {'source': host, 'quality': quality, 'language': 'en', 'url': stream, 'direct': False,
                                 'debridonly': False})
                        else:
                            continue
                    except BaseException:
                        pass


            except BaseException:
                pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url


