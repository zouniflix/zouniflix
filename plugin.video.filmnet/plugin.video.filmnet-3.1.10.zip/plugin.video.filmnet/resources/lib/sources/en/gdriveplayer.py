# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''

import urllib, urlparse, re, json

from resources.lib.modules import jsunpack
from resources.lib.modules import client

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['gdriveplayer.us']
        self.base_link = 'http://gdriveplayer.us/'
        self.episode_api = 'https://database.gdriveplayer.us/player.php?type=series&imdb={}&season={}&episode={}'
        self.movie_api = 'http://database.gdriveplayer.us/player.php?imdb={}'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            imdb = data['imdb']
            if 'tvshowtitle' in data:
                season, episode = data['season'], data['episode']
                player_link = self.episode_api.format(imdb, season, episode)
            else:
                player_link = self.movie_api.format(imdb)
            headers = {'User-Agent': client.agent(),
                       'Referer': self.base_link}
            page_data = client.request(player_link, headers=headers)
            ptext = jsunpack.unpack(page_data).replace('\\', '')
            ct = re.findall('"ct":"([^"]+)', ptext)[0]
            salt = re.findall('"s":"([^"]+)', ptext)[0].decode('hex')
            passphrase = "alsfheafsjklNIWORNiolNIOWNKLNXakjsfwnBdwjbwfkjbJjkBkjbfejkbefjkfegMKLFWN"
            from resources.lib.modules import jscrypto
            etext = jscrypto.decode(ct, passphrase, salt)
            ctext = jsunpack.unpack(etext).replace('\\', '')
            frames = json.loads(re.findall(r'sources:\s*(\[[^]]+\])', ctext)[0])
            # video_url = [i['file'] for i in frames if '720' in i['label']]
            # video_url = video_url[0] if video_url > 0 else [i['file'] for i in frames if 'Original' in i['label']][0]

            video_url = client.request(frames[0]['file'], headers=headers, redirect=False, output='location')

            sources.append({'source': 'GVIDEO', 'quality': '720p', 'language': 'en', 'url': video_url,
                            'direct': True, 'debridonly': False,})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
