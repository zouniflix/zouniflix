# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re, json, urllib,urlparse,requests,urllib2

from resources.lib.modules import unjuice
from resources.lib.modules import client
from resources.lib.modules import directstream
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.base_link = 'http://www.imdb.com'
        self.search_link = '/find?ref_=nv_sr_fn&q=%s&s=all'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = imdb
            return url
        except Exception:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources
            result = url
            link = 'http://indexmovie.stream/download/' + result
            ua = 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36'
            headers = { 'User-Agent' : ua }
            r = client.request(link, headers=headers)
            if r is None or '404 - NOT FOUND' in r:
                return sources

            try:
                link = client.parseDOM(r, 'div', attrs={'class':'download_links'})[0]
                link = zip(client.parseDOM(link, 'a', ret='href'),
                        re.findall('>(\d{3,4}p)<', link, re.I))
            except BaseException:
                r = client.request(link.replace('/download/', '/embed/'), headers=headers)
                r = unjuice.run(r)
                r = re.findall('sources:\[(.+?)\]', r)[0]
                r = json.loads(r)
                link = [(r['file'], r['label'])]

            for url, qual in link:
                try:
                    quality, info = source_utils.get_release_quality(qual, qual)
                    host = 'gvideo'
                    url = urllib.quote(url, './:?+=-_%$#@!*')
                    if 'no-video' in url: raise Exception()
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': True, 'debridonly': False})
                except BaseException:
                    pass

            return sources
        except Exception:
            return

    def resolve(self, url):
        return url