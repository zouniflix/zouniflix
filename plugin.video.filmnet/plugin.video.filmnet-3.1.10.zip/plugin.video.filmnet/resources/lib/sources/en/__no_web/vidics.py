# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urlparse,random,urllib

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import dom_parser2
from resources.lib.modules import log_utils
from resources.lib.modules import cfscrape

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['vidics.to','vidics.unblocked.mx']
        self.base_link = 'https://vidics.to'
        self.search_link = urlparse.urljoin(self.base_link, 'Category-FilmsAndTV/Genre-Any/Letter-Any/ByPopularity/1/Search-%s.htm')
                       
    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            clean_title = cleantitle.geturl(title).replace('-','%20')
            url = self._search(clean_title, title, year)
            return url
        except Exception:
            return
            
    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            clean_title = cleantitle.geturl(tvshowtitle).replace('-','%20')
            url = self._search(clean_title, tvshowtitle, year)
            return url
        except Exception:
            return
            
    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url: return
            url += '-Season-%01d-Episode-%01d' % (int(season), int(episode))
            return url
        except Exception:
            return
            
    def _search(self, title, or_title, year):
        try:
            url = self.search_link % title
            for i in range(1, 5):
                r = client.request(url, post='ajax=1', timeout=5)
                if r: break
            r = client.parseDOM(r, 'div', attrs={'class':'searchResultInner tooltip'})
            r = [(client.parseDOM(i, 'a', ret='href')[0],
                  client.parseDOM(i, 'h2', ret='title')[0]) for i in r]
            r = [urlparse.urljoin(self.base_link,i[0]) for i in r if cleantitle.get(or_title) in cleantitle.get(i[1])]
            return r[0]
        except BaseException: return
            
    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if not url: return sources

            r = client.request(url)
            r = dom_parser2.parse_dom(r, 'div', {'class': 'movie_link'})
            r = [dom_parser2.parse_dom(i.content, 'a', req='href') for i in r]
            r = [(urlparse.urljoin(self.base_link, i[0].attrs['href']), i[0].content) for i in r]

            for i in r:
                try:
                    host = i[1].split('.')[0]
                    if host.lower() in str(hostDict):
                        sources.append({
                            'source': host,
                            'info': '',
                            'quality': 'SD',
                            'language': 'en',
                            'url': i[0],
                            'direct': False,
                            'debridonly': False
                        })
                    elif host.lower() in str(hostprDict):
                        sources.append({
                            'source': host,
                            'info': '',
                            'quality': 'SD',
                            'language': 'en',
                            'url': i[0],
                            'direct': False,
                            'debridonly': True
                        })
                except BaseException:
                    pass
                    
            return sources
        except BaseException:
            return sources
            
    def resolve(self, url):
        try:
            for i in range(1, 5):
                r = client.request(url, timeout=5)
                if r: break
            r = dom_parser2.parse_dom(r, 'div', {'class': re.compile('movie_link\d')})
            r = [dom_parser2.parse_dom(i.content, 'a', req='href') for i in r]
            r = [i[0].attrs['href'] for i in r]
            url = r[0]
            return url
        except BaseException:
            return