# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys, json
from urllib import quote_plus
from random import randint
from .init import rtype, url, tvshowtitle, year, tvdb, season, imdb
from . import control


def run():

    if rtype == 'movie':
        from resources.lib.indexers import movies

        rlist = movies.movies().get(url, create_directory=False)
        r = sys.argv[0] + "?action=play"
    elif rtype == 'episode':
        from resources.lib.indexers import episodes

        rlist = episodes.episodes().get(tvshowtitle, year, imdb, tvdb, season, create_directory=False)
        r = sys.argv[0] + "?action=play"
    elif rtype == 'season':
        from resources.lib.indexers import episodes

        rlist = episodes.seasons().get(tvshowtitle, year, imdb, tvdb, create_directory=False)
        r = sys.argv[0] + "?action=random&rtype=episode"
    elif rtype == 'show':
        from resources.lib.indexers import tvshows

        rlist = tvshows.tvshows().get(url, create_directory=False)
        r = sys.argv[0] + "?action=random&rtype=season"

    try:
        rand = randint(1, len(rlist)) - 1
        for p in ['title', 'year', 'imdb', 'tvdb', 'season', 'episode', 'tvshowtitle', 'premiered', 'select']:
            if rtype == "show" and p == "tvshowtitle":
                try:
                    r += '&' + p + '=' + quote_plus(rlist[rand]['title'])
                except:
                    pass
            else:
                try:
                    r += '&' + p + '=' + quote_plus(rlist[rand][p])
                except:
                    pass
        try:
            r += '&meta=' + quote_plus(json.dumps(rlist[rand]))
        except:
            r += '&meta=' + quote_plus("{}")
        if rtype == "movie":
            try:
                control.infoDialog(rlist[rand]['title'], control.lang(32536).encode('utf-8'), time=30000)
            except:
                pass
        elif rtype == "episode":
            try:
                control.infoDialog(
                    rlist[rand]['tvshowtitle'] + " - Season " + rlist[rand]['season'] + " - " + rlist[rand]['title'],
                    control.lang(32536).encode('utf-8'), time=30000
                )
            except:
                pass
        control.execute('RunPlugin(%s)' % r)
    except:
        control.infoDialog(control.lang(32537).encode('utf-8'), time=8000)
