# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import json
import os
import xbmc
import urllib
import re

from resources.lib.modules import control
from resources.lib.modules import trakt

try:
    from sqlite3 import dbapi2 as database
except ImportError:
    from pysqlite2 import dbapi2 as database


def getMovieIndicators(refresh=False):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        if not refresh:
            timeout = 720
        elif trakt.getWatchedActivity() < trakt.timeoutsyncMovies():
            timeout = 720
        else:
            timeout = 0
        indicators = trakt.cachesyncMovies(timeout=timeout)
        return indicators
    except BaseException:
        pass


def getTVShowIndicators(refresh=False):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        if not refresh:
            timeout = 720
        elif trakt.getWatchedActivity() < trakt.timeoutsyncTVShows():
            timeout = 720
        else:
            timeout = 0
        indicators = trakt.cachesyncTVShows(timeout=timeout)
        return indicators
    except BaseException:
        pass


def getSeasonIndicators(imdb):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        indicators = trakt.syncSeason(imdb)
        return indicators
    except BaseException:
        pass


def getLocalOverlay(imdb, season='None', episode='None'):
    try:
        try:
            control.makeFile(control.dataPath)
            dbcon = database.connect(control.historyFile)
            dbcur = dbcon.cursor()
            dbcur.execute(
                "SELECT * FROM history WHERE (imdb = '%s' and season = '%s' and episode = '%s')" %
                (imdb, season, episode))
            match = dbcur.fetchone()
            if match:
                return '7'
        except BaseException:
            pass

        db_file = control.videosdbFile()

        conn = database.connect(db_file)
        cursor = conn.cursor()

        if season == 'None' and episode == 'None':
            sql = """select
            case when
            (select count(idfile) from files
            where strfilename like '%&imdb={0}%'
            and (strfilename not like '%&season=%' or strfilename like '%&season=none%')
            and playcount >= 1) >= 1 Then '7' Else '6' End as Result""".format(imdb)
        else:
            sql = """select
            case when
            (select count(idfile) from files
            where strfilename like '%&imdb={0}%' and strfilename like '%&season={1}%' and strfilename like '%&episode={2}%'
            and playcount >= 1) >= 1 Then '7' Else '6' End as Result""".format(imdb, season, episode)

        cursor.execute(sql)
        if str(cursor.fetchone()[0]) == '7':
            try:
                dbcon = database.connect(control.historyFile)
                dbcur = dbcon.cursor()
                dbcur.execute(
                    "CREATE TABLE IF NOT EXISTS history ("
                    "imdb TEXT, "
                    "season TEXT, "
                    "episode TEXT, "
                    "UNIQUE(imdb, season, episode)"
                    ");")
                dbcur.execute(
                    "INSERT INTO history Values (?, ?, ?)", (imdb, season, episode))
                dbcon.commit()
                return '7'
            except BaseException:
                pass
        return '6'
    except BaseException:
        return '6'


def getMovieOverlay(indicators, imdb):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        try:
            playcount = indicators._get_watched('movie', imdb, '', '')
            return str(playcount)
        except BaseException:
            playcount = [i for i in indicators if i == imdb]
            playcount = 7 if len(playcount) > 0 else 6
            return str(playcount)
    except BaseException:
        playcount = getLocalOverlay(imdb)
        return playcount


def getTVShowOverlay(indicators, tvdb):
    try:
        playcount = [
            i[0] for i in indicators if i[0] == tvdb and len(
                i[2]) >= int(
                i[1])]
        playcount = 7 if len(playcount) > 0 else 6
        return str(playcount)
    except BaseException:
        return '6'


def getEpisodeOverlay(indicators, imdb, tvdb, season, episode):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        try:
            playcount = indicators._get_watched_episode(
                {'imdb_id': imdb, 'season': season, 'episode': episode, 'premiered': ''})
            return str(playcount)
        except BaseException:
            playcount = [i[2] for i in indicators if i[0] == tvdb]
            playcount = playcount[0] if len(playcount) > 0 else []
            playcount = [
                i for i in playcount if int(season) == int(
                    i[0]) and int(episode) == int(
                    i[1])]
            playcount = 7 if len(playcount) > 0 else 6
            return str(playcount)
    except BaseException:
        playcount = getLocalOverlay(imdb, season, episode)
        return playcount


def markMovieDuringPlayback(imdb, watched):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()

        if int(watched) == 7:
            trakt.markMovieAsWatched(imdb)
        else:
            trakt.markMovieAsNotWatched(imdb)
        trakt.cachesyncMovies()

        if trakt.getTraktAddonMovieInfo():
            trakt.markMovieAsNotWatched(imdb)
    except BaseException:
        pass


def markEpisodeDuringPlayback(imdb, tvdb, season, episode, watched):
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()

        if int(watched) == 7:
            trakt.markEpisodeAsWatched(tvdb, season, episode)
        else:
            trakt.markEpisodeAsNotWatched(tvdb, season, episode)
        trakt.cachesyncTVShows()

        if trakt.getTraktAddonEpisodeInfo():
            trakt.markEpisodeAsNotWatched(tvdb, season, episode)
    except BaseException:
        pass


def movies(imdb, watched):
    control.busy()
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        if int(watched) == 7:
            trakt.markMovieAsWatched(imdb)
        else:
            trakt.markMovieAsNotWatched(imdb)
        control.infoDialog(
            control.lang(32057).encode('utf-8'),
            sound=True,
            icon='INFO')
        control.idle()
        trakt.cachesyncMovies()
        control.refresh()
    except BaseException:
        control.idle()
        pass


def episodes(imdb, tvdb, season, episode, watched):
    control.busy()
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()
        if int(watched) == 7:
            trakt.markEpisodeAsWatched(tvdb, season, episode)
        else:
            trakt.markEpisodeAsNotWatched(tvdb, season, episode)
        control.infoDialog(
            control.lang(32057).encode('utf-8'),
            sound=True,
            icon='INFO')
        control.idle()
        trakt.cachesyncTVShows()
        control.refresh()
    except BaseException:
        control.idle()
        pass


def tvshows(tvshowtitle, imdb, tvdb, season, watched):
    control.busy()
    try:
        if trakt.getTraktIndicatorsInfo() is False:
            raise Exception()

        if season:
            from resources.lib.indexers import episodes
            items = episodes.episodes().get(tvshowtitle, '0', imdb, tvdb, season, idx=False)
            items = [(int(i['season']), int(i['episode'])) for i in items]
            items = [
                i[1] for i in items if int(
                    '%01d' %
                    int(season)) == int(
                    '%01d' %
                    i[0])]
            for i in items:
                if int(watched) == 7:
                    trakt.markEpisodeAsWatched(tvdb, season, i)
                else:
                    trakt.markEpisodeAsNotWatched(tvdb, season, i)
        else:
            if int(watched) == 7:
                trakt.markTVShowAsWatched(tvdb)
            else:
                trakt.markTVShowAsNotWatched(tvdb)
        trakt.cachesyncTVShows()
        control.refresh()
    except BaseException:
        pass
    control.idle()
    control.refresh()
