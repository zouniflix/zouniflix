# -*- coding: utf-8 -*-

"""
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

from resources.lib.modules import client, control, log_utils, cache
import json, datetime, xbmcaddon


def get_account():
    try:
        refreshtoken = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_refresh')
        rd_enabled = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_enabled')
        if rd_enabled == 'false' or '':
            #log_utils.log('@#@RD Information-FALSE', log_utils.LOGNOTICE)
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.status', 'Disabled in SMR')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.username', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.email', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.points', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.type', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.expiration', '')
        elif refreshtoken == '' or refreshtoken is None:
            #log_utils.log('@#@Refresh-TOKEN', log_utils.LOGNOTICE)
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.status', 'Not Authorized')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.username', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.email', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.points', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.type', '')
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.expiration', '')
        else:
            #log_utils.log('@#@RD-ENABLED', log_utils.LOGNOTICE)
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.status', 'Enabled')

            access_token = refresh_token()
            headers = {'Authorization': 'Bearer %s' % access_token}
            #log_utils.log('@#@RD-HEADERS: %s' % headers, log_utils.LOGNOTICE)
            js_result2 = json.loads(
                cache.get(
                    client.request,
                    1,
                    'https://api.real-debrid.com/rest/1.0/user',
                    True,
                    True,
                    False,
                    True,
                    None,
                    None,
                    headers,
                    False,
                    False,
                    None,
                    None,
                    None,
                    True,
                    '',
                    5))

            ts = datetime.datetime.strptime(str(js_result2['expiration']), '%Y-%m-%dT%H:%M:%S.000Z')
            ts = ts.strftime('%a, %d %b, %Y at %H:%M')
            l = str(js_result2['expiration']).split('T')[0]
            a, b, c = l.split('-')
            z = datetime.datetime.today().strftime('%Y-%m-%d')
            e, f, g = z.split('-')
            f_date = datetime.date(int(e), int(f), int(g))
            l_date = datetime.date(int(a), int(b), int(c))
            delta = l_date - f_date
            l = delta.days

            if int(l) == 1:
                left = '1 Day Left (%s)' % ts
            else:
                left = '%01d Days Left (%s)' % (l, ts)

            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.username', str(js_result2['username']))
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.email', str(js_result2['email']))
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.points', str(js_result2['points']))
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.type', str(js_result2['type']).title())
            xbmcaddon.Addon(control.addonInfo('id')).setSetting('rd.expiration', left)
    except BaseException:
        import traceback
        log_utils.log('RD Information Error :: %s' % traceback.print_exc())
        pass

# def get_account():
#     try:
#         refreshtoken = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_refresh')
#         if refreshtoken == '' or refreshtoken == None:
#             control.setting('rd.status', 'Not Setup')
#             control.setting('rd.username', '')
#             control.setting('rd.email', '')
#             control.setting('rd.points', '')
#             control.setting('rd.type', '')
#             control.setting('rd.expiration', '')
#         else:
#             control.setting('rd.status', 'Enabled')
#
#             access_token = refresh_token()
#             headers = {'Authorization': 'Bearer %s' % access_token}
#             js_result2 = json.loads(client.request('https://api.real-debrid.com/rest/1.0/user', headers=headers, timeout='3'))
#             log_utils.log('FINAL TEST RD DATA %s' % js_result2)
#
#             ts = datetime.datetime.strptime(str(js_result2['expiration']), '%Y-%m-%dT%H:%M:%S.000Z')
#             ts = ts.strftime('%a, %d %b, %Y at %H:%M')
#             l = str(js_result2['expiration']).split('T')[0]
#             a, b, c = l.split('-')
#             z = datetime.datetime.today().strftime('%Y-%m-%d')
#             e, f, g = z.split('-')
#             f_date = datetime.date(int(e), int(f), int(g))
#             l_date = datetime.date(int(a), int(b), int(c))
#             delta = l_date - f_date
#             l = delta.days
#
#             if int(l) == 1:
#                 left = '1 Day Left (%s)' % ts
#             else:
#                 left = '%01d Days Left (%s)' % (l, ts)
#
#             control.setting('rd.username', str(js_result2['username']))
#             control.setting('rd.email', str(js_result2['email']))
#             control.setting('rd.points', str(js_result2['points']))
#             control.setting('rd.type', str(js_result2['type']).title())
#             control.setting('rd.expiration', left)
#     except:
#         pass


def refresh_token():
    try:
        refreshtoken = xbmcaddon.Addon('script.module.resolveurl').getSetting(
            'RealDebridResolver_refresh')
        client_id = xbmcaddon.Addon('script.module.resolveurl').getSetting(
            'RealDebridResolver_client_id')
        client_secret = xbmcaddon.Addon('script.module.resolveurl').getSetting(
            'RealDebridResolver_client_secret')
        data = {
            'client_id': client_id,
            'client_secret': client_secret,
            'code': refreshtoken,
            'grant_type': 'http://oauth.net/grant_type/device/1.0'}
        js_result = json.loads(
            cache.get(
                client.request,
                1,
                'https://api.real-debrid.com/oauth/v2/token',
                True,
                True,
                False,
                True,
                None,
                data,
                None,
                False,
                False,
                None,
                None,
                None,
                True,
                '',
                5))
        xbmcaddon.Addon('script.module.resolveurl').setSetting('RealDebridResolver_token', js_result['access_token'])
        xbmcaddon.Addon('script.module.resolveurl').setSetting('RealDebridResolver_refresh', js_result['refresh_token'])
        return js_result['access_token']
    except BaseException:
        return


def rd_check():
    rd_priority = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_priority')
    xbmcaddon.Addon(control.addonInfo('id')).setSetting('RealDebridResolver_priority', rd_priority)

    check_rd_now = False

    _rd_enabled = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_enabled')
    l_rd_enabled = xbmcaddon.Addon(control.addonInfo('id')).getSetting('RealDebridResolver_enabled')

    _rd_login = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_login')
    l_rd_login = xbmcaddon.Addon(control.addonInfo('id')).getSetting('RealDebridResolver_login')

    _rd_client = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_client_id')
    l_rd_client = xbmcaddon.Addon(control.addonInfo('id')).getSetting('RealDebridResolver_client_id')

    _rd_secret = xbmcaddon.Addon('script.module.resolveurl').getSetting('RealDebridResolver_client_secret')
    l_rd_secret = xbmcaddon.Addon(control.addonInfo('id')).getSetting('RealDebridResolver_client_secret')

    if _rd_enabled != l_rd_enabled:
        check_rd_now = True
        xbmcaddon.Addon(control.addonInfo('id')).setSetting('RealDebridResolver_enabled',  _rd_enabled)
    if _rd_login != l_rd_login:
        check_rd_now = True
        xbmcaddon.Addon(control.addonInfo('id')).setSetting('RealDebridResolver_login', _rd_login)
    if _rd_client != l_rd_client:
        check_rd_now = True
        xbmcaddon.Addon(control.addonInfo('id')).setSetting('RealDebridResolver_client_id', _rd_client)
    if _rd_secret != l_rd_secret:
        check_rd_now = True
        xbmcaddon.Addon(control.addonInfo('id')).setSetting('RealDebridResolver_client_secret', _rd_secret)
    #log_utils.log('@#@RD-CHECK: %s' % check_rd_now, log_utils.LOGNOTICE)
    if check_rd_now:
        get_account()
    else:
        cache.get(get_account, 24)
