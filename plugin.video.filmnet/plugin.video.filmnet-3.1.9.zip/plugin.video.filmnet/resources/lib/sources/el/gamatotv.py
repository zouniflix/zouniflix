# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['el']
        self.domains = ['gamatotv.co']
        self.base_link = 'https://www.gamatotv1.com/'
        self.search_link2 = 'search/{}/feed/rss2/'
        self.search_link = 'https://gmtsearch.com/?s={}&submit=%E2%96%B6%EF%B8%8E'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = self.__search([localtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and title != localtitle: url = self.__search([title] + source_utils.aliases_to_array(aliases),
                                                                    year)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = self.__search([localtvshowtitle] + source_utils.aliases_to_array(aliases), year)
            if not url and tvshowtitle != localtvshowtitle: url = self.__search(
                [tvshowtitle] + source_utils.aliases_to_array(aliases), year)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if not url:
                return
            url = [{'url': url, 'season': season, 'episode': episode}]
            return url
        except BaseException:
            return

    def __search(self, titles, year):
        try:
            query = [self.search_link.format(urllib.quote_plus(cleantitle.getsearch(i + ' ' + year))) for i in titles]
            # query = [urlparse.urljoin(self.base_link, i) for i in query]
            # print query
            t = [cleantitle.get(i) for i in set(titles) if i]

            for u in query:
                try:
                    r = client.request(u)
                    r = client.parseDOM(r, 'div', attrs={'id': r'post-\d+'})
                    for i in r:
                        r = dom_parser.parse_dom(i, 'h1')[0]
                        r = dom_parser.parse_dom(r, 'a')[0]
                        title = r.attrs['title']
                        tit = re.sub(r'(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', title, re.I)
                        if cleantitle.get(tit) not in t:
                            continue
                        y = re.findall(r'(\d{4})', title, re.DOTALL)[0]
                        if year == y:
                            # print r.attrs['href']
                            return r.attrs['href']
                except BaseException:
                    pass
            return
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            if type(url) is list:
                url = url[0]
                query, season, episode = url['url'], url['season'], url['episode']
                # query = urlparse.urljoin(self.base_link, query)
                data = client.request(query)
                # data = client.parseDOM(data, 'div', attrs={'class': 'xg_module_body xg_user_generated'})[0]
                pattern = r'>season\s*%1d\s*<(.+?)(?:text-decoration|</strong></p>)' % int(season)
                data1 = re.findall(pattern, data, re.DOTALL | re.I)
                if data1:
                    links = dom_parser2.parse_dom(data1, 'a')
                    links = [i.attrs['href'] for i in links if int(episode) == int(i.content)]
                else:
                    hdlr = 'S%02dE%02d' % (int(season), int(episode))
                    links = dom_parser2.parse_dom(data, 'a')
                    links = [i.attrs['href'] for i in links if hdlr.lower() in i.attrs['href'].lower()]

                print links
                for url in links:
                    if 'youtube' in url: raise Exception()
                    quality = 'SD'
                    lang, info = 'gr', 'SUB'
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if 'hdvid' in host: valid = True
                    if not valid: continue

                    sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                    'direct': False, 'debridonly': False})

            else:
                query = urlparse.urljoin(self.base_link, url)
                r = client.request(query)
                data = client.parseDOM(r, 'div', attrs={'class': 'post-content'})
                links = dom_parser.parse_dom(data, 'a')
                links += dom_parser.parse_dom(data, 'iframe', req='src')
                print links
                for i in links:
                    url = i[0]['href']
                    if 'youtube' in url:
                        continue
                    quality = 'SD'
                    lang, info = 'gr', 'SUB'
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if 'hdvid' in host:
                        valid = True
                    if 'cloudb' in host:
                        valid = True
                    if not valid:
                        continue

                    sources.append({'source': host, 'quality': quality, 'language': lang, 'url': url, 'info': info,
                                    'direct': False, 'debridonly': False})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        if 'cloudb' in url:
            data = client.request(url)
            from resources.lib.modules import jsunpack
            unpack = jsunpack.detect(data)
            if unpack:
                data = jsunpack.unpack(data)
                print data
                url = re.findall(r'sources:\["(.+?)"\]', data)[0]
        return url
