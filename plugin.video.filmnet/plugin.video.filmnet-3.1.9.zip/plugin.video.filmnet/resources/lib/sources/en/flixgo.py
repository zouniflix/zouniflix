# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import json
import re, urllib, urlparse, time

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2 as dom
from resources.lib.modules import workers


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['flixgo.co']
        self.base_link = 'https://flixgo.club/'
        self.search_link = 'engine/ajax/search.php'
        self.search_post = 'do=search&subaction=search&story=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def search(self, title, hdlr, imdb):
        try:
            post = self.search_post % (urllib.quote_plus(title), hdlr)
            r = client.request(self.base_link, post=post)
            r = dom.parse_dom(r, 'div', {'class': 'post'})
            r = [(dom.parse_dom(i, 'a', req='href'),
                  dom.parse_dom(i, 'src', req=['href', 'target', 'rel'])) for i in r]
            r = [(i[0][0].attrs['href'], i[0][0].content, i[1][0].attrs['href']) for i in r if i[0] and i[1]]
            if len(hdlr) == 4:
                r = [(i[0], i[1]) for i in r if imdb in i[2] and hdlr.lower() in i[1].lower()]
            else:
                r = [(i[0], i[1]) for i in r if
                     cleantitle.get(title) in cleantitle.get(i[1]) and hdlr.lower() in i[1].lower()]
            return r
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            #<input type="hidden" name="user_hash"
            hash = client.request(self.base_link)
            #hash = client.parseDOM(hash, 'input', attrs={'name': 'user_hash'}, ret='value')[0]
            hash = re.findall('''dle_login_hash\s*=\s*['"](.+?)['"]''', hash, re.DOTALL)[0]
            plink = urlparse.urljoin(self.base_link, self.search_link)
            post = 'query={0}&user_hash={1}'.format(data['imdb'], hash)
            r = client.request(plink, post=post)

            link = client.parseDOM(r, 'a', ret='href')[0]
            link = urlparse.urljoin(self.base_link, link) if link.startswith('/') else link

            r = client.request(link)

            if 'tvshowtitle' in data:
                seasons = client.parseDOM(r, 'span', attrs={'id': 'episode'})
                slinks = [dom.parse_dom(i, 'a', req='href')[0] for i in seasons]
                slink = [i.attrs['href'] for i in slinks if i.content == 'S{0}'.format(data['season'])][0]
                slink = urlparse.urljoin(self.base_link, slink) if slink.startswith('/') else slink

                r = client.request(slink)
                infos = re.findall('Playerjs\((.+?)\);', r, re.DOTALL)[0]
                infos = re.findall('file:\s*(\[.+?\])\}', infos, re.DOTALL)[0]
                infos = json.loads(infos)
                ep = 'Episode {}'.format(str(data['episode']))
                link = [i['file'] for i in infos if ep in i['title']][0]

            else:
                infos = re.findall('Playerjs\((.+?)\);', r, re.DOTALL)[0]
                infos = json.loads(infos)['file']
                link = re.findall('(https://.+?$)', infos.split(',')[0])[0]

            sources.append({'source': 'GVIDEO', 'quality': '720p', 'language': 'en', 'url': link,
                            'direct': True, 'debridonly': False})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url