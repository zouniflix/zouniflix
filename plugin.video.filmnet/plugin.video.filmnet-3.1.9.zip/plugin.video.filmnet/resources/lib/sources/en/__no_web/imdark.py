# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['imdark.com']
        self.base_link = 'http://imdark.com'
        self.search_link = '?s=%s&darkestsearch=%s&_wp_http_referer=%s&quality=&genre=&year=&lang=en'
        self.ajax_link = '/wp-admin/admin-ajax.php'
       

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return None

    def sources(self, url, hostDict, locDict):
        sources = []

        try:
            if url is None: return sources
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['title']
            y = data['year']
            tit = title +' '+ y
            r = client.request(self.base_link)
            dark = client.parseDOM(r, 'input', ret='value', attrs={'name':'darkestsearch'})[0]
            wp_ref = client.parseDOM(r, 'input', ret='value', attrs={'name': '_wp_http_referer'})[0]
            query = self.search_link % (urllib.quote_plus(tit), dark, wp_ref)
            query = urlparse.urljoin(self.base_link, query)
            headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36'}
            result = client.request(query, headers=headers)
            r = client.parseDOM(result, 'div', attrs={'id':'showList'})
            r = client.parseDOM(r, 'h4')[0]
            r = dom_parser2.parse_dom(r, 'a', req='href')
            r = [i.attrs['href'] for i in r if cleantitle.get(title) == cleantitle.get(i.content) and y in i.content]

            url = r[0]
            result = client.request(url)
            try:
                data = re.findall('''var url\s*=.+?nonce\s*=\s*['"](\w+)['"]\s*.+?var\s*tipi\s*=\s*(\d+)''', result, re.DOTALL)[0]

                post = {'action': 'getitsufiplaying',
                        'tipi': data[1],
                        'jhinga': data[0]}
                r = client.request(urlparse.urljoin(self.base_link,self.ajax_link), post=post)
                r = re.findall(r'''\{['"]src['"]:['"]([^"']+)['"].+?data-res['"]:['"](\d+)['"]\}''', r, re.DOTALL)
            except BaseException:
                r = re.findall(r'''\{['"]src['"]:['"]([^"']+)['"].+?data-res['"]:['"](\d+)['"]\}''',result,re.DOTALL)

            for i in r:
                try:
                    sources.append({'source': 'CDN', 'quality': source_utils.label_to_quality(i[1]), 'language': 'en',
                                    'url': i[0].replace('\/','/')+'|Referer=%s'% url, 'direct': True, 'debridonly': False})
                except BaseException:
                    pass

            return sources
        except Exception as e:
            return sources

    def resolve(self, url):
        return url