# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, base64, time

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from resources.lib.modules import debrid
from resources.lib.modules import workers

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ganool.unblocked.vet']
        self.base_link = 'https://ganool.unblocked.gdn'
        self.search_link = 'search?q=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            q = urlparse.urljoin(self.base_link, (self.search_link % urllib.quote_plus(cleantitle.getsearch(title))))
            r = client.request(q)
            r = client.parseDOM(r, 'div', attrs={'class':'panel panel-default info-box indexing'})
            posts = [(dom_parser2.parse_dom(i, 'h4'), re.findall('\d{4}', i, re.DOTALL)[0]) for i in r]
            posts = [(dom_parser2.parse_dom(i[0], 'a'), i[1]) for i in posts if i]
            posts = [(i[0][0].attrs['href'], i[0][0].content, i[1]) for i in posts if i]
            posts = [i[0] for i in posts if (cleantitle.get_simple(i[1]) == cleantitle.get(title) and year == i[2])]
            if len(posts) == 1: return posts[0]
            elif len(posts) > 1:
                for i in posts:
                    try:
                        im = client.request(urlparse.urljoin(self.base_link, i))
                        if imdb in im:
                            return i
                        else: continue
                    except BaseException:
                        pass
            else: return
        except BaseException:
            return


    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = urlparse.urljoin(self.base_link, (self.search_link % urllib.quote_plus(cleantitle.getsearch(tvshowtitle))))
            r = client.request(url)
            posts = dom_parser2.parse_dom(r, 'h4')
            posts = [dom_parser2.parse_dom(i, 'a') for i in posts if i]
            posts = [(i[0].attrs['href'], i[0].content) for i in posts if i]
            posts = [i[0] for i in posts if cleantitle.get(i[1]) == cleantitle.get(tvshowtitle)]
            url = posts[0]
            return url
        except BaseException:
            return


    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            url = url[:-1] if url.endswith('/') else url
            t = re.sub('/tv-show/', '', url)
            url = self.base_link
            url += '/e/%s-s%d-e%d' % (t, int(season), int(episode))
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []

            if url is None: return self._sources
            if debrid.status() == False: raise Exception()

            url = urlparse.urljoin(self.base_link, url)

            r = client.request(url)

            posts = dom_parser2.parse_dom(r, 'span', attrs={'class':'list-group-item'})
            self.hostDict = hostDict + hostprDict

            threads = []

            for i in posts: threads.append(workers.Thread(self._get_sources, i))
            [i.start() for i in threads]
            [i.join() for i in threads]

            while any(x.is_alive() for x in threads): time.sleep(0.1)

            return self._sources
        except BaseException:
            return self._sources
            
    def _get_sources(self, item):
        try:
            n = client.parseDOM(item.content, 'span', attrs={'class':'badge'})
            name = '.'.join(n)
            url = dom_parser2.parse_dom(item.content, 'a')[1]
            url, host = url.attrs['href'], url.content
            if any(x in url.lower() for x in ['.rar.', '.zip.', '.iso.']) or any(
                    url.lower().endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()

            if any(x in url.lower() for x in ['youtube', 'sample', 'trailer']): raise Exception()
            valid, host = source_utils.is_host_valid(host, self.hostDict)
            if not valid: raise Exception()
            info = []
            quality, info2 = source_utils.get_release_quality(name, url)
            try:
                size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|gb|MB|mb))', name)[0]
                div = 1 if size.endswith(('GB', 'GiB')) else 1024
                size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                size = '%.2f GB' % size
                info.append(size)
            except BaseException:
                pass
            info = ' | '.join(info)
            host = client.replaceHTMLCodes(host)
            host = host.encode('utf-8')
            self._sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True})
        except BaseException:
            pass

    def resolve(self, url):
        if 'linkgen' in url:
            url = client.request(url)
            url = client.parseDOM(url, 'div', attrs={'class':'align-center'})[0]
            url = client.parseDOM(url, 'a', ret='href')[0]
            return url
        else:
            return url