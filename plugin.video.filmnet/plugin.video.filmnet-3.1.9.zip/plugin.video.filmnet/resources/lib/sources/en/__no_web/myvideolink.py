# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, os, time

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import workers


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['iwantmyshow.tk', 'myvideolinks.net']
        self.base_link = 'http://iwantmyshow.tk/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []
            #<form role="search" method="get" id="top-searchform" action="http://iwantmyshow.tk/1111/">

            if url is None: return self._sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s S%02dE%02d' % (
            data['tvshowtitle'], int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s %s' % (
            data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            r = client.request(self.base_link, output='extended')
            search_link = client.parseDOM(r[0], 'iframe', ret='src')[0]
            url = '%s/?s=%s' % (search_link, urllib.quote_plus(query))

            r = client.request(url)
            posts = client.parseDOM(r, 'article')
            if not posts and 'tvshowtitle' in data:
                url = '%s/?s=%s' % (search_link,   urllib.quote_plus(cleantitle.geturl(title +' '+ hdlr)))
                r = client.request(url, headers={'User-Agent': client.agent()})
                posts += client.parseDOM(r, 'article')
                url = '%s/?s=%s' % (search_link,  urllib.quote_plus(cleantitle.geturl(title)))
                r = client.request(url, headers={'User-Agent': client.agent()})
                posts += client.parseDOM(r, 'article')

            if not posts: return self._sources
            items = []
            for post in posts:
                if not data['imdb'] in post: continue
                try:
                    t = client.parseDOM(post, 'a', ret='title')[0]
                    u = client.parseDOM(post, 'a', ret='href')[0]
                    s = re.search('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', post)
                    s = s.groups()[0] if s else '0'
                    items += [(t, u, s, post)]
                except BaseException:
                    pass

                threads = []
                for url in items: threads.append(
                    workers.Thread(self._get_source, url, hdlr, hostDict, hostprDict))
                [i.start() for i in threads]

                alive = [x for x in threads if x.is_alive() is True]
                while alive:
                    alive = [x for x in threads if x.is_alive() is True]
                    time.sleep(0.1)

            return self._sources
        except BaseException:
            return self._sources

    def _get_source(self, url, hdlr, hostDict, hostprDict):
        try:
            title, url, size, data = url[0], url[1], url[2], url[3]
            r = client.request(url, headers={'User-Agent': client.agent()})
            name = client.parseDOM(r, 'h4')[0]
            if 'S' in hdlr:
                regex = '<p>\s*%s\s*</p>(.+?)</ul>' % hdlr
                data = re.search(regex, r, re.DOTALL).groups()[0]
                frames = client.parseDOM(data, 'a', ret='href')

            else:
                data = client.parseDOM(r, 'div', attrs={'class': 'entry-content'})[0]
                data = client.parseDOM(data, 'ul')[0]
                frames = client.parseDOM(data, 'a', ret='href')

            quality, info = source_utils.get_release_quality(name, title)

            size_string = re.search('<strong>Size</strong>:(.+?)<strong>', r)
            if size_string:
                try:
                    size = \
                        re.findall('((?:\d+\.\d+|\d+\,\d+|\d+) (?:GB|GiB|MB|MiB))', size_string.groups()[0])[0]
                    div = 1 if size.endswith(('GB', 'GiB')) else 1024
                    size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                    size = '%.2f GB' % size
                    info.append(size)
                except BaseException:
                    pass

            info = ' | '.join(info)
            for url in frames:
                try:
                    if any(x in url for x in ['.rar.', '.zip.', '.iso.']) or any(
                            url.endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                    if host in hostDict:
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')
                        if quality == 'SD': quality, info2 = source_utils.get_release_quality(name, url)
                        self._sources.append(
                            {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                             'direct': False,
                             'debridonly': False})
                    elif host in hostprDict:
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')
                        if quality == 'SD': quality, info2 = source_utils.get_release_quality(name, url)
                        self._sources.append(
                            {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                             'direct': False,
                             'debridonly': True})
                    else:
                        continue
                except BaseException:
                    pass
        except BaseException:
            pass

    def resolve(self, url):
        try:
            return url
        except BaseException:
            return