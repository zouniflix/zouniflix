# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib, urlparse, re

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from resources.lib.modules import unjuice


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['theflametv.com']
        self.base_link = ''
        self.search_link = 'search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'localtitle': localtitle, 'title': title, 'aliases': aliases,'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            sources = []

            if url is None: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '%s' % data['tvshowtitle'] if 'tvshowtitle' in data else '%s' % data['title']
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)

            r = client.request(url, timeout=30)
            posts = client.parseDOM(r, 'item')

            for post in posts:
                try:
                    name = client.parseDOM(post, 'title')[0]
                    name = client.replaceHTMLCodes(name)
                    link = client.parseDOM(post, 'link')[0]

                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, re.I)
                    t = re.findall('\w+', cleantitle.get(t))[0]

                    if not t == cleantitle.get(title): raise Exception()

                    if 'tv-shows' in link:
                        r = client.request(link)
                        links = client.parseDOM(r, 'a', ret='href')
                        links = [i for i in links if hdlr.lower() in i.lower()]

                    else:
                        r = client.request(link)
                        links = client.parseDOM(r, 'div', attrs={'role':'main'})
                        links = client.parseDOM(links, 'a', ret='href', attrs={'target':'_blank'})
                        links = [i for i in links if (hdlr in i and '.mkv' in i and not 'addtoany' in i)]

                    for url in links:
                        if any(x in url for x in ['youtube', 'facebook', 'twitter', '.rar', '.zip', '.iso']): continue

                        quality, info = source_utils.get_release_quality(url, url)
                        info = ' | '.join(info)
                        url = client.replaceHTMLCodes(url)
                        url = url.encode('utf-8')

                        sources.append({'source': 'DL', 'quality': quality, 'language': 'en',
                                        'url': url, 'info': info, 'direct': True, 'debridonly': False})

                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url