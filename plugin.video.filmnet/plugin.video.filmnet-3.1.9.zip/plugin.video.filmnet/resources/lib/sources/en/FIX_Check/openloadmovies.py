# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urllib
import urlparse
import json

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from resources.lib.modules import cfscrape



class source:
    def __init__(self):
        self.priority = 1
        self.direct = 1
        self.language = ['en']
        self.domains = [
            'pubfilmonline.net',
            'getmypopcornnow.xyz',
            'openloadmovies.tv']
        self.base_link = 'https://openloadmovies.ac/'
        self.post_link = '/wp-admin/admin-ajax.php'
        self.search_link = '/?s=%s'
        self.search2_link = 'search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {
                'imdb': imdb,
                'tvdb': tvdb,
                'tvshowtitle': tvshowtitle,
                'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '')
                         for i in data])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            hdlr = '%dx%d' % (int(data['season']), int(
                data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '%s %s' % (data['title'], data['year']) if not 'tvshowtitle' in data else data['tvshowtitle']
            query = re.sub(r'(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            url = urlparse.urljoin(self.base_link, self.search2_link % urllib.quote_plus(query))
            #r = client.request(url)
            scraper = cfscrape.create_scraper()
            r = scraper.get(url).content

            posts = client.parseDOM(r, 'item')

            hostDict = hostprDict + hostDict

            for post in posts:
                tit = client.parseDOM(post, 'title')[0]

                t = re.sub(
                    r'(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)',
                    '',
                    tit,
                    flags=re.I)

                if not cleantitle.get(t) == cleantitle.get(title):
                    raise Exception()

                if not 'tvshowtitle' in data:
                    try:
                        y = re.findall(
                            r'(?:\.|\(|\[|\s*|)(S\d+E\d+|S\d+)(?:\.|\)|\]|\s*|)', tit, re.I)[-1].upper()
                    except BaseException:
                        y = re.findall(
                            r'(?:\.|\(|\[|\s*|)(\d{4})(?:\.|\)|\]|\s*|)',
                            tit,
                            re.I)[0].upper()

                    if hdlr == y:
                        link = client.parseDOM(post, 'link')[0]

                else:
                    link = client.parseDOM(post, 'link')[0]
                    link = link.replace('tvserie', 'episode') #https://openloadmovies.bz/episodes/game-of-thrones-4x6/
                    link = link[:-1] if link.endswith('/') else link
                    link = '{0}-{1}'.format(link, hdlr)

                r = scraper.get(link).content
                headers = {'User-Agent': client.agent(),
                           'Referer': url, 'X-Requested-With': 'XMLHttpRequest',
                           'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}

                post_link = '%swp-admin/admin-ajax.php' % self.base_link
                post_id = client.parseDOM(r, 'li', ret='data-post')[0]
                post_data = 'action=doo_player_ajax&post={0}&nume=1&type=movie'.format(post_id)

                #r = client.request(post_link, post=post_data, headers=headers)
                r = scraper.post(post_link, data=post_data, headers=headers).content

                try:
                    links = re.findall(r'sources:\s*([^\]]+])', r)[0]
                    links = json.loads(links)
                    for link in links:
                        quality, info = source_utils.get_release_quality(
                            link['label'], link['file'])
                        sources.append({'source': 'CDN',
                                        'quality': quality,
                                        'language': 'en',
                                        'url': link['file'],
                                        'direct': True,
                                        'debridonly': False})
                except BaseException:
                    link = dom_parser2.parse_dom(r, 'iframe', req='src')[0]
                    frame = link.attrs['src']

                    id = re.search(r'\?id=(\d+)', frame)
                    if id:
                        id = id.groups()[0]
                    else:
                        raise Exception()
                    #r = client.request(frame, headers=headers)
                    r = scraper.get(frame)

                    netloc = '%s://%s/' % (urlparse.urlparse(frame).scheme,
                                           urlparse.urlparse(frame).netloc)

                    js = re.findall(
                        r'''<script\s*type=['"]text/javascript['"]\s*src=['"]([^'"]+)''', r)[-1]
                    js = urlparse.urljoin(netloc, js)

                    #r = client.request(js, headers=headers)
                    r = scraper.get(js)

                    link = re.findall(
                        r'''navigator\.userAgent\.indexOf(?:[^)]+).+?w\s*=\s*"([^'"]+)''', r)[0]
                    link = '%s/caches/get?id=%s' % (link, id)  # api/v1/caches/get
                    #r = client.request(link, headers=headers)
                    r = scraper.get(link)

                    links = json.loads(r)['videos_audio']
                    for link in links:
                        try:
                            quality, info = source_utils.get_release_quality(
                                link['label'], link['file'])
                            host = re.findall(
                                r'(?:https|http):\/\/([^\.]+)', link['file'])[0]
                            sources.append({'source': host,
                                            'quality': quality,
                                            'language': 'en',
                                            'url': link['file'],
                                            'direct': True,
                                            'debridonly': False})
                        except BaseException:
                            pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
