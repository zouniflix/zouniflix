# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import urllib
import urlparse
import json

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2
from resources.lib.modules import source_utils
from resources.lib.modules import workers


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['two-movies.name']
        self.base_link = 'https://www1.two-movies.name'
        self.search_link = 'https://www1.two-movies.name/search/?search_query=%s&criteria=all'  # imdb

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {
                'imdb': imdb,
                'title': title,
                'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {
                'imdb': imdb,
                'tvdb': tvdb,
                'tvshowtitle': tvshowtitle,
                'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '')
                         for i in data])

            query = self.search_link % data['imdb']
            post = client.request(query, XHR=True, output='geturl')
            if 'tvshowtitle' in data:
                epi_link = '%s/%01d/%01d' % (
                    post.replace('tv_show', 'episode'), int(data['season']), int(data['episode']))
                post = epi_link
            else:
                post = post
            r = client.request(post)
            frame = client.parseDOM(r, 'table', attrs={'class': 'striped'})[0]
            frame = client.parseDOM(frame, 'a', ret='href')[0]
            frame = urlparse.urljoin(self.base_link, frame) if frame.startswith('/') else frame
            r = client.request(frame)
            hash = re.findall('''var\s*hash\s*=\s*['"]([^'"]+)''', r, re.MULTILINE)[0]#var hash = '9fafa6c0c1771b38a1c72a5bd893c503';
            pdata = 'hash=%s&confirm_continue=I+understand%s+I+want+to+continue' % (str(hash), '%2C')
            data = client.request(frame, post=pdata, referer=frame)
            frames = re.compile('''vlink.+?title=['"]([^'"]+).+?href=['"]([^'"]+).+?onclick.+?>(.+?)</a''', re.M | re.DOTALL).findall(data.replace('\n', ''))

            for name, link, host in frames:
                try:
                    host = host.replace('\xc5\x8d', 'o').replace('\xc4\x93', 'e').replace('\xc4\x81', 'a').replace('\xc4\xab', 'i')#.replace('\u014d', 'o').replace('\u0113', 'e').replace('\u0101', 'a').replace('\u012b', 'i')
                    host = host.replace('\xc5\xab', 'u')
                    valid, host = source_utils.is_host_valid(host, hostDict)
                    if not valid:
                        raise Exception()
                    quality, info = source_utils.get_release_quality(name, name)
                    if quality == '4K':
                        quality = '1080p'
                    elif quality == '1080p' and not 'openload' in host:
                        quality = '720p'
                    info = ' | '.join(info)
                    link = urlparse.urljoin(self.base_link, link) if link.startswith('/') else link

                    sources.append({'source': host,
                                    'quality': quality,
                                    'language': 'en',
                                    'url': link,
                                    'info': info,
                                    'direct': False,
                                    'debridonly': False})
                except BaseException:
                    pass
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        try:
            if self.base_link in url:
                data = client.request(url, referer=self.base_link)
                link = client.parseDOM(data, 'iframe', ret='src')[0]
                link = 'https:' + link if link.startswith('//') else link
            else:
                link = url
            return link
        except BaseException:
            return