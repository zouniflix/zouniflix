# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''

import urllib, urlparse, re

from resources.lib.modules import client
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['videospider.in']
        self.base_link = 'https://videospider.in/'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            aliases.append({'country': 'us', 'title': tvshowtitle})
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []

        try:
            if not url:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            imdb = data['imdb']
            season = data['season'] if 'tvshowtitle' in data else '0'

            try:
                get_ip = client.request('https://whatismyipaddress.com')
                get_ip = re.findall('''/ip/(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})['"]''', get_ip, re.DOTALL)[0]
            except IndexError:
                return sources

            api = 'Nc56mz5vlA9TPZRA'
            secret = 'za0gog6495v89ezc6mu5wvscpi17p7'

            ticket = '{base}getticket.php?key={api}&secret_key={secret}&video_id={imdb}&s={season}&ip={ip}'.format(
                base=self.base_link, api=api, secret=secret, imdb=imdb, season=season, ip=get_ip)
            ticket = client.request(ticket)

            if 'tvshowtitle' in data:
                url = 'https://videospider.stream/getvideo?key={api}&video_id={imdb}&tv=1&s={season}&e={episode}&ticket={ticket}'.format(
                    api=api, imdb=imdb, season=season, episode=data['episode'], ticket=ticket)
            else:
                url = 'https://videospider.stream/getvideo?key={api}&video_id={imdb}&ticket={ticket}'.format(
                    api=api, imdb=imdb, ticket=ticket)

            url = client.request(url, output='geturl')
            valid, host = source_utils.is_host_valid(url, hostDict)
            if not valid: raise Exception()
            data = client.request(url)
            quality = client.parseDOM(data, 'meta', ret='content')[0]
            quality, info = source_utils.get_release_quality(quality, None)
            info = ' | '.join(info)
            sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False, 'info': info})

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url


