# -*- coding: utf-8 -*-

"""
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import re
import urllib
import urlparse
import json
import binascii
import requests

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2
from resources.lib.modules import source_utils
from resources.lib.modules.jsunwise import JsUnwiser


class source:
    def __init__(self):

        self.priority = 1
        self.language = ['en']
        self.domains = ['pubfilm.ru', 'pubfilm.is', 'pubfilm.to', 'pubfilm.su']
        self.base_link = 'https://www.pubfilm.su'
        self.search_link = '?s=%s'
        self.cookie_link = urlparse.urljoin(
            self.base_link, 'wp-content/themes/sahifa-child/ccookie.js?v=1.001')

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            return self.__search(
                [title] + source_utils.aliases_to_array(aliases), year)
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {
                'tvshowtitle': tvshowtitle,
                'aliases': aliases,
                'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '')
                         for i in data])
            tvshowtitle = data['tvshowtitle']
            aliases = source_utils.aliases_to_array(eval(data['aliases']))
            url = self.__search([tvshowtitle] + aliases, data['year'], season)
            url = '%s&episode=%s' % (url, episode)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None:
                return sources
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '')
                         for i in data])
            siteq = data['quality']
            url = data['url']
            content = 'episode' if 'episode' in url else 'movie'
            result = client.request(url)
            url = dom_parser2.parse_dom(
                result, 'a', {
                    'class': [
                        'abutton', 'orange', 'medium']})
            if content == 'movie':
                urls = [
                    i.attrs['href'] if i.attrs['href'].startswith('https:') else 'https:%s' %
                                                                                 i.attrs['href'] for i in url if
                    'server' in i.content.lower()]
            else:
                episode = data['episode']
                urls = [
                    i.attrs['href'] if i.attrs['href'].startswith('https:') else 'https:%s' %
                                                                                 i.attrs['href'] for i in url if
                    'episode %s' %
                    episode in i.content.lower()]

            for url in urls:
                result = client.request(url)
                result = JsUnwiser().unwiseAll(result)
                matches = re.findall(
                    r'replace\(pathname,\s*"([^"]+).*?var\s+(\w+)=\'([^\']+).*?token="\+\2',
                    result,
                    re.DOTALL)[0]
                url = url.replace(
                    'get', matches[0]) + '&token={}'.format(matches[2])
                result = client.request(url)
                result = JsUnwiser().unwiseAll(result)
                result = re.findall(r'JSON.parse\(\'([^\']+)', result)[0]
                result = json.loads(result)
                sitesub = result['info']['sub']
                hosterurls = result['info']['hosterurls']

                for hosterurl in hosterurls:
                    try:
                        if hosterurl['reason'] == 'can not access':
                            raise Exception()
                        try:
                            sub = hosterurl['sub']
                        except BaseException:
                            sub = sitesub
                        if sub and len(sub) > 0:
                            sub = sub if 'http' in sub else 'https://player.pubfilm.su/sub/' + sub
                        else:
                            sub = None

                        uri = hosterurl['source']
                        quali = None

                        if not isinstance(uri, basestring):
                            for item in uri:
                                if 'file' not in item:
                                    continue
                                quali, info = source_utils.get_release_quality(item['label'])
                                if quali == 'SD':
                                    try:
                                        quali, info = source_utils.get_release_quality(item['default'])
                                    except:
                                        pass
                                quali = siteq if quali == 'SD' else quali

                                uri = item['file']
                                uri = uri if 'http' in uri else 'https:' + uri
                                valid, hoster = source_utils.is_host_valid(uri, hostDict)
                                direct = False
                                if not valid:
                                    direct = True
                                    hoster = 'CDN'
                                sources.append({'source': hoster,
                                                'quality': quali,
                                                'language': 'en',
                                                'url': uri + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36&Adaptive=False'
                                                   ,
                                                'direct': direct,
                                                'sub': sub,
                                                'debridonly': False})


                        else:
                            url = uri if uri.startswith('http') else 'https:{0}'.format(uri)
                            if 'vidcloud.icu' in url:
                                _slinks = []
                                if 'vidcloud.icu' in url:
                                    urls = []
                                    urls = source_utils.getVidcloudLink(url)
                                    if urls:
                                        for uri in urls:
                                            _slinks.append((uri[0], uri[1]))
                                    for url in _slinks:
                                        quality = url[1]
                                        url = url[0]
                                        url = client.replaceHTMLCodes(url)
                                        url = url.encode('utf-8')
                                        url = re.sub('(#caption=[^$]+)', '', url)
                                        valid, host = source_utils.is_host_valid(url, hostDict)
                                        direct = False if valid else True
                                        host = client.replaceHTMLCodes(host)
                                        host = host.encode('utf-8')
                                        sources.append({'source': host,
                                                        'quality': quality,
                                                        'language': 'en',
                                                        'url': url,
                                                        'sub': sub,
                                                        'direct': direct,
                                                        'debridonly': False})
                    except BaseException:
                        pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url

    def __search(self, titles, year, season='0'):
        try:
            url = urlparse.urljoin(
                self.base_link,
                self.search_link) % (urllib.quote_plus(
                titles[0]))

            r = client.request(self.base_link, output='extended')
            cookie = r[4]
            headers = r[3]
            result = r[0]
            cookie += ';%s' % self.__get_cookie()
            headers['Cookie'] = cookie
            result = client.request(url, headers=headers, cookie=cookie)

            r = client.parseDOM(result, 'div', attrs={'class': 'recent-item'})
            r = [
                (dom_parser2.parse_dom(
                    i, 'a', req='href'), dom_parser2.parse_dom(
                    i, 'div', {
                        'class': 'f_tag'})) for i in r]
            r = [(i[1][0].content if i[1] else 'SD', i[0]
            [-1].attrs['href'], i[0][-1].content) for i in r]
            if season != '0':
                season = 'Season %s' % season
                ret = [({'quality': 'SD', 'url': i[1]}) for i in r if season in i[2]
                       and cleantitle.get(titles[0]) in cleantitle.get(i[2])][0]
            else:
                ret = [({'quality': i[0], 'url': i[1]}) for i in r if year in i[2]
                       and cleantitle.get(titles[0]) in cleantitle.get(i[2])][0]
            return urllib.urlencode(ret)
        except BaseException:
            return

    def __get_cookie(self):
        def getc(z07):
            z82 = '\x5c'
            while len(z82) < 200:
                z82 += z82 + z82 + z82 + z82 + z82
            z84 = ''
            z5d = 0
            while True:
                zff = z07.find('\x5e', z5d)
                if zff == -1:
                    return z84 + z07[z5d:]
                else:
                    z84 += z07[z5d:zff]
                    zd1 = 2
                    z21 = z07[zff + 1]
                    while True:
                        zab = z07[zff + zd1]
                        zd1 += 1
                        if '\x39' < zab < '\x30':
                            break
                        else:
                            z21 += zab
                    z21 = int(z21)
                    z5d = zff + zd1 - 1
                    while True:
                        z14 = len(z82) if z21 > len(z82) else z21
                        z21 -= z14
                        z84 += z82[0:z14]
                        if z21 <= len(z82):
                            break

            return z84

        def cclean(z84):
            cvar, cdata, formula = re.findall(
                r"var\s*([^\s]+)\s*=\s*unescape\('([^']+).+?\1\s*=\s*([^;]+)", z84)[0]
            cdata = urllib.unquote(cdata)
            regex1 = r'^\([^(]+\((\d+)\)>(\d+)\?[^(]+\(\((\d+)[^(]+\((\d+)\)\)%(\d+)[^(]+\((\d+)\)\)\+*'
            regex2 = r'^{}\.substr\((\d+),(\d+)\)\+*'.format(cvar)
            ckdata = ''
            while len(formula) > 0:
                regex = regex1 if formula.startswith('(') else regex2
                match = re.findall(regex, formula)[0]
                if len(match) == 6:
                    if ord(cdata[int(match[0])]) > int(match[1]):
                        ckdata += chr((int(match[2]) +
                                       ord(cdata[int(match[3])])) %
                                      int(match[4]))
                    else:
                        ckdata += cdata[int(match[5])]
                else:
                    ckdata += cdata[int(match[0]):int(match[0]) + int(match[1])]
                formula = re.sub(regex, '', formula, 1)
            return ckdata

        jsurl = self.cookie_link
        js = client.request(jsurl)
        js = urllib.unquote(
            re.findall(
                r"var\s*[^\s]+\s*=\s*unescape\('([^']+)", js)[0])
        js = getc(js)
        while 'substr' in js:
            js = cclean(js)
        js = urllib.unquote(re.findall(r"{var\s[^\s]+\s*=\s*'([^']+)", js)[0])
        item, value = re.findall(
            r'a\(\n?"([^"]+)"\n?,\n?"([^"]+)', js, re.IGNORECASE)[0]
        item = binascii.unhexlify(item.replace('\\x', ''))
        value = binascii.unhexlify(value.replace('\\x', ''))
        cookie = '{}={}'.format(item, value)
        return cookie

    def get_spath(self, server0, server1, rj, uri):
        try:
            sfile = rj['datas'][0]['file']
            spath = 'https://{}/0/{}'.format(server0, sfile)
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36',
                'Accept': '*/*',
                'Referer': uri,
                'Origin': 'https://hydrax.net'
                }
            s = requests.Session()
            s.headers.update(headers)
            try:
                data = s.get(spath)
                if data.status_code <> 200:
                    raise Exception()
                else:
                    data = data.content

            except BaseException:
                if server1:
                    spath = 'https://{}/1/{}'.format(server1, sfile)
                    data = s.get(spath)

                else:
                    return ''
            data = json.loads(data)
            spath = data['url']
            return spath
        except Exception as e:
            print e
            return None
