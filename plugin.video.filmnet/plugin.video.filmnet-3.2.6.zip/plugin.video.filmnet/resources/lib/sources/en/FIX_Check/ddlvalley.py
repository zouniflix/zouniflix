# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, time, os, datetime, random

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import dom_parser2
from resources.lib.modules import workers
from resources.lib.modules import source_utils
from cloudscraper2 import CloudScraper as cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ddlvalley.me']
        self.base_link = 'http://www.ddlvalley.me/'
        self.search_link = 'search/%s/'
        self.search_link1 = '?s=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            clean_title = cleantitle.geturl(title).replace('-', '+')
            url = urlparse.urljoin(self.base_link, self.search_link % clean_title)
            url = {'url': url, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        self._sources = []
        try:
            if url is None:
                return self._sources
            if debrid.status() is False:
                raise Exception()

            data = urlparse.parse_qs(url)

            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            self.show = True if 'tvshowtitle' in data else False
            self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data[
                'year']
            query = '%s' % (data['tvshowtitle']) if \
                'tvshowtitle' in data else '%s %s' % (data['title'], data['year'])
            self.query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)
            self.headers = {}
            self.headers['User-Agent'] = client.randomagent()
            self.headers['Referer'] = urlparse.urljoin(self.base_link, self.search_link1 % urllib.quote_plus(self.query))
            self.headers.update({'Upgrade-Insecure-Requests': '1'})

            plinks = []
            self.scraper = cfscrape.create_scraper()
            self.result = self.scraper.get(url, headers=self.scraper).text
            _pages = re.search('''<link\s*rel="next"\s*href="''', self.result)

            if _pages:
                for i in range(2, 4):
                    try:
                        page = url + 'page/%01d' % int(i)
                        plinks.append(page)
                    except BaseException:
                        pass

            pthreads = []
            for plink in plinks:
                pthreads.append(workers.Thread(self.result_in_range, plink))
            [i.start() for i in pthreads]
            [i.join() for i in pthreads]

            items = dom_parser2.parse_dom(self.result, 'h2')
            items = [dom_parser2.parse_dom(i.content, 'a', req=['href', 'rel', 'data-wpel-link']) for i in items]
            items = [(i[0].content, i[0].attrs['href']) for i in items]
            items = [(i[0], i[1]) for i in items if cleantitle.get_simple(title.lower()) in cleantitle.get_simple(
                i[1].lower()) and cleantitle.get_simple(self.hdlr.lower()) in cleantitle.get_simple(i[1].lower())]
            threads = []
            for i in items: threads.append(workers.Thread(self._get_sources, i[0], i[1], hostDict, hostprDict))
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, name, url, hostDict, hostprDict):
        try:
            hostDict = hostDict + hostprDict
            name = client.replaceHTMLCodes(name)
            r = client.request(url)
            links = dom_parser2.parse_dom(r, 'a', req=['href', 'rel', 'data-wpel-link', 'target'])
            links = [i.attrs['href'] for i in links]
            if self.show: links = [i for i in links if self.hdlr.lower() in i.lower()]

            for url in links:
                try:
                    if any(x in url for x in ['.rar.', '.zip.', '.iso.']) or any(
                            url.endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if not valid: continue
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')

                    quality, info = source_utils.get_release_quality(name, url)
                    info = ' | '.join(info)

                    self._sources.append({'source': host, 'quality': quality, 'language': 'en',
                                          'url': url, 'info': info, 'direct': False, 'debridonly': True})
                except BaseException:
                    pass
        except BaseException:
            pass

    def result_in_range(self, url):
        try:
            for u in range(0, 10):
                result = self.scraper.get(url, headers=self.scraper).text
                if result and not '403 Forbidden':
                    self.result += result
                    break
            if not self.result:
                return None

            return self.result
        except BaseException:
            return self.result

    def resolve(self, url):
        return url
