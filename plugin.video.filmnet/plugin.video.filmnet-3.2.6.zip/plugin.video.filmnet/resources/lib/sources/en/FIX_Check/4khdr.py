# -*- coding: utf-8 -*-
##FILES DONT EXIST##CHECK LATER# 17-05-2018#
'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['4k-hdr.org']
        self.base_link = 'https://4k-hdr.org'
        self.post_link = '/index.php?do=search'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources

            if debrid.status() is False: raise Exception()

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['title'].replace(':','').lower()
            year = data['year']

            query = '%s %s' % (data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = urlparse.urljoin(self.base_link, self.post_link)

            post = 'do=search&subaction=search&story=%s&x=0&y=0' % urllib.quote_plus(query)

            r = client.request(url, post=post)
            r = client.parseDOM(r, 'div', attrs={'class': 'main-news'})
            r = [(dom_parser2.parse_dom(i, 'div', attrs={'class':'main-news-title'})) for i in r if i]
            r = [(dom_parser2.parse_dom(i[0], 'a', req='href')) for i in r if i]
            r = [(i[0].attrs['href'], i[0].content) for i in r if i]

            hostDict = hostprDict + hostDict

            for item in r:
                try:
                    name = item[1]
                    url = item[0]
                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D|4K|UHD)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)
                    if not cleantitle.get(re.sub('(\.|\(|\[|\s)(\d{4})', '', title)) == cleantitle.get(t): raise Exception()

                    y = re.findall('(\d{4})', re.sub('\d{3,4}p', '', name))[-1]
                    if not y == year: raise Exception()

                    r = client.request(url)
                    data = dom_parser2.parse_dom(r, 'center')[0]
                    data = dom_parser2.parse_dom(data.content, 'a', req='href')[0]
                    link = data.attrs['href']
                    link = client.replaceHTMLCodes(link)
                    link = link.encode('utf-8')

                    if any(x in url for x in ['.rar', '.zip', '.iso', ]): raise Exception()
                    quality, info = source_utils.get_release_quality(link, link)
                    size = re.findall('size:\s*((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', r)[0]
                    info.append(size)

                    info = ' | '.join(info)

                    url = client.request(link, output='geturl')
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    if not valid: raise Exception()
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')

                    sources.append({'source': host, 'quality': quality, 'language': 'en',
                                    'url': url, 'info': info, 'direct': False, 'debridonly': True})

                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources


    def resolve(self, url):
        return url

