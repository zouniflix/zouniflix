# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

'''

import re, urllib, urlparse, base64, json

from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import workers

class source:
    def __init__(self):
        self.priority = 1
        self.direct = 1
        self.language = ['en']
        self.domains = ['afdah.to']
        self.base_link = 'https://afdah.info'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        self.sources = []

        try:
            if not url: return self.sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            imdb = re.search('(\d+)', data['imdb']).groups()[0]
            embeds = ['/embed/%s', '/embed2/%s', '/embed3/%s', '/embed4/%s']

            threads = []
            for emb in embeds:
                url = urlparse.urljoin(self.base_link, emb % imdb)
                threads.append(workers.Thread(self.__get__items, url))
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self.sources
        except BaseException:
            return self.sources


    def __get__items(self, url):
        try:
            txt = client.request(url, post='play=continue&x=0&y=0', referer=url)

            code = re.findall(r'''salt\("([^"]+)''', txt)[0]
            decode = base64.b64decode(tor(base64.b64decode(code)))

            try:
                source_txt = re.findall('''sources:\s*\[([^\]]+)''', decode)[0]

                urls = re.findall('''file['"\s]*:\s*['"]([^'"]+)['"].+?['"\s]*type['"\s]*:\s*['"]([^'"]+)''',
                                    source_txt)
                for i in urls:
                    if 'googlevideo' in i[0]:
                        type = 'GVIDEO'
                    else:
                        type = 'CDN' if 'hls' not in i[1].lower() else 'HLS'
                    quality, info = source_utils.get_release_quality(i[0])
                    info = ' | '.join(info)
                    self.sources.append(
                        {'source': type, 'quality': '720p', 'language': 'en', 'url': i[0], 'direct': True,
                         'debridonly': False, 'info': info})
            except BaseException:
                pass

            try:
                frame = client.parseDOM(decode, 'iframe', ret='src')[0]
                api_frame = 'https://psystreams.com/api/source/{0}'.format(frame.split('/')[-1])
                post = {'r': '', 'd': 'psystreams.com'}
                data = client.request(api_frame, post=post)
                data = json.loads(data)
                for item in data['data']:
                    quality, info = source_utils.get_release_quality(item['label'])
                    info = ' | '.join(info)
                    self.sources.append(
                        {'source': 'CDN', 'quality': quality, 'language': 'en', 'url': item['file'], 'direct': True,
                         'debridonly': False, 'info': info})

            except BaseException:
                pass

            try:
                url = re.findall('''urlVideo\s*=\s*['"]([^'"]+)''', txt, re.DOTALL)[0]
                type = 'CDN' if 'hls' not in url.lower() else 'HLS'
                self.sources.append(
                    {'source': type, 'quality': '720p', 'language': 'en', 'url': url, 'direct': True,
                     'debridonly': False})
            except BaseException:
                pass


        except BaseException:
            pass



    def resolve(self, url):
        return url


def tor(txt):
    try:
        map = {}
        tmp = "abcdefghijklmnopqrstuvwxyz"
        buf = ""
        j = 0;
        for c in tmp:
            x = tmp[j]
            y = tmp[(j + 13) % 26]
            map[x] = y;
            map[x.upper()] = y.upper()
            j += 1

        j = 0
        for c in txt:
            c = txt[j]
            if c >= 'A' and c <= 'Z' or c >= 'a' and c <= 'z':
                buf += map[c]
            else:
                buf += c
            j += 1

        return buf
    except BaseException:
        return