# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse
import math, random

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['hdm.to']
        self.base_link = 'https://hdm.to'
        self.year_link = '/category/year/%s/'
        self.search_link = 'search/{0}/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            query = '%s' % data['tvshowtitle'] if 'tvshowtitle' in data else '%s' % data['title']
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            query = self.search_link.format(urllib.quote_plus(query))
            url = urlparse.urljoin(self.base_link, query)
            cj = client.request(self.base_link, output='cookie')
            r = client.request(url, referer=self.base_link, cookie=cj)
            items = client.parseDOM(r, 'item')
            for item in items:
                try:
                    name = client.parseDOM(item, 'title')[0]
                    name = client.replaceHTMLCodes(name)
                    t = re.sub(r'(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)
                    if not cleantitle.get(t) == cleantitle.get(title):
                        raise Exception()

                    if 'tvshowtitle' in data:
                        tv_link = client.parseDOM(item, 'link')[0]
                        tv_link = tv_link[:-1] if tv_link.endswith('/') else tv_link
                        tv_link = '{0}-season-{1}-episode-{2}'.format(tv_link, int(data['season']), int(data['episode']))

                        data = client.request(tv_link, referer=self.base_link, cookie=cj)
                        link = client.parseDOM(data, 'iframe', ret='src')[0]

                    else:
                        link = client.parseDOM(item, 'iframe', ret='src')[0]

                    try:
                        valid, host = source_utils.is_host_valid(link, hostDict)
                        if not valid:
                            if 'hdm.to/src' in link:
                                link = urllib.quote(link, ':/?=')
                                url, sub = self.get_link(link)
                                if url:
                                    url += "|Referer={}".format(link)
                                    sources.append({'source': 'HLS', 'quality': '1080p', 'language': 'en', 'url': url,
                                                    'direct': True, 'debridonly': False})
                            else:
                                continue
                        else:
                            sources.append({'source': host, 'quality': '1080p', 'language': 'en', 'url': link,
                                            'direct': False, 'debridonly': False})
                    except BaseException:
                        pass

                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def get_link(self, url):
        try:
            r = client.request(url)
            print r
            pattern = r'''var\s*hlsUrl\s*=.+?urlProtocol\)\.replace\("([^"]+)",\s*"([^"]+)"\)\+"([^"]+)";'''
            reg_hls = re.search(pattern, r, re.DOTALL)
            rep_1 = reg_hls.groups()[0]
            rep_2 = reg_hls.groups()[1]
            end_plus = reg_hls.groups()[2]
            url = url.split('?v=')[1]
            vtt_url = url.replace(".mp4", "_webvtt.vtt").replace('http://', 'https://')
            url = url.replace(rep_1, rep_2).replace('http://', 'https://') + end_plus
            return url, vtt_url
        except BaseException: return

    def resolve(self, url):
        return url