# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''



import re,urllib,urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from cloudscraper2 import CloudScraper as cfscrape

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['awesomedl.unblocked.mx']
        self.base_link = 'https://awesomedl.unblocked.mx'
        self.search_link ='/?s=%s&x=0&y=0'

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            tvshowtitle = url['tvshowtitle']
            url = self._search_show(tvshowtitle, season, episode, premiered)
            return url
        except BaseException:
            return

    def _search_show(self, tvshowtitle, season, episode, premiered):
        try:
            t = tvshowtitle.split()
            t = '.'.join(t)
            hdlr = 'season-%01d-episode-%01d' % (int(season), int(episode))
            self.hdlr1 = 'S%02dE%02d' % (int(season), int(episode))
            premiered = self._get_date(premiered)
            confirm_string = '%s-%s' % (cleantitle.geturl(tvshowtitle), hdlr)
            confirm_string2 = '%s-%s' % (cleantitle.geturl(tvshowtitle), premiered)
            url = urlparse.urljoin(self.base_link, self.search_link % (t + '.' + self.hdlr1))
            r = client.request(url)
            u = dom_parser2.parse_dom(r, 'div', {'class': 'post-wrap'})
            u = [dom_parser2.parse_dom(i, 'a', req='href')[0] for i in u]
            u = [i.attrs['href'] for i in u]
            u = [i for i in u if hdlr in i or premiered in i]
            uf = [i for i in u if confirm_string in i or confirm_string2 in i]
            if uf: return uf[0]
            elif u: return u[0]

            url = urlparse.urljoin(self.base_link, self.search_link % (cleantitle.geturl(tvshowtitle).replace('-','+') + '+' + premiered))
            r = client.request(url)
            u = dom_parser2.parse_dom(r, 'div', {'class': 'post-wrap'})
            u = [dom_parser2.parse_dom(i, 'a', req='href')[0] for i in u]
            u = [i.attrs['href'] for i in u]
            u = [i for i in u if hdlr in i or premiered in i]
            uf = [i for i in u if confirm_string in i or confirm_string2 in i]
            if uf: return uf[0]
            elif u: return u[0]
            return
        except BaseException:
            return

    def _get_date(self, premiered):
        try:
            year, month, day = premiered.split('-')
            year = '%04d' % int(year)
            month = '%02d' % int(month)
            day = '%02d' % int(day)
            if month == '01': month = 'jan'
            elif month == '02': month = 'feb'
            elif month == '03': month = 'mar'
            elif month == '04': month = 'apr'
            elif month == '05': month = 'may'
            elif month == '06': month = 'jun'
            elif month == '07': month = 'jul'
            elif month == '08': month = 'aug'
            elif month == '09': month = 'sep'
            elif month == '10': month = 'oct'
            elif month == '11': month = 'nov'
            elif month == '12': month = 'dec'
            
            premiered = '%s-%01d-%04d' % (month, int(day), int(year))
            return premiered
        except BaseException:
            return '0'
            
    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources

            r = client.request(url)
            u = dom_parser2.parse_dom(r, 'div', {'class': 'entry'})[0]
            u = dom_parser2.parse_dom(u.content, 'a', req='href')
            u = [(i.attrs['href']) for i in u if i]

            for url in u:
                try:
                    if any(x in url.lower() for x in ['.rar.', '.zip.', '.iso.']) or any(
                            url.lower().endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()

                    if any(x in url.lower() for x in ['youtube', 'sample', 'trailer']): raise Exception()
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')
                    if self.hdlr1.lower() in url.lower():
                        valid, host = source_utils.is_host_valid(url, hostDict)
                        if not valid:
                            valid, host = source_utils.is_host_valid(url, hostprDict)
                            if not valid: continue
                            debrid_only = True
                        else: debrid_only = False
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')

                        info = []
                        quality, info = source_utils.get_release_quality(url, url)
                        info = ' | '.join(info)

                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': debrid_only})
                except BaseException: pass
            return sources
        except BaseException:
            return sources


    def resolve(self, url):
        return url