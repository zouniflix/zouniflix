# -*- coding: utf-8 -*-
##RECAPTCHA v2###
'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, requests

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['flenix.cc']
        self.base_link = 'https://www1.flenix.cc/'
        self.search_link = urlparse.urljoin(self.base_link, 'index.php?do=search')
        self.recaptcha = 'g-recaptcha-response=0AJI'
        self.post_data = 'do=search&filter=true&story=%s&min_year=%s&max_year=%s&min_imdb=0&max_imdb=10&cat=1&order=date&%s'
        self.link_post = urlparse.urljoin(self.base_link, 'engine/ajax/get.php')
        self.ajax_link = urlparse.urljoin(self.base_link, 'engine/ajax/search.php')
        self.ajax_post = 'query=%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def search_movie(self, post, title, year):
        try:

            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1'}
            r = client.request(self.base_link, headers=headers, output='extended')
            cookies = r[4]
            headers = r[3]
            result = r[0]
            headers['X-Requested-With'] = 'XMLHttpRequest'
            headers['Referer'] = self.base_link
            r = client.request(self.ajax_link, post=post, XHR=True, headers=headers, cookie=cookies, close=False,
                               timeout=20)
            r = dom_parser2.parse_dom(r, 'a', {'class': 'searchresult'})
            r = [(i.content, i.attrs['href']) for i in r]
            r = [(dom_parser2.parse_dom(i[0], 'span', {'class': 'searchheading'})[0].content,
                  dom_parser2.parse_dom(i[0], 'span', {'class': 'syear'})[0].content, i[1]) for i in r]
            r = [(i[0], i[1], i[2]) for i in r if cleantitle.get(title) == cleantitle.get(i[0]) and year == i[1]]

            return r[0][2]
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):

        try:
            sources = []
            if url is None: return sources
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            post = self.ajax_post % urllib.quote_plus(data['title'])

            url = self.search_movie(post, data['title'], data['year'])
            ref_url = url
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1'}
            headers['Referer'] = self.base_link
            r = client.request(url, headers=headers, timeout=20)
            site_quality = re.findall(r'<div\s+class="quality">(.*?)</div>', r)[0]
            site_quality = source_utils.label_to_quality(site_quality)
            tmp = re.findall(r"post\('([^']+)',\s+\{id:\s*(\d+),\s*device:\s*'(\w+)'", r, re.DOTALL)[0]
            data = 'id=%s&device=%s' % (tmp[1], tmp[2])
            headers['Referer'] = url
            self.link_post = urlparse.urljoin(self.base_link, tmp[0])
            r = client.request(self.link_post, post=data, headers=headers, timeout=20)

            links = r.split(',')
            for link in links:
                try:
                    try:
                        quality = re.findall(r'&f=%2F([^%]+)%2', link)[0]
                        quality += 'p'
                        quality = source_utils.label_to_quality(quality)
                    except BaseException:
                        quality = site_quality
                    link += '|Referer=%s' % ref_url
                    s = 'HLS' if '.m3u8' in url else 'CDN'
                    sources.append({'source': s, 'quality': quality, 'language': 'en', 'url': link, 'direct': True,
                                    'debridonly': False})
                except BaseException:
                    pass
            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        try:
            url, ref = url.split('|')
            ref = ref.split('=')[1]
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1'}
            headers['Referer'] = ref
            url = client.request(url, output='geturl', headers=headers, timeout=10)
            url += '|Referer=%s' % ref
            return url
        except BaseException:
            return