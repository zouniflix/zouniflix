# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, base64
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2 as dom
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['vioozgo.org']
        self.base_link = 'https://vioozgo.org/'
        self.search_link = 'search?q=%s&s=t'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['title']
            hdlr = data['year']

            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', title.lower())

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)
            r = client.request(url)
            posts = client.parseDOM(r, 'div', attrs={'class': 'infos'})
            for post in posts:
                try:
                    r = dom.parse_dom(post, 'a', req=['href', 'title'])[0]
                    link = r.attrs['href']
                    name = r.attrs['title']
                    tit = re.sub('(\.|\(|\[|\s)(\d{4})(\.|\)|\]|\s|)(.+|)', '', name, flags=re.I)
                    if not cleantitle.get(tit) == cleantitle.get(title): raise Exception()
                    y = re.findall('[\.|\(|\[|\s](\d{4})[\.|\)|\]|\s]', name)[-1]
                    if not y == hdlr: raise Exception()
                    r = client.request(link)
                    links = re.findall('''['"]/go/(.+?)['"]\s*''', r, re.DOTALL)
                    for link in links:
                        link = base64.b64decode(link)
                        link = link.encode('utf-8')
                        valid, host = source_utils.is_host_valid(link, hostDict)
                        if not valid: continue

                        sources.append({'source': host, 'quality': 'SD', 'language': 'en', 'url': link,
                                        'direct': True, 'debridonly': False})
                except BaseException:
                    return sources

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url