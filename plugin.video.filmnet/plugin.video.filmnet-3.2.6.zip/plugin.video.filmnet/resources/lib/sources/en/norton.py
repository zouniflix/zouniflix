# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import json
import urllib, urlparse, re

from resources.lib.modules import cleantitle, jsunpack
from resources.lib.modules import client
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['bioskop45.com']
        self.base_link = 'https://bioskop45.cc/'
        self.search_link = 'search/%s/feed/rss2/'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['title']
            hdlr = data['year']

            query = '%s %s' % (title, hdlr)
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', '', query)

            url = urlparse.urljoin(self.base_link, self.search_link % urllib.quote_plus(query))
            r = client.request(url)

            items = client.parseDOM(r, 'item')

            for item in items:
                try:
                    name = client.parseDOM(item, 'title')[0]
                    name = client.replaceHTMLCodes(name)
                    t = re.sub('(\.|\(|\[|\s)(\d{4})(\.|\)|\]|\s|)(.+|)', '', name)
                    if not cleantitle.get(t) == cleantitle.get(title):
                        raise Exception()

                    y = re.findall('(?:\.|\(|\[|\s*|)(\d{4})(?:\.|\)|\]|\s*|)', name)[0]
                    if not y == hdlr:
                        raise Exception()

                    link = client.parseDOM(item, 'link')[0]
                    r = client.request(link)
                    r += client.request(urlparse.urljoin(link, '/2/'))
                    try:
                        frames = client.parseDOM(r, 'iframe', ret='data-lazy-src')
                        frames = [i for i in frames if not 'facebook' in i]
                        for frame in frames:
                            if 'dbplayer' in frame:
                                data = client.request(frame)
                                streams = re.findall('sources:\s*(\[.+?\])', data)
                                for i in streams:
                                    url, qual = re.findall('''file:['"](.+?)['"].+?label:['"](.+?)['"]''', i, re.DOTALL)[0]
                                    quality = source_utils.get_release_quality(qual, qual)[0]
                                    if 'google' in url:
                                        host = 'GVIDEO'
                                    else:
                                        host = 'DL'

                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': 'en', 'url': url,
                                         'direct': True, 'debridonly': False})
                            elif 'bioskop45.vip' in frame:
                                data = client.request(frame)
                                if jsunpack.detect(data):
                                    unpack = jsunpack.unpack(data)
                                else:
                                    unpack = data
                                streams = re.findall('sources:.+?(\[.+?\]).+?', unpack)[0]
                                streams = json.loads(streams)
                                for i in streams:
                                    if 'xtubeid.mp4' in i['file']: continue
                                    quality = source_utils.get_release_quality(i['label'], i['label'])[0]
                                    if 'google' in i['file']:
                                        host = 'GVIDEO'
                                    else:
                                        host = 'DL'

                                    sources.append(
                                        {'source': host, 'quality': quality, 'language': 'en', 'url': i['file'],
                                         'direct': True, 'debridonly': False})
                    except BaseException:
                        pass

                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        return url
