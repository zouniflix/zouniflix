# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re
import urllib
import urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2 as dom
from cloudscraper2 import CloudScraper as cfscrape
from resources.lib.modules import jsunpack


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['primewire.ac', 'primewire.ink']
        self.base_link = 'https://www.primewire.site/'#'https://www4.primewire.ac/'
        self.moviesearch_link = '?keywords=%s&type=movie'
        self.tvsearch_link = '?tv=&search_keywords={}'
        self.search_link = '?search_keywords={}'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            query = self.search_link.format(urllib.quote_plus(title))
            query = urlparse.urljoin(self.base_link, query.lower())
            # self.headers = client.setup_headers(referer=self.base_link)
            # self.scraper = cfscrape.create_scraper()
            result = client.request(query, referer=self.base_link)
            # result = self.scraper.get(query, self.headers)
            result = client.parseDOM(result, 'div', attrs={'class': 'index_item.+?'})

            result = [(dom.parse_dom(i, 'a', req=['href', 'title'])[0]) for i in result if i]
            result = [(i.attrs['href']) for i in result if
                      cleantitle.get(title) == cleantitle.get(re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '',
                        i.attrs['title'], flags=re.I))][0]
            url = client.replaceHTMLCodes(result)
            url = url.encode('utf-8')
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            query = self.tvsearch_link.format(urllib.quote_plus(cleantitle.query(tvshowtitle)))
            query = urlparse.urljoin(self.base_link, query.lower())
            # self.headers = client.setup_headers(referer=self.base_link)
            # self.scraper = cfscrape.create_scraper()
            result = client.request(query, referer=self.base_link)
            # result = self.scraper.get(query, self.headers).text
            result = client.parseDOM(result, 'div', attrs={'class': 'index_item.+?'})

            result = [(dom.parse_dom(i, 'a', req=['href', 'title'])[0]) for i in result if i]
            result = [
                (i.attrs['href']) for i in result if cleantitle.get(tvshowtitle) == cleantitle.get(
                    re.sub(
                        '(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)',
                        '',
                        i.attrs['title'],
                        flags=re.I))][0]

            url = client.replaceHTMLCodes(result)
            url = url.encode('utf-8')
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None:
                return

            url = urlparse.urljoin(self.base_link, url) if url.startswith('/') else url
            #https://www.primewire.site/watch-2784726-The-Crown
            url = url.replace('watch-', 'tv-')
            url = url + '/season-{:d}-episode-{:d}'.format(int(season), int(episode))

            # result = client.request(url)
            # result = client.parseDOM(result, 'div', attrs={'class': 'tv_episode_item'})
            #
            # urls = client.parseDOM(result, 'a', ret='href')
            # url = [i for i in urls if 'season-%01d-episode-%01d' % (int(season), int(episode)) in i][0]
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url is None:
                return sources

            url = urlparse.urljoin(self.base_link, url) if not url.startswith('http') else url

            # result = self.scraper.get(url, self.headers).text
            result = client.request(url)
            #links = client.parseDOM(result, 'tbody')
            data = re.findall(r'\s*(eval.+?)\s*</script', result, re.DOTALL)[1]
            data = jsunpack.unpack(data).replace('\\', '')

            #https://www.primewire.ink/ajax-78583.php?slug=watch-2809620-Black-Panther&cp=7TYP4N
            #var rtv=\'aja\';var aa=\'x-7\';var ba=\'85\';var ca=\'83\';var da=\'.ph\';var ea=\'p?sl\';var fa=\'ug=\';var ia=\'&cp=7T\';var ja=\'YP\';var ka=\'4N\';var code=ia+ja+ka;var page=rtv+aa+ba+ca+da+ea+fa;function goml(loc){$(\'#div1\').load(domain+page+loc+code)}
            patern = '''rtv='(.+?)';var aa='(.+?)';var ba='(.+?)';var ca='(.+?)';var da='(.+?)';var ea='(.+?)';var fa='(.+?)';var ia='(.+?)';var ja='(.+?)';var ka='(.+?)';'''
            links_url = re.findall(patern, data, re.DOTALL)[0]
            if 'season-' in url:
                seas, epis = re.findall(r'season-(\d+)-episode-(\d+)', url, re.DOTALL)[0]
                slug = 'slug={}&season={}&episode={}'.format(url.split('/')[3].replace('tv-', 'watch-'), str(seas), str(epis))
            else:
                slug = 'slug={}'.format(url.split('/')[-1])
            #slug=watch-2784726-The-Crown&season=2&episode=1&cp=7TYP4N
            links_url = self.base_link + [''.join(links_url)][0].replace('slug=', slug)
            links = client.request(links_url, timeout=20)
            links = client.parseDOM(links, 'tbody')
            for i in links:
                try:  # span class="version_host"
                    data = [
                        (client.parseDOM(i, 'a', ret='href')[0],
                         client.parseDOM(i, 'span', attrs={'class': 'version_host'})[0])][0]
                    url = urlparse.urljoin(self.base_link, data[0])
                    url = client.replaceHTMLCodes(url)
                    url = url.encode('utf-8')

                    host = data[1]
                    valid, host = source_utils.is_host_valid(host, hostDict)
                    if not valid:
                        continue

                    quality = client.parseDOM(i, 'span', ret='class')[0]
                    quality, info = source_utils.get_release_quality(
                        quality, url)

                    sources.append({'source': host,
                                    'quality': quality,
                                    'language': 'en',
                                    'url': url,
                                    'direct': False,
                                    'debridonly': False})
                except BaseException:
                    pass

            return sources
        except BaseException:
            return sources

    def resolve(self, url):
        try:
            # url = 'https://primewire.ink/go.php?title=Black-Panther&url=efdf73e70e3dc1c530e983a5bb2414365d813086==&id=384919&loggedin=0'
            if self.base_link in url:
                info = client.request(url)
                link = re.findall(r'''>window\.location\.replace\(['"](.+?)['"]\);</script>''', info, re.DOTALL)[0]
                return link

        except BaseException:
            return url

