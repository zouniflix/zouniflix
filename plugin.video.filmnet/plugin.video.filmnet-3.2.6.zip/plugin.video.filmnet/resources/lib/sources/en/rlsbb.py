# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, time, json, random

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from cloudscraper2 import CloudScraper as cfscrape
from resources.lib.modules import dom_parser2 as dom
from resources.lib.modules import workers
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 0
        self.language = ['en']
        self.domains = ['rlsbb.ru', 'rlsbb.to']
        self.base_link = 'http://rlsbb.ru/'
        self.old_link = 'http://old2.rlsbb.ru/'
        self.referer_link = 'http://search.rlsbb.ru/search/{0}'
        self.search_link = 'http://search.rlsbb.ru/Home/GetPost'#'http://search.rlsbb.ru/lib/search45224149886049641.php'
        self.search_phrase = '?phrase={0}&pindex=1&type=Simple&rand=0.%s' % random.randint(00000000000000001, 99999999999999999)
        #Home/GetPost?phrase=joker+2019&pindex=1&type=Simple&rand=0.5928290142150179

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []
            if url is None:
                return self._sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            self.title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data[
                'year']

            query = '%s S%02dE%02d' % (
            data['tvshowtitle'], int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else '%s %s' % (
            data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            query = urllib.quote_plus(query)
            self.headers = {'User-Agent': client.agent(),
                            'Referer': self.base_link}
            self.scraper = cfscrape.create_scraper()
            # code = self.scraper.get(self.referer_link.format(query), headers=self.headers).text
            # code = client.parseDOM(code, 'script', ret='data-code-rlsbb')[0]

            url = urlparse.urljoin(self.search_link, self.search_phrase.format(query))
            r = self.scraper.get(self.base_link, headers=self.headers).text
            r = self.scraper.get(url, headers=self.headers).text
            posts = json.loads(r)['results']
            if not posts and 'tvshowtitle' in data:
                hdlr = 'S%02d' % int(data['season'])
                query = '%s %s' % (self.title, hdlr)
                query = urllib.quote_plus(query)
                url = urlparse.urljoin(self.search_link, self.search_phrase % query.replace('+', '%2B'))
                r = r = self.scraper.get(url).text
                posts = json.loads(r)['results']
                posts = [(i['post_title'], i['post_name'], i['domain']) for i in posts]

                posts = [(i[0], i[1], i[2]) for i in posts if
                         cleantitle.get(i[0].lower().split(self.hdlr.lower())[0]) == cleantitle.get(self.title)]
            else:
                posts = [(i['post_title'], i['post_name'], i['domain']) for i in posts]
                posts = [(i[0], i[1], i[2]) for i in posts if
                         cleantitle.get(i[0].lower().split(self.hdlr.lower())[0]) == cleantitle.get(self.title)]
            self.hostprDict = hostprDict
            self.hostDict = hostDict
            filter = ['uhd', '4k', '2160', '1080', '720', 'hevc', 'bluray', 'web']
            posts = [(i[0], i[1], i[2]) for i in posts if any(x in i[1] for x in filter)]

            threads = []

            for i in posts:
                threads.append(workers.Thread(self._get_sources, i))
            [i.start() for i in threads]
            [i.join() for i in threads]

            return self._sources
        except BaseException:
            return self._sources

    def _get_sources(self, item):
        try:
            base = self.base_link if 'old' not in item[2] else self.old_link
            u = urlparse.urljoin(base, item[1])
            r = self.scraper.get(u).text
            name = item[0]
            name = client.replaceHTMLCodes(name)
            main = dom.parse_dom(r, 'div', {'class': 'postContent'})
            main = [i.content for i in main]
            comments = dom.parse_dom(r, 'div', {'class': re.compile('content')})
            main += [i.content for i in comments]

            for con in main:
                links = client.parseDOM(con, 'a', ret='href')
                for i in links:
                    try:
                        url = i
                        if 'youtube' in url: continue
                        if any(x in url for x in ['.rar', '.zip', '.iso', '.part']) or any(url.endswith(x) for x in ['rar', '.zip', '.iso', '.xsp']): raise Exception()
                        valid, host = source_utils.is_host_valid(url, self.hostDict)
                        if not valid:
                            valid, host = source_utils.is_host_valid(url, self.hostprDict)
                            if not valid:
                                continue
                            else:
                                rd = True
                        else:
                            rd = False
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')

                        if not self.hdlr.lower() in url.lower(): raise Exception()

                        quality, info = source_utils.get_release_quality(i, i)
                        try:
                            size = re.findall(r'((?:\d+\,\d+\.\d+|\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', con)[0]
                            div = 1 if size.endswith(('GB', 'GiB')) else 1024
                            size = float(re.sub('[^0-9|/.|/,]', '', size.replace(',', '.'))) / div
                            size = '%.2f GB' % size
                            info.append(size)
                        except BaseException:
                            pass
                        info = ' | '.join(info)
                        if url in str(self._sources): continue
                        if rd:
                            self._sources.append(
                                {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                                 'direct': False, 'debridonly': True})
                        else:
                            self._sources.append(
                                {'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info,
                                 'direct': False, 'debridonly': False})
                    except BaseException:
                        pass
        except BaseException:
            pass

    def resolve(self, url):
        return url