# -*- coding: utf-8 -*-

"""
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
import os
from resources.lib.modules import control


def create_settings():
    xml = ''
    source_path = os.path.abspath('sources').replace('/modules', '')
    print source_path
    langs = []
    for item in os.listdir(source_path):
        folder = os.path.join(source_path, item)
        if os.path.isdir(folder):
            lang_dict = {'de': 'German', 'el': 'Greek', 'en': 'English', 'es': 'Spanish'}
            langs.append((lang_dict[item], folder))
    for d in sorted(langs):
        xml += '\t\t<setting label="%s" type="lsep" />\n' % d[0]
        for root, dirs, files in os.walk(d[1]):
            if root[len(d[1]):].count(os.sep)<1:
                for f in sorted(files):
                    if '__init__' not in f and f.endswith('.py'):
                        f = f[:-3]
                        xml += '\t\t<setting id="provider.%s" type="bool" label="%s" default="true" />\n' % (f, f.upper())

    print xml


create_settings()