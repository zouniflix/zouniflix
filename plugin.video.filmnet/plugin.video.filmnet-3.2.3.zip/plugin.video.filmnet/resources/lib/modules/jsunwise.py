# -*- coding: utf-8 -*-

'''
    Filmnet Add-on
    Code ported from Shani's LiveStreamsPro Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import sys
import traceback


class JsUnwiser:
    def unwiseAll(self, data):
        try:
            in_data = data
            sPattern = 'eval\\(function\\(w,i,s,e\\).*?}\\((.*?)\\)'
            wise_data = re.compile(sPattern).findall(in_data)
            for wise_val in wise_data:
                unpack_val = self.unwise(wise_val)
                #print '\nunpack_val',unpack_val
                in_data = in_data.replace(wise_val, unpack_val)
            return re.sub(
                re.compile(
                    r"eval\(function\(w,i,s,e\).*?join\(''\);}",
                    re.DOTALL),
                "",
                in_data,
                count=1)
        except BaseException:
            traceback.print_exc(file=sys.stdout)
            return data

    def containsWise(self, data):
        return 'w,i,s,e' in data

    def unwise(self, sJavascript):
        #print 'sJavascript',sJavascript
        page_value = ""
        try:
            ss = "w,i,s,e=(" + sJavascript + ')'
            exec (ss)
            page_value = self.__unpack(w, i, s, e)
        except BaseException:
            traceback.print_exc(file=sys.stdout)
        return page_value

    def __unpack(self, w, i, s, e):
        lIll = 0
        ll1I = 0
        Il1l = 0
        ll1l = []
        l1lI = []
        while True:
            if (lIll < 5):
                l1lI.append(w[lIll])
            elif (lIll < len(w)):
                ll1l.append(w[lIll])
            lIll += 1
            if (ll1I < 5):
                l1lI.append(i[ll1I])
            elif (ll1I < len(i)):
                ll1l.append(i[ll1I])
            ll1I += 1
            if (Il1l < 5):
                l1lI.append(s[Il1l])
            elif (Il1l < len(s)):
                ll1l.append(s[Il1l])
            Il1l += 1
            if (len(w) + len(i) + len(s) + len(e)
                    == len(ll1l) + len(l1lI) + len(e)):
                break

        lI1l = ''.join(ll1l)  # .join('');
        I1lI = ''.join(l1lI)  # .join('');
        ll1I = 0
        l1ll = []
        for lIll in range(0, len(ll1l), 2):
            #print 'array i',lIll,len(ll1l)
            ll11 = -1
            if (ord(I1lI[ll1I]) % 2):
                ll11 = 1
            #print 'val is ', lI1l[lIll: lIll+2]
            l1ll.append(chr(int(lI1l[lIll: lIll + 2], 36) - ll11))
            ll1I += 1
            if (ll1I >= len(l1lI)):
                ll1I = 0
        ret = ''.join(l1ll)
        if 'eval(function(w,i,s,e)' in ret:
            ret = re.compile(
                r'eval\(function\(w,i,s,e\).*}\((.*?)\)').findall(ret)[0]
            return self.unwise(ret)
        else:
            return ret
