# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, json, random, platform

from resources.lib.modules import client
from resources.lib.modules import cleantitle
from resources.lib.modules import directstream
from resources.lib.modules import source_utils
from cloudscraper2 import CloudScraper as cfscrape


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['putlockertv.to', 'putlocker.se']
        self.base_link = 'https://www6.putlockertv.to/'
        self.movie_search_path = 'search?keyword=%s'
        self.episode_search_path = '/filter?keyword=%s&sort=post_date:Adesc&type[]=series'
        self.ajax_search_path = '/ajax/film/search?ts=%s&_=%s&sort=year:desc&keyword=%s'
        self.film_path = '/watch/%s'
        self.info_path = '/ajax/episode/info?ts=%s&_=%s&id=%s&server=%s&update=0'
        self.grabber_path = '/grabber-api/?ts=%s&_=%s&id=%s&token=%s&mobile=0'
        self.servers_path = '/ajax/film/servers/%s?ts=%s&_=1042'
        self.film_url = ''

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            clean_title = cleantitle.geturl(title)
            search_title = cleantitle.getsearch(title).replace(' ', '+')
            query = (self.movie_search_path % (search_title))
            url = urlparse.urljoin(self.base_link, query)
            self.scraper = cfscrape.create_scraper()
            self.scraper.headers[
                'User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'

            for r in range(1, 3):
                # search_response = client.request(url, timeout=10)
                search_response = self.scraper.get(url).content
                if search_response != None: break

            results_list = client.parseDOM(search_response, 'div', attrs={'class': 'item'})
            for result in results_list:
                tip = client.parseDOM(result, 'div', attrs={'class': 'inner'}, ret='data-tip')[0]
                url = urlparse.urljoin(self.base_link, tip)
                tip_response = self.scraper.get(url).content  # client.request(url, timeout=10)
                if year in tip_response:
                    film_id = re.findall('(\/watch\/)([^\"]*)', result)[0][1]
                    break

            query = self.film_path % film_id
            url = urlparse.urljoin(self.base_link, query)
            self.film_url = url
            film_id_new = film_id.split('.')[1]

            for r in range(1, 3):
                film_response = self.scraper.get(url).content  # client.request(url, timeout=10)
                if film_response != None: break

            ts = re.findall('(data-ts=\")(.*?)(\">)', film_response)[0][1]
            url = urlparse.urljoin(self.base_link, self.servers_path % (film_id_new, ts))
            servers_response = self.scraper.get(url).content
            servers_response = json.loads(servers_response)['html']

            server_ids = client.parseDOM(
                servers_response, 'div', ret='data-id', attrs={'class': 'server row'})

            sources_dom_list = client.parseDOM(
                servers_response, 'ul', attrs={'class': 'episodes range active'})
            sources_list = []
            quali_list = []

            for i in sources_dom_list:
                # source_id = re.findall('([\/])(.{0,6})(\">)', i)[0][1]
                source_id = client.parseDOM(i, 'a', ret='data-id')[0]
                release_q = client.parseDOM(i, 'a')[0]
                sources_list.append(source_id)
                quali_list.append(release_q)

            sources_list = zip(sources_list, server_ids, quali_list)

            data = {
                'imdb': imdb,
                'title': title,
                'localtitle': localtitle,
                'year': year,
                'ts': ts,
                'sources': sources_list
            }
            url = urllib.urlencode(data)

            return url

        except Exception:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            data = {
                'imdb': imdb,
                'tvdb': tvdb,
                'tvshowtitle': tvshowtitle,
                'year': year
            }
            url = urllib.urlencode(data)

            return url

        except Exception:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:

            data = urlparse.parse_qs(url)
            data = dict((i, data[i][0]) for i in data)

            clean_title = cleantitle.geturl(data['tvshowtitle'])
            query = (self.movie_search_path % clean_title)
            url = urlparse.urljoin(self.base_link, query)
            self.scraper = cfscrape.create_scraper()
            self.scraper.headers[
                'User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'

            for r in range(1, 3):
                search_response = self.scraper.get(url).content
                if search_response != None: break

            results_list = client.parseDOM(
                search_response, 'div', attrs={'class': 'items'})[0]

            film_id = []

            film_tries = [
                '\/' + (clean_title + '-0' + season) + '[^-0-9](.+?)\"',
                '\/' + (clean_title + '-' + season) + '[^-0-9](.+?)\"',
                '\/' + clean_title + '[^-0-9](.+?)\"'
            ]

            for i in range(len(film_tries)):
                if not film_id:
                    film_id = re.findall(film_tries[i], results_list)
                else:
                    break

            film_id = film_id[0]
            query = re.findall(r'href="(.*?\.%s)"' % film_id, results_list)[0]
            # query = (self.film_path % film_id)
            url = urlparse.urljoin(self.base_link, query)
            self.film_url = url

            for r in range(1, 3):
                film_response = self.scraper.get(url).content
                if film_response != None: break

            ts = re.findall('(data-ts=\")(.*?)(\">)', film_response)[0][1]

            url = urlparse.urljoin(self.base_link, self.servers_path % (film_id, ts))
            servers_response = self.scraper.get(url).content
            servers_response = json.loads(servers_response)['html']

            server_ids = client.parseDOM(
                servers_response, 'div', ret='data-id', attrs={'class': 'server row'})

            sources_dom_list = client.parseDOM(
                servers_response, 'ul', attrs={'class': 'episodes range active'})

            if not re.findall(
                    '([^\/]*)\">' + episode + '[^0-9]', sources_dom_list[0]):
                episode = '%02d' % int(episode)

            sources_list = []
            quali_list = []

            for i in sources_dom_list:
                try:
                    source_id = re.findall('''data-id=['"](.+?)['"].+?">''' +episode+'''</a>''', i)[0]
                    sources_list.append(source_id)
                    quali_list.append('SD')

                except BaseException:
                    pass

            sources_list = zip(sources_list, server_ids, quali_list)

            data.update({
                'title': title,
                'premiered': premiered,
                'season': season,
                'episode': episode,
                'ts': ts,
                'sources': sources_list
            })

            url = urllib.urlencode(data)

            return url

        except Exception:
            return

    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            data_sources = eval(data['sources'])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            for i, s, rq in data_sources:
                token = str(self.___token(
                    {'id': i, 'server': s, 'update': 0, 'ts': data['ts']}, 'XT4Az3r00D'))
                query = (self.info_path % (data['ts'], token, i, s))
                url = urlparse.urljoin(self.base_link, query)
                headers = self.scraper.headers
                headers['X-Requested-With'] = 'XMLHttpRequest'

                for r in range(1, 3):
                    info_response = self.scraper.get(url,
                                                     headers=headers).content  # client.request(url, XHR=True, timeout=10)
                    if info_response != None: break
                info_response = re.findall(r'(\{[^\}]+\})', info_response)[0]
                grabber_dict = json.loads(info_response)

                try:
                    if grabber_dict['type'] == 'direct':
                        token64 = grabber_dict['params']['token']
                        randint = random.randint(1000000, 2000000)
                        query = (self.grabber_path % (data['ts'], randint, i, token64))
                        url = urlparse.urljoin(self.base_link, query)
                        self.referer = url
                        for r in range(1, 3):
                            response = client.request(url, XHR=True, timeout=10)
                            if response != None: break

                        sources_list = json.loads(response)['data']

                        for j in sources_list:

                            quality = j['label'] if not j['label'] == '' else 'SD'
                            quality = source_utils.label_to_quality(quality)
                            urls = None

                            if 'googleapis' in j['file']:
                                sources.append(
                                    {'source': 'gvideo', 'quality': quality, 'language': 'en', 'url': j['file'],
                                     'direct': True, 'debridonly': False, 'subs': None})
                                continue

                            if 'lh3.googleusercontent' in j['file'] or 'bp.blogspot' in j['file']:
                                try:
                                    newheaders = {
                                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36',
                                        'Accept': '*/*',
                                        'Host': 'lh3.googleusercontent.com',
                                        'Accept-Language': 'en-US,en;q=0.8,de;q=0.6,es;q=0.4',
                                        'Accept-Encoding': 'identity;q=1, *;q=0',
                                        'Referer': self.film_url,
                                        'Connection': 'Keep-Alive',
                                        'X-Client-Data': 'CJK2yQEIo7bJAQjEtskBCPqcygEIqZ3KAQjSncoBCKijygE=',
                                        'Range': 'bytes=0-'
                                        }
                                    resp = client.request(j['file'], headers=newheaders, redirect=False,
                                                          output='extended', timeout='10')
                                    loc = resp[2]['Location']
                                    c = resp[2]['Set-Cookie'].split(';')[0]
                                    j['file'] = '%s|Cookie=%s' % (loc, c)
                                    urls, host, direct = [{'quality': quality, 'url': j['file']}], 'gvideo', True

                                except BaseException:
                                    pass

                            valid, hoster = source_utils.is_host_valid(j['file'], hostDict)
                            if not urls or urls == []:
                                urls, host, direct = source_utils.check_directstreams(j['file'], hoster)
                            for x in urls:
                                sources.append({
                                    'source': 'gvideo',
                                    'quality': x['quality'],
                                    'language': 'en',
                                    'url': x['url'],
                                    'direct': True,
                                    'debridonly': False
                                })

                    elif not grabber_dict['target'] == '':
                        url = 'https:' + grabber_dict['target'] if not grabber_dict['target'].startswith('http') else \
                        grabber_dict['target']
                        sub = grabber_dict['subtitle']
                        rq, info = source_utils.get_release_quality(url, rq)
                        info = ' | '.join(info)
                        q = rq if rq and rq != '' else 'SD'
                        if 'mcloud' in url:
                            response = client.request(url,
                                                      headers={'Referer': self.film_url, 'Connection': 'Keep-Alive'})
                            pls = re.findall(r'sources:\s*\[\{"file":"([^"]+)', response)[0]
                            plsbase = re.findall(r'(.*/)\w+\.m3u8', pls)[0]
                            pls = client.request(pls, headers={'Referer': url, 'Connection': 'Keep-Alive'})
                            pls = re.findall(r'(\w+.*m3u8)', pls)
                            for pl in pls:
                                # u = '%s%s|Referer=%s'%(plsbase, pl ,url)
                                u = '%s%s|Referer=%s' % (plsbase, pl, 'https://mcloud.to/')
                                if platform.linux_distribution()[0] == 'debian' and platform.linux_distribution()[
                                    1] == 'jessie/sid':
                                    u = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;proxy_for_chunks=False&amp;name=%s&amp;url=%s' % (
                                    title, urllib.quote(u))
                                q = source_utils.label_to_quality(pl)
                                sources.append(
                                    {'source': 'MYCLOUD', 'quality': q, 'language': 'en', 'url': u, 'info': info,
                                     'direct': True, 'debridonly': False, 'sub': sub})

                        elif 'rapidvid' in url:
                            # add RD embed links too
                            sources.append({
                                'source': 'rapidvideo.com',
                                'quality': q,
                                'language': 'en',
                                'url': url,
                                'info': info,
                                'direct': False,
                                'debridonly': False,
                                'sub': sub
                            })
                            response = client.request(url,
                                                      headers={'Referer': self.film_url, 'Connection': 'Keep-Alive'},
                                                      output='extended')
                            cookie = response[4]
                            post = 'confirm.x=%d&confirm.y=%d&block=1' % (
                            random.randint(50, 80), random.randint(50, 80))
                            response = client.request(url, post=post,
                                                      headers={'Referer': url, 'Connection': 'Keep-Alive'},
                                                      cookie=cookie)
                            links = re.findall(r'href="(https:\/\/www.rapidvideo[^"]+)">\s*<div[^>]+>\s*(.*)\s*<\/div>',
                                               response)
                            for link, qualy in links:
                                cookie2 = '%s;q=%s' % (cookie, qualy.replace('p', ''))
                                response = client.request(link, post=post,
                                                          headers={'Referer': url, 'Connection': 'Keep-Alive'},
                                                          cookie=cookie2)
                                link = re.findall(r'video.*source\s+src="([^"]+)', response)[0]
                                q = source_utils.label_to_quality(qualy)
                                sources.append({
                                    'source': 'RAPIDVIDEO',
                                    'quality': q,
                                    'language': 'en',
                                    'url': link,
                                    'info': info,
                                    'direct': True,
                                    'debridonly': False,
                                    'sub': sub
                                })

                        else:
                            valid, hoster = source_utils.is_host_valid(url, hostDict)
                            if not valid: continue
                            urls, host, direct = source_utils.check_directstreams(url, hoster)
                            q = urls[0]['quality'] if urls[0]['quality'] != 'SD' else rq
                            sources.append({
                                'source': hoster,
                                'quality': q,
                                'language': 'en',
                                'url': urls[0]['url'],
                                'info': info,
                                'direct': False,
                                'debridonly': False,
                                'sub': sub
                            })
                except BaseException:
                    pass
            return sources

        except Exception:
            return sources

    def resolve(self, url):
        try:
            if not url.startswith('http'):
                url = 'http:' + url

            for i in range(3):
                if 'google' in url and not 'googleapis' in url:
                    url = directstream.googlepass(url)

                if url:
                    break

            return url

        except Exception:
            return

    def ___token(self, params, It):
        #####################################################################################
        # The It string constant can be found in assets/min/public/all.js
        # Search for the function that returns a hex number like Number(e)[W$ + JY + kw](16)
        # and then search for the params passed to that function. one of the params is a
        # function like e(). search for that function further up. It contains the It string
        ####################################################################################
        try:
            def r(t):
                i = 0
                j = 0
                for i in range(0, len(t)):
                    j = j + (ord(t[i]) + i)
                return j

            s = r(It)

            for p in params:
                t = It + p
                i = str(params[p])
                l = max(len(t), len(i))
                e = 0
                for n in range(0, l):
                    if n < len(i):
                        e += ord(i[n])
                    if n < len(t):
                        e += ord(t[n])

                e = str(hex(e)).replace('0x', '')
                e = r(e)
                s += e

            return s
        except Exception:
            return 0

