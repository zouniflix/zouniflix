# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators


    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,urllib,urlparse,json


from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import dom_parser2
from resources.lib.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['allrls.pw']
        self.base_link = 'http://bestrls.net/'
        self.search_link = '?s=%s+%s&go=Search'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = urlparse.urljoin(self.base_link, '%s-%s' % (cleantitle.geturl(title), year))
            #p_link = 'http://allrls.pw/hello.php'
            #post = {'fname': 'Hello'}
            #post = client.request(p_link, post=post, referer=url)
            url = client.request(url, output='geturl')
            if url is None:
                url = urlparse.urljoin(self.base_link, '%s' % (cleantitle.geturl(title)))
                url = client.request(url, output='geturl')
            if url is None: raise Exception()
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        return tvshowtitle

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return
            url = urlparse.urljoin(self.base_link, '%s-s%02de%02d' % (cleantitle.geturl(url), int(season), int(episode)))
            #p_link = 'http://allrls.pw/hello.php'
            #post = {'fname': 'Hello'}
            #post = client.request(p_link, post=post, referer=url)
            url = client.request(url, output='geturl')
            #print url
            if url is None: raise Exception()
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources
            if debrid.status() is False: raise Exception()

            hostDict = hostprDict + hostDict

            r = client.request(url)           

            r = [(dom_parser2.parse_dom(r, 'h1', {'class': 'entry-title'}),
                 dom_parser2.parse_dom(r, 'div', {'class': 'entry-content'}))]
            r = [(i[0][0].content, re.search('>Size:\s*([^<]+)', i[1][0].content), i[1][0].content) for i in r]
            r = [(i[0], i[1].groups()[0] if i[1] else '0', i[2]) for i in r]

            for i in r:
                urls = client.parseDOM(i[2], 'a', ret = 'href')
                for url in urls:
                    try:
                        host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
                        if not host in hostDict: raise Exception()

                        if any(x in url.lower() for x in ['.rar.', '.zip.', '.iso.']) or any(
                                url.lower().endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()

                        if any(x in url.lower() for x in ['youtube', 'sample', 'trailer']): raise Exception()
                        
                        info = []
                        quality, info = source_utils.get_release_quality(url, i[0])
                        try:
                            size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', i[1])[-1]
                            div = 1 if size.endswith(('GB', 'GiB')) else 1024
                            size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                            size = '%.2f GB' % size
                            info.append(size)
                        except BaseException:
                            pass

                        if any(x in url.upper() for x in ['HEVC', 'X265', 'H265']): info.append('HEVC')

                        info = ' | '.join(info)
                        
                        host = client.replaceHTMLCodes(host)
                        host = host.encode('utf-8')

                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True})                       
                    except BaseException:
                        pass
            return sources
        except BaseException:
            return

    def resolve(self, url):
        return url