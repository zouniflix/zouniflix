# -*- coding: utf-8 -*-

'''
    Filmnet Add-on (C) 2017
    Credits to Exodus and Covenant; our thanks go to their creators

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re,urllib,urlparse,time

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import debrid
from resources.lib.modules import source_utils
from resources.lib.modules import dom_parser2
from resources.lib.modules import workers

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['pilihlaptop.com']
        self.base_link = 'http://pilihlaptop.com/'
        self.search_post = 'do=search&subaction=search&story=%s+%s'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def search(self, title, hdlr, imdb):
        try:
            post = self.search_post % (urllib.quote_plus(title), hdlr)
            r = client.request(self.base_link, post=post)
            r = dom_parser2.parse_dom(r, 'div', {'class': 'post'})
            r = [(dom_parser2.parse_dom(i, 'a', req='href'), dom_parser2.parse_dom(i, 'a', req=['href','target','rel'])) for i in r]
            r = [(i[0][0].attrs['href'], i[0][0].content, i[1][0].attrs['href']) for i in r if i[0] and i[1]]
            if len(hdlr) == 4: r = [(i[0], i[1]) for i in r if imdb in i[2] and hdlr.lower() in i[1].lower()]
            else: r = [(i[0], i[1]) for i in r if cleantitle.get(title) in cleantitle.get(i[1]) and hdlr.lower() in i[1].lower()]
            return r
        except BaseException:
           return
           
    def sources(self, url, hostDict, hostprDict):
        try:
            self._sources = []

            if url is None: return self._sources

            if debrid.status() is False: raise Exception()

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']

            u = self.search(title, hdlr, data['imdb'])

            self.hostprDict = hostprDict
            self.hostDict = hostDict
            threads = []

            for i in u: threads.append(workers.Thread(self._get_sources, i[0], i[1]))
            [i.start() for i in threads]
            
            alive = [x for x in threads if x.is_alive() == True]
            while alive:
                alive = [x for x in threads if x.is_alive() == True]
                time.sleep(0.1)
            return self._sources
        except BaseException:
            return self._sources
            
    def _get_sources(self, url, name):
        try:
            name = client.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = client.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            r = client.request(url)
            s = dom_parser2.parse_dom(r, 'meta', {'name': 'description'})[0]
            s = s.attrs['content']
            r = dom_parser2.parse_dom(r, 'div', {'class': 'quote'})
            c = ''
            for i in r: c += i.content
            r = dom_parser2.parse_dom(c, 'a', req='href')
            l = [i.attrs['href'] for i in r]
            for url in l:
                try:
                    if any(x in url.lower() for x in ['.rar.', '.zip.', '.iso.']) or any(
                            url.lower().endswith(x) for x in ['.rar', '.zip', '.iso']): raise Exception()

                    if any(x in url.lower() for x in ['youtube', 'sample', 'trailer']): raise Exception()
                    valid, host = source_utils.is_host_valid(url, self.hostDict)
                    if not valid:
                        valid, host = source_utils.is_host_valid(url, self.hostprDict)
                        if not valid: continue
                        else: rd = True
                    else: rd = False
                    host = client.replaceHTMLCodes(host)
                    host = host.encode('utf-8')
                    quality, info = source_utils.get_release_quality(url, name)
                    info = []
                    try:
                        size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GiB|MiB|GB|MB))', s)[0]
                        div = 1 if size.endswith(('GB', 'GiB')) else 1024
                        size = float(re.sub('[^0-9|/.|/,]', '', size)) / div
                        size = '%.2f GB' % size
                        if size.startswith('0.00'): size = ''
                        info.append(size)
                    except BaseException:
                         pass
                    info = ' | '.join(info)
                    if url in str(self._sources): continue
                    if rd:
                        self._sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True})
                    else:
                        self._sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': False})
                except BaseException:
                    pass
        except BaseException:
            pass

    def resolve(self, url):
        return url