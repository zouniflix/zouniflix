# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re, urllib, urlparse, math, random, json

from resources.lib.modules import control
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import dom_parser2
from resources.lib.modules import source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['m4ufree.com']
        self.base_link = 'http://ww1.m4ufree.com/'
        self.search_link = '?keyword=%s&search_section=1'
        self.tv_episode = urlparse.urljoin(self.base_link, 'ajax-tvshow.php')
        self.movie_post = urlparse.urljoin(self.base_link, 'ajax_new.php')

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = urlparse.parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urllib.urlencode(url)
            return url
        except BaseException:
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []

            if url is None: return sources

            data = urlparse.parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']

            hdlr = 'S%02d-E%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data[
                'year']

            query = '%s' % data['tvshowtitle'] if 'tvshowtitle' in data else '%s %s' % (data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)

            url = self.search_link % urllib.quote_plus(query)
            url = urlparse.urljoin(self.base_link, url)

            r = client.request(url, referer=self.base_link)

            posts = client.parseDOM(r, 'div', attrs={'class': 'item'})

            hostDict = hostprDict + hostDict

            items = []

            for post in posts:
                try:
                    t = client.parseDOM(post, 'a', ret='title')[0]

                    c = client.parseDOM(post, 'a', ret='href')[0]
                    try:
                        qual = client.parseDOM(r, 'span', attrs={'class': 'quality'})[0]
                    except BaseException:
                        qual = '0'

                    u = [(t, c, qual)]
                    items += u
                except BaseException:
                    pass

            for item in items:
                try:
                    name = item[0]
                    name = client.replaceHTMLCodes(name)

                    t = re.sub('(\.|\(|\[|\s)(\d{4}|S\d+E\d+|S\d+|3D)(\.|\)|\]|\s|)(.+|)', '', name, re.I)

                    if not cleantitle.get(t) == cleantitle.get(title): raise Exception()

                    if 'tvshowtitle' in data:
                        url = urlparse.urljoin(self.base_link, item[1].replace('./', '/'))
                        r = client.request(url)
                        r = client.parseDOM(r, 'h2')
                        r = [i for i in r if hdlr in i][0]
                        r = re.findall('''idepisode=['"](.+?)['"]''', r)[0]
                        post = 'idepisode=%s' % r
                        r = None
                        for i in range(0, 20):
                            r = client.request(self.tv_episode, post=post)
                            if r: break
                    else:
                        y = re.findall('[\.|\(|\[|\s](\d{4}|S\d+E\d+|S\d+)[\.|\)|\]|\s]', name, re.I)[-1].upper()
                        if not y == hdlr: raise Exception()
                        url = urlparse.urljoin(self.base_link, item[1].replace('./', '/'))
                        r = client.request(url)

                    data = client.parseDOM(r, 'div', attrs={'class': 'le-server'})
                    data = [dom_parser2.parse_dom(i, 'span') for i in data if i]
                    data = [(i[0].attrs['data'], item[2]) for i in data if i]

                    for i in data:
                        try:
                            plink = self.movie_post
                            post = 'm4u=%s' % urllib.quote(i[0])

                            r = client.request(plink, post=post)

                            links = []
                            embed = re.search('file:\s*"([^"]+)', r)
                            if embed:
                                links.append(urlparse.urljoin(self.base_link, embed.groups()[0]))
                            links.append(client.parseDOM(r, 'iframe', ret='src')[0])
                            quality = '720p' if 'HD' in i[1] else 'SD'

                            for link in links:
                                try:
                                    if 'player.php?' in link:
                                        slinks = self.get_links(link)
                                        if len(slinks) > 0:
                                            for quality, url in slinks:
                                                url += '|Origin=http://them4ufree.com'
                                                sources.append({'source': 'CDN', 'quality': quality, 'language': 'en',
                                                                'url': url, 'direct': True, 'debridonly': False})
                                    elif 'm4ufree' in link:
                                        r = client.request(link, referer=url, redirect=False, output='extended')
                                        r = r[2]['Location']
                                        if 'embed' in r: r = client.request(r, referer=url, redirect=False,
                                                                            output='extended')
                                        link = r[2]['Location']
                                        sources.append(
                                            {'source': 'gvideo', 'quality': quality, 'language': 'en', 'url': link,
                                             'direct': True, 'debridonly': False})
                                except BaseException:
                                    pass
                        except BaseException:
                            pass

                except BaseException:
                    pass
            return sources
        except BaseException:
            return sources

    def get_links(self, link):
        def get_spath(rj):
            sid = rj['id']
            srange = rj['range'][0]
            spired = rj['expired']
            sfile = rj['multiData'][0]['file']
            spath = '%s/%s/%s/1/%s' % (sid, srange, spired, sfile)
            return spath

        streams = []
        try:
            import json
            r = client.request(link)
            jd = json.loads(re.findall('Player\(([^\)]+)', r)[0])
            post = urllib.urlencode({'key': jd['key'], 'type': jd['type'], 'value': jd['value']})
            r = json.loads(client.request('https://multi.hydrax.net/vip', post=post, referer=link))
            server = r['servers'][0]
            if 'fullhd' in r.keys():
                rj = r['fullhd']
                surl = 'http://%s/%s' % (server, get_spath(rj))
                streams.append(('1080p', surl))
            if 'hd' in r.keys():
                rj = r['hd']
                surl = 'http://%s/%s' % (server, get_spath(rj))
                streams.append(('720p', surl))
            if 'sd' in r.keys():
                rj = r['sd']
                surl = 'http://%s/%s' % (server, get_spath(rj))
                streams.append(('SD', surl))

            return streams

        except BaseException:
            return streams

    def resolve(self, url):
        return url