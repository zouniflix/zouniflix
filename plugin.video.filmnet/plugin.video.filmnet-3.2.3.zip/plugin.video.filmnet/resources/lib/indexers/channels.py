# -*- coding: utf-8 -*-

'''
    Filmnet Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.modules import cleangenre
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import metacache
from resources.lib.modules import workers
from resources.lib.modules import trakt
from resources.lib.modules import playcount
from resources.lib.modules import views

import xbmc
import sys
import re
import json
import urllib
import urlparse
import datetime
import time
import xbmcaddon
import os


class channels:
    def __init__(self):
        self.list = []
        self.items = []

        self.uk_datetime = self.uk_datetime()
        self.systime = (self.uk_datetime).strftime('%Y%m%d%H%M%S%f')
        self.tm_img_link = 'https://image.tmdb.org/t/p/w%s%s'
        self.lang = control.apiLanguage()['trakt']

        # SKY DATA
        self.sky_now_link = 'http://epgservices.sky.com/5.1.1/api/2.0/channel/json/%s/now/nn/0'
        self.sky_programme_link = 'https://awk.epgsky.com/hawk/linear/schedule/%s/%s/'
        # HBO DATA
        self.tvguide_link = 'http://mobilelistings.tvguide.com/Listingsweb/ws/rest/airings/%s/start/%s/duration/10?channelsourceids=%s|%s&formattype=json'
        self.get_year_hbo = 'http://mapi.tvguide.com/listings/details?program=%s'

        self.tm_user = control.setting('tm.user')
        self.fanart_tv_user = control.setting('fanart.tv.user')
        self.fanart_tv_art_link = 'http://webservice.fanart.tv/v3/movies/%s'
        self.fanart_tv_level_link = 'http://webservice.fanart.tv/v3/level'
        self.tm_art_link = 'http://api.themoviedb.org/3/movie/%s/images?api_key=%s&language=en-US&include_image_language=en,%s,null' % (
            '%s', self.tm_user, self.lang)
        self.tm_img_link = 'https://image.tmdb.org/t/p/w%s%s'
        self.fanart_tv_headers = {'api-key': control.setting('fanart.tv.api')}
        if not self.fanart_tv_user == '':
            self.fanart_tv_headers.update({'client-key': self.fanart_tv_user})

    def get(self):
        channels = [
            ('01', 'Sky Cinema Premiere HD', '4021'),
            ('02', 'Sky Cinema Premiere +1', '1823'),
            ('03', 'Sky Cinema Hits HD', '4033'),
            ('04', 'Sky Cinema Greats HD', '4015'),
            ('05', 'Sky Cinema Disney HD', '4013'),
            ('06', 'Sky Cinema Family HD', '4018'),
            ('07', 'Sky Cinema Action HD', '4014'),
            ('08', 'Sky Cinema Comedy HD', '4019'),
            ('09', 'Sky Cinema Thriller HD', '4062'),
            ('10', 'Sky Cinema Drama HD', '4016'),
            ('11', 'Sky Cinema Sci Fi HD', '4017'),
            ('12', 'Sky Cinema Classics HD', '4020'),
            ('13', 'Film4 HD', '4044'),
            ('14', 'Film4 +1', '1629'),
            ('15', 'TCM HD', '3811'),
            ('16', 'TCM +1', '5275'),
            ('17', 'Sony Movies', '3709'),
            ('18', 'Sony Movies+1', '3771'),
            ('19', 'movies4men', '3708'),
            ('20', 'mov4men+1', '3721'),
            ('21', 'Movies 24', '4420'),
            ('22', 'Movies 24+', '4421'),
            ('23', 'True Movies', '3643'),
            ('24', 'True Movies+1', '3751'),
            ('25', 'Talking Pictures', '5252'),
            ('26', 'ROK', '3542'),
            ('27', 'horror channel', '3605'),
            ('28', 'horror ch+1', '4502')
        ]

        threads = []
        for i in channels:
            threads.append(workers.Thread(self.sky_list, i[0], i[1], i[2]))
        [i.start() for i in threads]
        [i.join() for i in threads]

        channels = [
            ('29', 'HBO HDTV (East)', '889066', '11096', '501'),
            ('30', 'HBO 2 HDTV (East)', '889066', '20936', '502'),
            ('31', 'HBO Signature HDTV (East)', '889066', '20938', '503'),
            ('32', 'HBO HDTV (West)', '889066', '11097', '504'),
            ('33', 'HBO 2 HDTV (West)', '889066', '21086', '505'),
            ('34', 'HBO Comedy HDTV (East)', '889066', '20939', '506'),
            ('35', 'HBO Family HDTV (East)', '889066', '20937', '507'),
            ('36', 'HBO Family (West)', '889066', '2531', '508'),
            ('37', 'HBO Zone HDTV (East)', '889066', '21089', '509'),
            ('38', 'HBO Latino HDTV (East)', '889066', '21861', '511'),
            ('39', 'Showtime HDTV (East)', '889066', '10564', '545'),
            ('40', 'Showtime HDTV (West)', '889066', '11095', '546'),
            ('41', 'Showtime 2 HDTV (East)', '889066', '20280', '547'),
            ('42', 'Showtime Showcase HDTV (East)', '889066', '21582', '548'),
            ('43', 'Showtime Extreme HDTV (East)', '889066', '21584', '549'),
            ('44', 'Showtime Beyond HDTV (East)', '889066', '26999', '550'),
            ('45', 'Showtime Next East HDTV (East)', '889066', '27058', '551'),
            ('46', 'Showtime Women HDTV (East)', '889066', '27061', '552'),
            ('47', 'STARZ HD (East)', '889066', '12904', '525'),
            ('48', 'STARZ HD (West)', '889066', '12907', '526'),
            ('49', 'STARZ Kids & Family HD (East)', '889066', '19917', '527'),
            ('50', 'STARZ Comedy HD (East)', '889066', '19915', '528'),
            ('51', 'STARZ Edge HD (East)', '889066', '19916', '529'),
            ('52', 'STARZ InBlack HD (East)', '889066', '24600', '530'),
            ('53', 'STARZ Cinema HD (East)', '889066', '24589', '531'),
            ('54', 'STARZ ENCORE HD (East)', '889066', '13168', '535'),
            ('55', 'STARZ ENCORE (West)', '889066', '2500', '536'),
            ('56', 'STARZ ENCORE Classic (East)', '889066', '2003', '537'),
            ('57', 'STARZ ENCORE Suspense (East)', '889066', '2002', '539'),
            ('58', 'STARZ ENCORE Black (East)', '889066', '2001', '540'),
            ('59', 'STARZ ENCORE Action HD (East)', '889066', '29910', '541'),
            ('60', 'STARZ ENCORE Family (East)', '889066', '2004', '542'),
            ('61', 'Cinemax HDTV (East)', '889066', '12860', '515'),
            ('62', 'Cinemax HDTV (West)', '889066', '12861', '516'),
            ('63', 'Cinemax HDTV', '889066', '21213', '523')
        ]

        threads = []
        for i in channels:
            threads.append(
                workers.Thread(
                    self.hbo_list,
                    i[0],
                    i[1],
                    i[2],
                    i[3],
                    i[4]))
        [i.start() for i in threads]
        [i.join() for i in threads]

        threads = []

        total = len(self.items)

        for i in range(0, total):
            threads.append(workers.Thread(self.items_list, self.items[i]))
        [i.start() for i in threads]
        [i.join() for i in threads]

        self.list = metacache.local(
            self.list, self.tm_img_link, 'poster3', 'fanart2')

        try:
            self.list = sorted(self.list, key=lambda k: k['channel'])
        except BaseException:
            pass

        self.channelDirectory(self.list)
        return self.list

    def hbo_list(self, num, channel, srvid, srcid, numid):
        try:
            dt = datetime.datetime.utcnow()
            dt = datetime.datetime(dt.year, dt.month, dt.day, dt.hour)
            hs = str(int(time.mktime(dt.timetuple())))
            url = self.tvguide_link % (srvid, hs, srcid, numid)
            data = client.request(url)
            data = json.loads(data)
            title = data[0]['ProgramSchedule']['Title']
            id = data[0]['ProgramSchedule']['ProgramId']
            url = self.get_year_hbo % id
            data = client.request(url)
            data = json.loads(data)
            try:
                year = data['program']['release_year']
            except:
                year = '0'
            title = title.replace('(%s)' % year, '').strip()
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')

            self.items.append((title, year, channel, num))
        except BaseException:
            pass

    def sky_list(self, num, channel, id):
        try:
            url = self.sky_now_link % id
            result = client.request(url, timeout='10')
            result = json.loads(result)
            match = result['listings'][id][0]['s']

            dt1 = (self.uk_datetime).strftime('%Y%m%d')
            url = self.sky_programme_link % (str(dt1), id)
            result = client.request(url, timeout='10')
            result = json.loads(result)
            result = result['schedule'][0]['events']
            result = [i for i in result if i['st'] == match][0]

            try:
                year = result['sy']
                year = re.findall(r'[(](\d{4})[)]', year)[0].strip()
                year = year.encode('utf-8')
            except:
                year = '0'

            title = result['t']
            title = title.replace('(%s)' % year, '').strip()
            title = client.replaceHTMLCodes(title)
            title = title.encode('utf-8')

            self.items.append((title, year, channel, num))
        except BaseException:
            pass

    def items_list(self, i):
        try:
            item = trakt.SearchAll(i[0], i[1], True)[0]

            content = item.get('movie')
            if not content:
                content = item.get('show')
            item = content

            title = item.get('title')
            title = client.replaceHTMLCodes(title)

            originaltitle = title

            year = item.get('year', 0)
            year = re.sub('[^0-9]', '', str(year))

            imdb = item.get('ids', {}).get('imdb', '0')
            imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

            tmdb = str(item.get('ids', {}).get('tmdb', 0))

            premiered = item.get('released', '0')
            try:
                premiered = re.compile(
                    r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
            except BaseException:
                premiered = '0'

            genre = item.get('genres', [])
            genre = [x.title() for x in genre]
            genre = ' / '.join(genre).strip()
            if not genre:
                genre = '0'

            duration = str(item.get('runtime', 0))

            rating = item.get('rating', '0')
            if not rating or rating == '0.0':
                rating = '0'

            votes = item.get('votes', '0')
            try:
                votes = str(format(int(votes), ',d'))
            except BaseException:
                pass

            mpaa = item.get('certification', '0')
            if not mpaa:
                mpaa = '0'

            tagline = item.get('tagline', '0')

            plot = item.get('overview', '0')

            people = trakt.getPeople(imdb, 'movies')

            director = writer = ''
            if 'crew' in people and 'directing' in people['crew']:
                director = ', '.join([director['person']['name'] for director in people['crew']
                ['directing'] if director['job'].lower() == 'director'])
            if 'crew' in people and 'writing' in people['crew']:
                writer = ', '.join([writer['person']['name'] for writer in people['crew'][
                    'writing'] if writer['job'].lower() in ['writer', 'screenplay', 'author']])

            cast = []
            for person in people.get('cast', []):
                cast.append(
                    {'name': person['person']['name'], 'role': person['character']})
            cast = [(person['name'], person['role']) for person in cast]

            try:
                if self.lang == 'en' or self.lang not in item.get(
                        'available_translations', [self.lang]):
                    raise Exception()

                trans_item = trakt.getMovieTranslation(
                    imdb, self.lang, full=True)

                title = trans_item.get('title') or title
                tagline = trans_item.get('tagline') or tagline
                plot = trans_item.get('overview') or plot
            except BaseException:
                pass

            try:
                artmeta = True
                art = client.request(
                    self.fanart_tv_art_link %
                    imdb,
                    headers=self.fanart_tv_headers,
                    timeout='10',
                    error=True)
                try:
                    art = json.loads(art)
                except BaseException:
                    artmeta = False
            except BaseException:
                pass

            try:
                poster2 = art['movieposter']
                poster2 = [x for x in poster2 if x.get('lang') == self.lang][::-1] + [x for x in poster2 if x.get(
                    'lang') == 'en'][::-1] + [x for x in poster2 if x.get('lang') in ['00', '']][::-1]
                poster2 = poster2[0]['url'].encode('utf-8')
            except BaseException:
                poster2 = '0'

            try:
                if 'moviebackground' in art:
                    fanart = art['moviebackground']
                else:
                    fanart = art['moviethumb']
                fanart = [x for x in fanart if x.get('lang') == self.lang][::-1] + [x for x in fanart if x.get(
                    'lang') == 'en'][::-1] + [x for x in fanart if x.get('lang') in ['00', '']][::-1]
                fanart = fanart[0]['url'].encode('utf-8')
            except BaseException:
                fanart = '0'

            try:
                banner = art['moviebanner']
                banner = [x for x in banner if x.get('lang') == self.lang][::-1] + [x for x in banner if x.get(
                    'lang') == 'en'][::-1] + [x for x in banner if x.get('lang') in ['00', '']][::-1]
                banner = banner[0]['url'].encode('utf-8')
            except BaseException:
                banner = '0'

            try:
                if 'hdmovielogo' in art:
                    clearlogo = art['hdmovielogo']
                else:
                    clearlogo = art['clearlogo']
                clearlogo = [x for x in clearlogo if x.get('lang') == self.lang][::-1] + [x for x in clearlogo if x.get(
                    'lang') == 'en'][::-1] + [x for x in clearlogo if x.get('lang') in ['00', '']][::-1]
                clearlogo = clearlogo[0]['url'].encode('utf-8')
            except BaseException:
                clearlogo = '0'

            try:
                if 'hdmovieclearart' in art:
                    clearart = art['hdmovieclearart']
                else:
                    clearart = art['clearart']
                clearart = [x for x in clearart if x.get('lang') == self.lang][::-1] + [x for x in clearart if x.get(
                    'lang') == 'en'][::-1] + [x for x in clearart if x.get('lang') in ['00', '']][::-1]
                clearart = clearart[0]['url'].encode('utf-8')
            except BaseException:
                clearart = '0'

            try:
                if self.tm_user == '':
                    raise Exception()

                art2 = client.request(
                    self.tm_art_link %
                    imdb, timeout='10', error=True)
                art2 = json.loads(art2)
            except BaseException:
                pass

            try:
                poster3 = art2['posters']
                poster3 = [x for x in poster3 if x.get(
                    'iso_639_1') == 'en'] + [x for x in poster3 if not x.get('iso_639_1') == 'en']
                poster3 = [x for x in poster3 if x.get(
                    'width') >= 500] + [x for x in poster3 if x.get('width') < 500]
                poster3 = sorted(
                    poster3,
                    key=lambda x: (
                        float(
                            x['vote_count'])),
                    reverse=True)
                poster3 = [(x['width'], x['file_path']) for x in poster3]
                poster3 = [
                    ('500', x[1]) if x[0] < 500 else (
                        '500', x[1]) for x in poster3]
                poster3 = self.tm_img_link % poster3[0]
                poster3 = poster3.encode('utf-8')
            except BaseException:
                poster3 = '0'

            try:
                fanart2 = art2['backdrops']
                fanart2 = [x for x in fanart2 if x.get(
                    'iso_639_1') == 'en'] + [x for x in fanart2 if not x.get('iso_639_1') == 'en']
                fanart2 = [x for x in fanart2 if x.get(
                    'width') >= 1920] + [x for x in fanart2 if x.get('width') < 1920]
                fanart2 = sorted(
                    fanart2,
                    key=lambda x: (
                        float(
                            x['vote_count'])),
                    reverse=True)
                fanart2 = [(x['width'], x['file_path']) for x in fanart2]
                fanart2 = [
                    (x[0], x[1]) if x[0] < 1280 else (
                        '1280', x[1]) for x in fanart2]
                fanart2 = self.tm_img_link % fanart2[0]
                fanart2 = fanart2.encode('utf-8')
            except BaseException:
                fanart2 = '0'

            self.list.append({'title': title,
                              'originaltitle': originaltitle,
                              'year': year,
                              'premiered': premiered,
                              'genre': genre,
                              'duration': duration,
                              'rating': rating,
                              'votes': votes,
                              'mpaa': mpaa,
                              'director': director,
                              'writer': writer,
                              'cast': cast,
                              'plot': plot,
                              'tagline': tagline,
                              'imdb': imdb,
                              'tmdb': tmdb,
                              'poster': '0',
                              'poster2': poster2,
                              'poster3': poster3,
                              'banner': banner,
                              'fanart': fanart,
                              'fanart2': fanart2,
                              'clearlogo': clearlogo,
                              'clearart': clearart,
                              'channel': i[2],
                              'num': i[3],
                              'mediatype': 'movie'})

        except BaseException:
            pass

    def uk_datetime(self):
        dt = datetime.datetime.utcnow() + datetime.timedelta(hours=0)
        d = datetime.datetime(dt.year, 4, 1)
        dston = d - datetime.timedelta(days=d.weekday() + 1)
        d = datetime.datetime(dt.year, 11, 1)
        dstoff = d - datetime.timedelta(days=d.weekday() + 1)
        if dston <= dt < dstoff:
            return dt + datetime.timedelta(hours=1)
        else:
            return dt

    def channelDirectory(self, items):
        if items is None or len(items) == 0:
            control.idle()
            sys.exit()

        sysaddon = sys.argv[0]

        syshandle = int(sys.argv[1])

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()

        addonFanart, settingFanart = control.addonFanart(), control.setting('fanart')

        traktCredentials = trakt.getTraktCredentialsInfo()

        try:
            isOld = False
            control.item().getArt('type')
        except BaseException:
            isOld = True

        isPlayable = 'false' if control.setting(
            'hosts.mode') == '0' else 'true'

        indicators = playcount.getMovieIndicators(
            refresh=True)

        playbackMenu = control.lang(32063).encode(
            'utf-8') if control.setting('hosts.mode') == '2' else control.lang(32064).encode('utf-8')

        watchedMenu = control.lang(32068).encode(
            'utf-8') if trakt.getTraktIndicatorsInfo() else control.lang(32066).encode('utf-8')

        unwatchedMenu = control.lang(32069).encode(
            'utf-8') if trakt.getTraktIndicatorsInfo() else control.lang(32067).encode('utf-8')

        queueMenu = control.lang(32065).encode('utf-8')

        traktManagerMenu = control.lang(32070).encode('utf-8')

        nextMenu = control.lang(32053).encode('utf-8')

        addToLibrary = control.lang(32551).encode('utf-8')

        containerRefresh = control.lang(32667).encode('utf-8')

        for i in items:
            try:
                label = '[B][COLOR lightblue]%s[/COLOR][/B] : [I]%s (%s)[/I]' % (i['channel'].upper(),
                                                                                 i['title'], i['year'])
                imdb, tmdb, title, year = i['imdb'], i['tmdb'], i['originaltitle'], i['year']
                sysname = urllib.quote_plus('%s (%s)' % (title, year))
                systitle = urllib.quote_plus(title)

                meta = dict((k, v) for k, v in i.iteritems() if not v == '0')
                meta.update({'imdbnumber': imdb, 'tmdb_id': tmdb})

                meta.update(
                    {'trailer': '%s?action=trailer&name=%s' % (sysaddon, sysname)})
                if 'duration' not in i:
                    meta.update({'duration': '120'})
                elif i['duration'] == '0':
                    meta.update({'duration': '120'})
                try:
                    meta.update({'duration': str(int(meta['duration']) * 60)})
                except BaseException:
                    pass
                try:
                    meta.update(
                        {'genre': cleangenre.lang(meta['genre'], self.lang)})
                except BaseException:
                    pass

                poster = [
                    i[x] for x in [
                        'poster3',
                        'poster',
                        'poster2'] if i.get(
                        x,
                        '0') != '0']
                poster = poster[0] if poster else addonPoster
                meta.update({'poster': poster})

                cm = []

                cm.append(
                    (queueMenu,
                     'RunPlugin(%s?action=queueItem)' %
                     sysaddon))

                try:
                    overlay = int(playcount.getMovieOverlay(indicators, imdb))
                    if overlay == 7:
                        if trakt.getTraktIndicatorsInfo():
                            cm.append(
                                (unwatchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=6)' %
                                 (sysaddon, imdb)))
                        meta.update({'playcount': 1, 'overlay': 7})
                    else:
                        if trakt.getTraktIndicatorsInfo():
                            cm.append(
                                (watchedMenu, 'RunPlugin(%s?action=moviePlaycount&imdb=%s&query=7)' %
                                 (sysaddon, imdb)))
                        meta.update({'playcount': 0, 'overlay': 6})
                except BaseException:
                    pass

                if trakt.getTraktIndicatorsInfo():
                    cm.append(
                        (traktManagerMenu,
                         'RunPlugin(%s?action=traktManager&name=%s&imdb=%s&content=movie)' %
                         (sysaddon,
                          sysname,
                          imdb)))

                sysmeta = urllib.quote_plus(json.dumps(meta))
                ac = 'playLorka' if 'discovery' in control.addonInfo(
                    'id') else 'play'

                url = '%s?action=%s&title=%s&year=%s&imdb=%s&meta=%s&t=%s' % (
                    sysaddon, ac, systitle, year, imdb, sysmeta, self.systime)
                sysurl = urllib.quote_plus(url)

                path = '%s?action=%s&title=%s&year=%s&imdb=%s' % (
                    sysaddon, ac, systitle, year, imdb)

                if isOld:
                    cm.append(
                        (control.lang2(19033).encode('utf-8'), 'Action(Info)'))

                cm.append(
                    (addToLibrary,
                     'RunPlugin(%s?action=movieToLibrary&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s)' %
                     (sysaddon,
                      sysname,
                      systitle,
                      year,
                      imdb,
                      tmdb)))

                cm.append(
                    (containerRefresh,
                     'RunPlugin(%s?action=refreshContainer)' %
                     (sysaddon)))

                item = control.item(label=label)

                art = {}
                art.update({'icon': poster, 'thumb': poster, 'poster': poster})

                if 'banner' in i and not i['banner'] == '0':
                    art.update({'banner': i['banner']})
                else:
                    art.update({'banner': addonBanner})

                if 'clearlogo' in i and not i['clearlogo'] == '0':
                    art.update({'clearlogo': i['clearlogo']})

                if 'clearart' in i and not i['clearart'] == '0':
                    art.update({'clearart': i['clearart']})

                if settingFanart == 'true' and 'fanart3' in i and not i['fanart3'] == '0':
                    art.update({'fanart': i['fanart3']})
                    item.setProperty('Fanart_Image', i['fanart3'])
                elif settingFanart == 'true' and 'fanart2' in i and not i['fanart2'] == '0':
                    art.update({'fanart': i['fanart2']})
                    item.setProperty('Fanart_Image', i['fanart2'])
                elif settingFanart == 'true' and 'fanart' in i and not i['fanart'] == '0':
                    art.update({'fanart': i['fanart']})
                    item.setProperty('Fanart_Image', i['fanart'])
                elif addonFanart is not None:
                    art.update({'fanart': addonFanart})

                item.setArt(art)
                item.addContextMenuItems(cm)
                item.setProperty('IsPlayable', isPlayable)
                for i in meta.keys():
                    if i not in control.valid_infolabels:
                        meta.pop(i, None)
                item.setInfo(type='Video', infoLabels=meta)
                control.addItem(
                    handle=syshandle,
                    url=url,
                    listitem=item,
                    isFolder=False)
            except BaseException:
                pass

        control.content(syshandle, 'movies')
        control.directory(syshandle, cacheToDisc=True)
        views.setView('fail',
                      {'skin.estuary': 55,
                       'skin.confluence': 500,
                       'skin.xonfluence': 500})
