# Size indicates importance

---

##### Fix proxy enabler

---

### Check youtube setup action

---

#### Add search music


#######################################################################################

- **Id will change to "plugin.program.alivegr":**

    You have nothing to worry about this actually, I'll do the replacement semi-automatically by asking users first
  
- **Addon will be moved into github:**

    The parent "Thgiliwt" repository will now host alpha and testing versions.
    
    Once again you have nothing to do in this regard.

- **Minimum Kodi version supported will be bumped to Leia 18:**

    It has some neat features like live adaptive support, and its stable and mature enough

    Some streams' related settings have new defaults

- **Resolveurl will now be be imported optionally:**

    Plus you 'll have to do an action in order to enable it this is due to the nature of the streams it attempts to resolve some of them are considered grey-zoned

    Also it hasn't been ported yet into Python 3 so I might also make new stream link plugins to mitigate for unofficial streams

- **All menu items will be enabled by default including kids movies:**

    To watch streams other than official, youtube, vimeo & dailymotion ones you have to enable the additional streams first (see point above)

- **Live channels can now be pinned**:

    You can watch a video on a previous tweet for demonstration

- **Search functionality has been revamped:** 

    Now you can search by action/actress or even director
  
- **Networks' addons have been restored (except novasports):**

    You can watch content from those as well. For optimized experience make sure to utilize VPN with a greek server if you live outside Greece.
  
- **Python 3 support for Kodi 19 will be completed and fully tested**

#############################################################################
